// Material master // Resourcec master // 

export const EMPTY_SEARCH = 'cypress_000000'
export const DEMAND_REPORT_PROJECT1 = 'EMPTY PROJECTC'
export const DEMAND_REPORT_PROJECT2 = 'Training Project'
export const SEARCH_PROJECT ='Construct UI Automation'
export const SEARCH_PROJECT1 ='cypress_11314'
export const SCHEDULER_TASKBOARD_PROJECT ='Scheduler_TaskBoard'
export const SCHEDULER_SUR_PROJECT ='Scheduler_Sur'
export const ACTIVITY1 ='EXCAVATION'
export const ACTIVITY2 ='FOOTING'
export const ACTIVITY3 ='CASTING'
export const ACTIVITY4 ='FLOORING'
export const GANTT_TAG ='VILLA NUMBER'
export const SEARCH_MATERIAL ='automation'
export const SCHEDULER_DROP_PROJECT ='Drag_project'

// Task Board // 

export const NOT_STARTED ='Brickwork'
export const COMPLETED ='Concrete'
export const STARTED ='Excavation'
export const UPLOAD_DOC = 'Health isurance.pdf'
export const STARTED2 ='Foundation'
export const NOT_STARTED2 ='Plumbing'
export const LINK_RFI ='1_RFI_009'
export const TASK_COMMENT ='Task comepleted'
export const NOT_STARTED3 ='Brickwork'


// SUR // 

export const SUR_ACTIVITY ='Roofing'