import '../../support/setup-tests'
import { getUser } from '../../support/users'

const schedulerConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Schedule Update Request', () => {

    let getSURreason

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/scheduler/sur/**').as('getSURs')
        cy.server().route('GET', '/scheduler/task_rfi_link/rfi_status/**').as('getTaskStatus')
        cy.server().route('GET', '/scheduler/project_scheduler/scheduler_meta_data/**').as('getSURform')
        cy.server().route('DELETE', '/scheduler/sur/**/**').as('deleteSUR')
        cy.server().route('GET', '/scheduler/calendar/**/**').as('getSURsCal')
        cy.server().route('GET', '/scheduler/project_scheduler/published/**?all_tasks=true').as('getSurDetails')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(schedulerConstants.SCHEDULER_SUR_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Scheduler')
        cy.clickElement('Task Board')

    })

    it('Should validate all SUR landing page columns', () => {

        cy.log('Validating all landing page SUR column names')
        cy.log('Landing on SUR page')
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .clickElement('Scheduler')
            .clickElement('Schedule Update Request')
            .wait('@getSURs').its('status').should('eq', 200)
            .get('.request-list-title').should('contain.text', 'SUR')
            .get('#top-bar-heading').should('contain.text', 'Word Cloud')
            .get('.sur-holder').should('contain.text', 'Activity Id')
            .get('.sur-holder').should('contain.text', 'Activity Name')
            .get('.sur-holder').should('contain.text', 'Date Raised')
            .get('.sur-holder').should('contain.text', 'Raised by')
            .get('.sur-holder').should('contain.text', 'Assignee')
            .get('.sur-holder').should('contain.text', 'Status')
    });

    it('Should raise SUR and validate and delete it ', () => {

        cy.log('Clicking on SUR button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
            .wait(2000)
            .clickElement('sur')
        cy.getRandomString().then(SURreason => {
            raiseNewSUR(SURreason)
            getSURreason = SURreason

            cy.log('Validating SUR')
                .get(':nth-child(1) > [title="Roofing"]').click()
                .wait('@getSurDetails').its('status').should('eq', 200)
                .get('.sur-note').should('contain.text', getSURreason)

            deleteSUR()
        })
    });

    it('Should raise SUR and deney it', () => {

        cy.log('Clicking on SUR button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
            .wait(2000)
            .clickElement('sur')
        cy.getRandomString().then(SURreason => {
            raiseNewSUR(SURreason)
            getSURreason = SURreason

            cy.log('Validating SUR')
                .get(':nth-child(1) > [title="Roofing"]').click()
                .wait('@getSurDetails').its('status').should('eq', 200)
                .get('.modal-footer').contains('Deny').click()
                .wait('@getSURs').its('status').should('eq', 200)

            cy.log('Validating Raised SUR status')
                .clickElement('Scheduler')
                .clickElement('Task Board')
                .wait('@getTaskStatus').its('status').should('eq', 200)
                .wait(5000)
            cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
                .wait(2000)
                .clickElement('sur')
                .get('.sur-list-container').should('contain.text', 'Denied')
                .get('.close-label').click()
        })
    });

    it('Should raise SUR and Approve it', () => {
        cy.log('Clicking on SUR button')
        .wait('@getTaskStatus').its('status').should('eq', 200)
    cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
        .wait(2000)
        .clickElement('sur')
    cy.getRandomString().then(SURreason => {
        raiseNewSUR(SURreason)
        getSURreason = SURreason

        cy.log('Validating SUR')
            .get(':nth-child(1) > [title="Roofing"]').click()
            .wait('@getSurDetails').its('status').should('eq', 200)
            .get('.modal-footer').contains('Approve').click()
            .wait('@getSURs').its('status').should('eq', 200)

        cy.log('Validating Raised SUR status')
            .clickElement('Scheduler')
            .clickElement('Task Board')
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .wait(5000)
        cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
            .wait(2000)
            .clickElement('sur')
            .get('.sur-list-container').should('contain.text', 'Approved')
            .get('.close-label').click()
    })
    });
})

const raiseNewSUR = function (SURreason) {

    cy.log('Raising new SUR')
        .get('.footer').contains('Raise SUR').click()
        .get('#task-start-date').click()
        .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_month_cont > .dhtmlxcalendar_line > .dhtmlxcalendar_cell > .dhtmlxcalendar_month_arrow_right').click()
        .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_dates_cont > :nth-child(3) > :nth-child(7) > .dhtmlxcalendar_label').click()

        .get(':nth-child(5) > .col > .row > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()
    cy.findByText('Katerra cypress Automation').click()

        .get(':nth-child(6) > .col > :nth-child(1) > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()
    cy.findByText('Shortage of Labor').click()
        .get(':nth-child(6) > .col > :nth-child(1) > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()

        .get('.reason').type(SURreason)
        .get('.mat-raised-button').click()
        .wait('@getSURform').its('status').should('eq', 200)
        .wait('@getSURsCal').its('status').should('eq', 200)
        .wait('@getSURsCal')
        .wait(3000)
        .get('.close-label').click()

    cy.log('Navigating to SUR page')
        .clickElement('Scheduler')
        .clickElement('Schedule Update Request')
        .wait('@getSURs').its('status').should('eq', 200)

}

const deleteSUR = function () {

    cy.log('Deleting Raised SUR')
        .clickElement('Scheduler')
        .clickElement('Task Board')
        .wait('@getTaskStatus').its('status').should('eq', 200)
        .wait(5000)
    cy.findByText(schedulerConstants.SUR_ACTIVITY).click()
        .wait(2000)
        .clickElement('sur')
        .get('.trash-icon > .ng-fa-icon > .svg-inline--fa > path').click()
        .get('.discard-modal-header').should('contain.text', 'Are You Sure?')
        .get('.modal-title').should('contain.text', 'Are you sure you want to delete the schedule update request raised?')
        .get('.modal-body').should('contain.text', 'Yes')
        .get('.modal-body').should('contain.text', 'No')
        .get('.modal-body').contains('Yes').click()
        .wait('@deleteSUR').its('status').should('eq', 200)
        .get('.close-label').click()
}