import '../../support/setup-tests'

const schedulerConstants = require('../../support/constants')

describe('Scheduler Gantt', () => {

    let ganttActivityName

    beforeEach(() => {
        cy.server().route('GET', '/cmb/activity_code').as('getActivityCode')
        cy.server().route('PATCH', '/cmb/V1/configurations/sur').as('updateSUR')
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/tenant/members?sortKey=name&sort=1&pageSize=500&type=project&typeId=**&includeUsers=true').as('getTenantMembers')
        cy.server().route('PUT', '/scheduler/project_task/**').as('updateProjectTask')
        cy.server().route('PUT', '/scheduler/project_task/bulk_update/**').as('updateProjectBulk')
        cy.server().route('DELETE', '/scheduler/project_task/bulk/delete/**').as('deleteActivity')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(schedulerConstants.SEARCH_PROJECT1)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Scheduler')
        cy.clickElement('Gantt')

    })

    it('Should verify Gantt landing page fields', () => {

        cy.log('Validating All Gantt page fields')
            .wait('@getActivityCode').its('status').should('eq', 200)
            .get('.title-bar').should('contain.text', 'Gantt')

        cy.log('Validating toolbar export button fileds')
            .findByDataCy('bottom').should('exist')
            .get('.toolbar-export-button').click()
            .findByDataCy('exportexcel').should('exist')
            .findByDataCy('exportpdf').should('exist')
            .findByDataCy('exportevr').should('exist')
            .findByDataCy('exportwbs').should('exist')
            .findByDataCy('exportprogress').should('exist')

        cy.log('Validating toggele button fileds')
            .get('.toolbar-toggle-button').should('exist')
            .get('.toolbar-toggle-button').click()
            .get('.popover-body').should('contain.text', 'Today')
            .get('.popover-body').should('contain.text', 'Expected Dates')
            .get('.popover-body').should('contain.text', 'Projected Plan')
            .get('.popover-body').should('contain.text', 'Colors')
            .findByDataCy('refreshProjectedPlan').should('exist')

        cy.log('Validating draft options fileds')
            .findByDataCy('draftOptions').should('exist')
            .clickElement('draftOptions')
            .get('.component-grid').should('contain.text', 'Save as')
            .get('.component-grid').should('contain.text', 'Restore Points')
            .get('.component-grid').should('contain.text', 'Auto-Schedule Subprojects')
            .get('.component-grid').should('contain.text', 'Schedule quality')
            .get('.component-grid').should('contain.text', 'Choose Columns')

            .get('.component-grid').contains('Save as').trigger('mouseover')
            .get('.component-grid').should('contain.text', 'Save as a Baseline')
            .get('.component-grid').should('contain.text', 'Save as a Template')

        cy.log('Validating Allocate button fields')
            .findByDataCy('allocate').should('exist')
            .clickElement('allocate')
            .get('.component-grid').should('contain.text', 'Material')
            .get('.component-grid').should('contain.text', 'Resource')
            .get('.component-grid').should('contain.text', 'Parameters')

            .get('.component-grid').contains('Material').trigger('mouseover')
            .get('.component-grid').should('contain.text', 'Upload CSV')
            .get('.component-grid').should('contain.text', 'Download Template')

            .get('.component-grid').contains('Resource').trigger('mouseover')
            .get('.component-grid').should('contain.text', 'Upload CSV')
            .get('.component-grid').should('contain.text', 'Download Template')

            .get('.component-grid').contains('Parameters').trigger('mouseover')
            .get('.component-grid').should('contain.text', 'Upload CSV')
            .get('.component-grid').should('contain.text', 'Download Template')

        cy.log('Validating other tools')
            .get('.views-container').should('exist')
            .findByDataCy('setscale').should('exist')
            .findByDataCy('filter').should('exist')
            .get('.legendTooltip').should('exist')
            .get('.zoom-button').should('exist')

        cy.log('Validating scale fields')
            .clickElement('setscale')
            .get('.component-grid').should('contain.text', 'Day')
            .get('.component-grid').should('contain.text', 'Week')
            .get('.component-grid').should('contain.text', 'Month')
            .get('.component-grid').should('contain.text', 'Year')
            .get('.component-grid').should('contain.text', 'Multiple')

        cy.log('Validating paths')
            .get('.legendTooltip').trigger('mouseover')
            .get('.component-grid').should('contain.text', 'Critical Path')
            .get('.component-grid').should('contain.text', 'Milestone')
            .get('.component-grid').should('contain.text', 'Summary Activity')
            .get('.component-grid').should('contain.text', 'Critical Activity')
            .get('.component-grid').should('contain.text', 'Regular Activity')
    });

    it('Should validate gantt grid data column names', () => {

        cy.log('Validating All Gantt page fields')
            .wait('@getActivityCode').its('status').should('eq', 200)
            .findByDataCy('gantt-holder').should('contain.text', 'Activity ID')
            .findByDataCy('gantt-holder').should('contain.text', 'Activity Name')
            .findByDataCy('gantt-holder').should('contain.text', 'Duration')
            .findByDataCy('gantt-holder').should('contain.text', 'Start Date')
            .findByDataCy('gantt-holder').should('contain.text', 'End Date')
            .findByDataCy('gantt-holder').should('contain.text', 'Float')
            .findByDataCy('gantt-holder').should('contain.text', 'Assignee')
            .findByDataCy('gantt-holder').should('contain.text', 'Type')
            .findByDataCy('gantt-holder').should('contain.text', schedulerConstants.SEARCH_PROJECT1)

    });

    it('Should choose Extra columns to board and then Unchoose it', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')
            .clickElement('draftOptions')
            .get('.component-grid').contains('Choose Columns').click()

        cy.log('Validating Choose columns fields')
            .get('.modal-header').should('contain.text', 'Choose Columns')
            .get('.close > span').should('exist')
            .get('.searchbox').should('exist')
            .get('.material-table').should('contain.text', 'Activity ID')
            .get('.material-table').should('contain.text', 'Activity Name')
            .get('.material-table').should('contain.text', 'Duration')
            .get('.material-table').should('contain.text', 'Start Date')
            .get('.material-table').should('contain.text', 'End Date')
            .get('app-columns-template').should('contain.text', 'Cancel')
            .get('app-columns-template').should('contain.text', 'Show Columns')

        cy.log('Searching and choosing columns')
            .get('.searchbox').type('Level')
            .wait(2000)
            .get('.ui-chkbox-box').click()
            .get('.searchbox').clear()
            .get('.searchbox').type('cost code')
            .wait(2000)
            .get('.ui-chkbox-box').click()
            .get('app-columns-template').contains('Show Columns').click()

        cy.findByDataCy('gantt-holder').should('contain.text', 'Level')
        cy.findByDataCy('gantt-holder').should('contain.text', 'Cost Code')

        cy.log('Unchoosinig selected columns')
            .clickElement('draftOptions')
            .get('.component-grid').contains('Choose Columns').click()
            .get('.searchbox').type('Level')
            .wait(2000)
            .get('.ui-chkbox-box').click()
            .get('.searchbox').clear()
            .get('.searchbox').type('cost code')
            .wait(2000)
            .get('.ui-chkbox-box').click()
            .get('app-columns-template').contains('Show Columns').click()

        cy.findByDataCy('gantt-holder').should('not.contain.text', 'Level')
        cy.findByDataCy('gantt-holder').should('not.contain.text', 'Cost Code')

    });

    it.skip('Should add No of activities to board by importing through XML file', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')
            .clickElement('draftOptions')
            .get('.component-grid').contains('Choose Columns').trigger('mouseover')
            .get('.component-grid').contains('Import').trigger('mouseover')
        //.get('.component-grid').contains('Import XML').click()

    });

    it.skip('Should add No of activities to board by importing through Activity template', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')
            .clickElement('draftOptions')
            .get('.component-grid').contains('Import').trigger('mouseover')

    });

    it('Should add New activity and delete it later', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName
            deleteActivity(ganttActivityName)
        })
    });

    it('Should validate all Edit Activity details', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Validating header fields')
                .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()
                .get('.slider-header').should('contain.text', 'Edit Activity Details')
                .get('.slider-header').should('contain.text', 'Predecessors')
                .get('.slider-header').should('contain.text', 'Successors')
                .get('.slider-header').should('contain.text', 'Materials')
                .get('.slider-header').should('contain.text', 'Resources')
                .get('.slider-header').should('contain.text', 'Activity Step')
                .findByDataCy('allactivity').should('exist')
                .findByDataCy('validate').should('exist')
                .findByDataCy('closeLightbox').should('exist')
                .verifyElementDisabled('validate')

            cy.log('Validating Edit activity details fields')
                .findByDataCy('activity-name').should('exist')
                .findByDataCy('activity-id').should('exist')
                .findByDataCy('startdate').should('exist')
                .findByDataCy('duration').should('exist')
                .findByDataCy('assignee').should('exist')
                .findByDataCy('cal').should('exist')
                .findByDataCy('trg-qty').should('exist')
                .findByDataCy('unit').should('exist')
                .findByDataCy('constraint-type').should('exist')
                .findByDataCy('constraint-date').should('exist')
                .findByDataCy('lumpsum').should('exist')
                .findByDataCy('actual').should('exist')
                .findByDataCy('tags').should('exist')

            deleteActivity(ganttActivityName)

        })
    });

    it('Should add New activity to board and then Edit Activity details', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Editing Activity details')
                .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()

            cy.log('Activity ID')
                .get('[data-cy=activity-id] > .ng-pristine').clear()
                .get('[data-cy=activity-id] > .ng-untouched').type('3')

            cy.log('Start date')
                .get('[data-cy=startdate] > .constraint-date-label > .fa').click()
                .get('.dhtmlxcalendar_month_arrow_right').click()
                .get(':nth-child(2) > :nth-child(5) > .dhtmlxcalendar_label').click()

            cy.log('Duration')
                .get('[data-cy=duration] > .ng-pristine').click()
                .get('[data-cy=duration] > .ng-pristine').clear()
                .get('[data-cy=duration] > .ng-untouched').type('3')

            cy.log('Unit')
                .get('[data-cy=unit] > .ng-pristine').type('Kg')

            cy.log('Constraint Type')
                .get('.constraints-dropdown > .ng-select-container > .ng-arrow-wrapper').click()
            cy.findByText('Start on or after').click()

            cy.log('Constraint Date')
                .get('[data-cy=constraint-date] > .constraint-date-label > .fa').click()
                .get(':nth-child(3) > :nth-child(5) > .dhtmlxcalendar_label').click()

            cy.log('Lump sum cost')
                .get('[data-cy=lumpsum] > .ng-pristine').type('$2000')

            cy.log('Actual cost')
                .get('[data-cy=actual] > .ng-untouched').type('$1500')

            cy.log('Saving activity details')
                .clickElement('validate')
                .wait('@updateProjectBulk')
                .clickElement('closeLightbox')

            deleteActivity(ganttActivityName)
        })
    });

    it('Should perform adding and deleting Tag in activity', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Validating Tags fields')
                .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()
                .clickElement('tags')
                .get('.discard-modal-header').should('contain.text', 'Choose Tags')
                .get('.modal-body').should('contain.text', 'Cancel')
                .get('.modal-body').should('contain.text', 'Confirm')
                .get('.modal-title').should('contain.text', 'Select Tags')
                .get('.modal-title').should('contain.text', 'Selected Tags:')
                .get('.modal-title').should('contain.text', 'No Tags Selected')

            cy.log('Adding Tags to activity')
                .get('.activity-code-dropdown > .ng-select-container').click()
                .get('.activity-code-dropdown > .ng-select-container > .ng-value-container > .ng-input > input')
                .type(schedulerConstants.GANTT_TAG)
            cy.findByText(schedulerConstants.GANTT_TAG).click()
                .get('.ui-chkbox-box').click()

            cy.log('Deleting tags')
                .get('.my-container').should('contain.text', schedulerConstants.GANTT_TAG)
                .get('.ng-fa-icon').click()
                .get('.modal-body').contains('Confirm').click()
                .clickElement('closeLightbox')

            deleteActivity(ganttActivityName)
        })
    });

    it('Should perfrom adding and deleting sub activity', () => {

        cy.server().route('GET', '/scheduler/project_scheduler/sub_project_schedules/**').as('getSubProjectDetails')

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Adding sub-activity')
                .get('.odd > [data-column-index="0"] > .gantt_add').click()
                .get('.gantt_selected > [data-column-index="1"] > .gantt_tree_content > .levelnone > span')
                .click()
                .wait('@getSubProjectDetails')
                .get('[data-cy=activity-name] > .ng-valid')
                .click().clear().type('Sub_Activity')
                .clickElement('validate')
                .wait('@updateProjectBulk')
                .clickElement('closeLightbox')

            cy.log('Deleting sub-activity')
                .get('.gantt_grid_data').contains('Sub_Activity').click()
                .clickElement('delete')
                .wait('@deleteActivity').its('status').should('eq', 200)

            deleteActivity(ganttActivityName)
        })
    });

    it.skip('Should perform Allocate and delete Materials to activity', () => {

        cy.server().route('GET', '/scheduler/project_bom?page=1&limit=20&project_id=**').as('getMaterials')
        cy.server().route('GET', '/scheduler/material_master?page=1.05&limit=20').as('getMaterialsList')
        cy.server().route('GET', '/scheduler/material_master/search/materials?search_term=' + schedulerConstants.SEARCH_MATERIAL + '&category=description&page=1&limit=20').as('getSearchResult')

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Allocating Materials to project')
                .clickElement('Scheduler')
                .clickElement('Project Bill of Materials')
                .wait('@getMaterials').its('status').should('eq', 200)
                .clickElement('addMaterial')
            cy.findByText('Add Materials').click()
                .wait('@getMaterialsList').its('status').should('eq', 200)
                .get('.modal-header').should('contain.text', 'Add Materials')
                .get('.header-wrapper > .search-wrapper > .search-box')
                .type(schedulerConstants.SEARCH_MATERIAL)
                .wait('@getSearchResult').its('status').should('eq', 200)
                .get('app-table.ng-star-inserted > [data-cy=table] > [data-cy=p-treeTable] > .ui-treetable > .ui-treetable-scrollable-wrapper > .ui-treetable-scrollable-view > .ui-treetable-scrollable-body > table > .ui-treetable-tbody > :nth-child(1) > :nth-child(1) > [data-cy=checkbox] > .ui-chkbox > .ui-chkbox-box').click()
                .get('app-table.ng-star-inserted > [data-cy=table] > [data-cy=p-treeTable] > .ui-treetable > .ui-treetable-scrollable-wrapper > .ui-treetable-scrollable-view > .ui-treetable-scrollable-body > table > .ui-treetable-tbody > :nth-child(2) > :nth-child(1) > [data-cy=checkbox] > .ui-chkbox > .ui-chkbox-box').click()
                .get('.end-button-group > .mat-focus-indicator').click()
                .get('.end-button-group > .mat-focus-indicator').click()
                .wait('@getMaterials').its('status').should('eq', 200)
                .clickElement('Scheduler')
                .clickElement('Gantt')
                .wait('@getActivityCode').its('status').should('eq', 200)

            cy.log('Allocating Materials to activity')
                .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()

        })
    });

    it.skip('should perfrom Allocate and delete Resources to activity', () => {

        cy.server().route('GET', '/scheduler/project_resource?page=1&limit=20&project_id=**').as('getResources')
        cy.server().route('GET', '/scheduler/resource_master?page=1.05&limit=20').as('getResourceList')
        cy.server().route('GET', '/scheduler/resource_master?search_term=' + schedulerConstants.SEARCH_MATERIAL + '&category=name&page=1&limit=20').as('getSearchResult')

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.getRandomString().then(activityName => {
            addNewActivity(activityName)
            ganttActivityName = activityName

            cy.log('Allocating Materials to project')
                .clickElement('Scheduler')
                .clickElement('Resources')
                .wait('@getResources')
                .clickElement('addMaterial')
                .clickElement('addResource')
                .wait('@getResourceList').its('status').should('eq', 200)
                .get('.modal-header').should('contain.text', 'Add Resources')
                .get('.header-wrapper > .search-wrapper > .search-box')
                .type(schedulerConstants.SEARCH_MATERIAL)
                .wait('@getSearchResult').its('status').should('eq', 200)
                .get(':nth-child(1) > :nth-child(1) > [data-cy=checkbox] > .ui-chkbox > .ui-chkbox-box').click()
                .get(':nth-child(2) > :nth-child(1) > [data-cy=checkbox] > .ui-chkbox > .ui-chkbox-box').click()
                .get('.end-button-group > .mat-focus-indicator').click()
                .get('.end-button-group > .mat-focus-indicator').click()
                .wait('@getResources').its('status').should('eq', 200)
                .clickElement('Scheduler')
                .clickElement('Gantt')
                .wait('@getActivityCode').its('status').should('eq', 200)

            cy.log('Allocating Resource to activity')
                .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()

        })
    });

    it.skip('Should add No.of activities,assign Relationship through predecessors and delete it later', () => {

        cy.wait('@getActivityCode').its('status').should('eq', 200)
        cy.get('.toolbar-draft-button').click()
            .wait('@getActivityCode')

        cy.log('Adding first Activity')
            .clickElement('add')
            .wait('@updateProjectBulk')
            cy.get('.gantt_grid_data').click()
            .wait(2000)
            .get('.gantt_grid_data').contains('New Activity').click()
            .get('.gantt_grid_data').contains('New Activity').dblclick({ force: true })
            .wait(4000)
            //.clear().type('M1')
    });
})

const addNewActivity = function (activityName) {

    cy.log('Adding new activity')
        .clickElement('add')
        .wait('@updateProjectBulk')
        .get('.odd > [data-column-index="1"] > .gantt_tree_content > .levelnone > span').click()
        .get('[data-cy=activity-name] > .ng-untouched')
        .click().clear().type(activityName)
        .clickElement('validate')
        .wait('@updateProjectBulk')
        .clickElement('closeLightbox')
}

const deleteActivity = function (ganttActivityName) {

    cy.log('Deleting activity')
        .get('.gantt_grid_data').contains(ganttActivityName).click()
        .clickElement('delete')
        .wait('@deleteActivity').its('status').should('eq', 200)
        .clickElement('discard')
        .wait('@getActivityCode')
}