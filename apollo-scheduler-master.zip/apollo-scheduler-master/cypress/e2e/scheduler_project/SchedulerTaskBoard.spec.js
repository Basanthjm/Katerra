import '../../support/setup-tests'
import { getUser } from '../../support/users'

const schedulerConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

let resourceMasterName

describe('Scheduler Task Board', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/scheduler/task_rfi_link/rfi_status/**').as('getTaskStatus')
        cy.server().route('GET', '/scheduler/project_task/history/**').as('getActivityHistory')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(schedulerConstants.SCHEDULER_TASKBOARD_PROJECT)
        //cy.get('.ap-project-search > .ap-text-sm').type(schedulerConstants.SCHEDULER_DROP_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Scheduler')
        cy.clickElement('Task Board')

    })

    it('Should validate all task board landing page fields', () => {

        cy.log('Validating All Task Board page fields')
            .wait('@getTaskStatus').its('status').should('eq', 200)

        cy.log('Validating tittle bar fields')
            .get('.title-bar').should('contain.text', 'Task Board')
            .get('.views-container').should('contain.text', 'View  Standard ')
            .get('.total-project-value > .value-name').should('contain.text', 'Total Project Value')
            .get('.earned-value > .value-name').should('contain.text', 'Earned Value')
            .get('.scheduled-value > .value-name').should('contain.text', 'Scheduled Value')
            .get(':nth-child(4) > .value-name').should('contain.text', 'SPI')
            .get('.ng-star-inserted > .value-name').should('contain.text', 'CPI')
            .findByDataCy('refreshBudget').should('exist')
            .findByDataCy('filterIcon').should('exist')

    });

    it('Should validate task board columns and validate count of activities', () => {

        cy.server().route('GET', '/scheduler/project_task/***?page=1&limit=30&status=not_started').as('getNotStartedCount')
        cy.server().route('GET', '/scheduler/project_task/***?page=1&limit=30&status=started').as('getStartedCount')
        cy.server().route('GET', '/scheduler/project_task/***?page=1&limit=30&status=completed').as('getCompletedCount')

        cy.log('Validating task board columns')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText('Not Started').should('exist')
            .get('.middle-board > app-header > .header > .mr-auto').should('contain.text', 'Started')
        cy.findByText('Completed').should('exist')

        cy.log('Validating Not started activities count')
            .wait('@getNotStartedCount').then((xhr) => {
                const NotStartedActivitiesCount = xhr.response.body.leaf_count
                cy.log('Number of Not started Activities ->', NotStartedActivitiesCount)
                    .get(':nth-child(1) > app-header > .header')
                    .should('contain.text', NotStartedActivitiesCount)
            })

        cy.log('Validating started activities count')
            .wait('@getStartedCount').then((xhr) => {
                const StartedActivitiesCount = xhr.response.body.leaf_count
                cy.log('Number of Started Activities ->', StartedActivitiesCount)
                    .get('.middle-board > app-header > .header')
                    .should('contain.text', StartedActivitiesCount)
            })

        cy.log('Validating completed activities count')
            .wait('@getCompletedCount').then((xhr) => {
                const CompletedActivitiesCount = xhr.response.body.leaf_count
                cy.log('Number of Completed Activities ->', CompletedActivitiesCount)
                    .get(':nth-child(3) > app-header > .header')
                    .should('contain.text', CompletedActivitiesCount)
            })
    });

    it('Should validate all Activity card Tools', () => {

        cy.log('Validating main project column names')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.NOT_STARTED).click()
        cy.wait(2000)
            .findByDataCy('history').should('exist')
            .findByDataCy('attachments').should('exist')
            .findByDataCy('sur').should('exist')
            .findByDataCy('inspection').should('exist')
            .findByDataCy('rfi').should('exist')
            .findByDataCy('material_allocation').should('exist')
            .findByDataCy('resource_allocation').should('exist')
            .findByDataCy('comments').should('exist')

        cy.log('Validating activity card tools in detail page')
            .clickElement('history')
            .wait('@getActivityHistory').its('status').should('eq', 200)
            .get('.mat-button-wrapper > .history-icon').should('exist')
            .get('.mat-button-wrapper > .attachments-icon').should('exist')
            .get('.mat-button-wrapper > .sur-icon').should('exist')
            .get('.mat-button-wrapper > .inspection-icon').should('exist')
            .get('.mat-button-wrapper > .rfi-icon').should('exist')
            .get('.mat-button-wrapper > .material-allocation-icon').should('exist')
            .get('.action-panel-button > .resource-allocation-icon').should('exist')
            .get('.mat-button-wrapper > .comments-icon').should('exist')
    });

    it('Should select Task and then validate History of same', () => {

        cy.log('Validating completed task history')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.COMPLETED).click()
            .wait(2000)
            .clickElement('history')
            .wait('@getActivityHistory').its('status').should('eq', 200)

        cy.log('History page')
            .get('.close-tab').should('contain.text', 'Action Panel - Task History')
            .get('.close-label').should('exist')
            .get(':nth-child(1) > .col-12 > .user-time > .user-details')
            .should('contain.text', `${loggedInUser.name}`)
            .get(':nth-child(1) > .col-12').should('contain.text', 'Created new project task')
            .get(':nth-child(2) > .col-12').should('contain.text', 'Status changed from Not Started to Started')
            .get(':nth-child(3) > .col-12').should('contain.text', 'Status changed from Started to Completed')
    });

    it('Should select Task then add and delete attchements to it', () => {

        cy.server().route('GET', '/cna/V1/project/**/documents/').as('getTaskDocs')
        cy.server().route('POST', '/file_management/s3/upload_info').as('uploadFile')
        cy.server().route('POST', '/scheduler/task_attachments/**/scheduler_task').as('uploadSchedulerTask')
        cy.server().route('GET', '/scheduler/task_attachments/**/scheduler_task').as('getSchedulerTask')
        cy.server().route('DELETE', '/scheduler/task_attachments/**/**/**').as('deleteAttaches')
        cy.server().route('GET', '/cna/V1/project/**/documents?path=/home/Scheduler_TaskBoard').as('getDocsBoard')


        cy.log('Clicking on attach button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.STARTED).click()
            .wait(2000)
            .clickElement('attachments')
            .get('.close-tab').should('contain.text', 'Action Panel - Attachments')
            .get('.close-label').should('exist')
            .get('.file-list-content').should('contain.text', 'No Files Selected')


        const yourFixturePath = 'Cypress.pdf';
        cy.log('Attaching file from local')
        cy.findByText('Add Attachments').click()
            .wait('@getTaskDocs').its('status').should('eq', 200)
        cy.findByText('From Local').click()
            .get('#up').attachFile(yourFixturePath, { force: true })
            .wait('@uploadFile').its('status').should('eq', 200)
        cy.findByText('Add').click()
            .wait('@uploadSchedulerTask').its('status').should('eq', 201)
            .wait('@getSchedulerTask').its('status').should('eq', 200)
        deleteAttachedFile()


        cy.log('Attaching file from Documents')
        cy.findByText('Add Attachments').click()
            .wait('@getTaskDocs').its('status').should('eq', 200)
            .wait('@getDocsBoard').its('status').should('eq', 200)
        cy.get('.ui-tabview-nav').contains('Documents').click()
            .get('.ui-tree-toggler').click()
        cy.findByText(schedulerConstants.UPLOAD_DOC).click({ force: true })
        cy.findByText('Add').click()
            .wait('@uploadSchedulerTask').its('status').should('eq', 201)
            .wait('@getSchedulerTask').its('status').should('eq', 200)
            .get('.close-label').click()
            .clickElement('attachments')
        deleteAttachedFile()


        cy.log('Attaching file from Documents')
        cy.findByText('Add Attachments').click()
            .wait('@getTaskDocs').its('status').should('eq', 200)
            .wait('@getDocsBoard').its('status').should('eq', 200)
            .get('.ui-tabview-nav').contains('Albums').click()
            .get(':nth-child(1) > .icon-check-box > .ng-fa-icon > .svg-inline--fa > path').click()
        cy.findByText('Add').click()
            .wait('@getSchedulerTask').its('status').should('eq', 200)
            .wait(2000)
            .get('.close-label').click()
            .clickElement('attachments')
        deleteAttachedFile()
    });

    it('Should Raise and delete Schedule Update Request to Task', () => {

        cy.server().route('GET', '/scheduler/project_scheduler/scheduler_meta_data/**').as('getSURform')
        cy.server().route('DELETE', '/scheduler/sur/**/**').as('deleteSUR')
        cy.server().route('GET', '/scheduler/calendar/**/**').as('getSURsCal')

        cy.log('Clicking on SUR button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.STARTED2).click()
            .wait(2000)
            .clickElement('sur')
            .get('.close-tab').should('contain.text', 'Action Panel - Schedule Update Request')
            .get('.close-label').should('exist')
            .get('.table-content').should('contain.text', 'No SURs to list')
            .get('.footer').contains('Raise SUR').should('exist')

        cy.log('Validating SUR form fields')
            .get('.footer').contains('Raise SUR').click()
            .wait('@getSURform').its('status').should('eq', 200)
            .get('#task-start-date').should('exist')
            .get('#update-duration').should('exist')
            .get('#task-end-date').should('exist')
            .get('.reason').should('exist')
            .get('.default-cancel-button').should('exist')
            .get('.mat-raised-button').should('be.disabled')

        cy.log('Raising new SUR')
            .get('#task-start-date').click()
            .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_month_cont > .dhtmlxcalendar_line > .dhtmlxcalendar_cell > .dhtmlxcalendar_month_arrow_left').click()
            .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_dates_cont > :nth-child(3) > :nth-child(7) > .dhtmlxcalendar_label').click()
            .get('.error-label').should('contain.text', 'updated date cant be lesser than planned start date')
            .get('#task-start-date').click()
            .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_month_cont > .dhtmlxcalendar_line > .dhtmlxcalendar_cell > .dhtmlxcalendar_month_arrow_right').click()
            .get('.dhtmlxcalendar_in_input > :nth-child(1) > .dhtmlxcalendar_dates_cont > :nth-child(3) > :nth-child(7) > .dhtmlxcalendar_label').click()

            .get(':nth-child(5) > .col > .row > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()
        cy.findByText('Katerra cypress Automation').click()

            .get(':nth-child(6) > .col > :nth-child(1) > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()
        cy.findByText('Shortage of Labor').click()
            .get(':nth-child(6) > .col > :nth-child(1) > .col-9 > .sur-reason-custom-select > .ng-select-container > .ng-arrow-wrapper').click()

            .get('.reason').type('Hey there its SUR !!')
            .get('.mat-raised-button').click()
            .wait('@getSURform').its('status').should('eq', 200)
            .wait('@getSURsCal').its('status').should('eq', 200)
            .wait('@getSURsCal')
            .wait(3000)

        cy.log('Deleting Raised SUR')
            .get('.ui-table-thead > .ng-star-inserted > :nth-child(2)')
            .should('contain.text', 'Raised By')
            .get('.ui-table-thead > .ng-star-inserted > :nth-child(3)')
            .should('contain.text', 'Status')
            .get('.trash-icon > .ng-fa-icon > .svg-inline--fa > path').click()
            .get('.discard-modal-header').should('contain.text', 'Are You Sure?')
            .get('.modal-title').should('contain.text', 'Are you sure you want to delete the schedule update request raised?')
            .get('.modal-body').should('contain.text', 'Yes')
            .get('.modal-body').should('contain.text', 'No')
            .get('.modal-body').contains('Yes').click()
            .wait('@deleteSUR').its('status').should('eq', 200)
            .get('.close-label').click()
    });

    it('Should Add and delete inspection to Task', () => {

        cy.server().route('GET', '/cmb/V1/inspection-template').as('loadAllTemplates')
        cy.server().route('POST', '/scheduler/task_inspection/bulk_inspection').as('updateInspections')
        cy.server().route('DELETE', '/scheduler/task_inspection/').as('deleteInspection')
        cy.server().route('GET', '/scheduler/calendar/**/**').as('getCals')

        cy.log('Clicking on Inspection button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.STARTED2).click()
            .wait(2000)
            .clickElement('inspection')
            .get('.close-tab').should('contain.text', 'Action Panel - Inspections')
            .get('.close-label').should('exist')
            .get('.no-files-found > span').should('contain.text', 'No Inspections Added')
        cy.get('.type-dropdown-wrap > :nth-child(3) > .mat-focus-indicator').should('be.disabled')
            .get('.m-1 > .mat-focus-indicator').should('be.disabled')

        cy.log('Adding Inspection')
            .get('.ui-dropdown-trigger-icon').click()
        cy.findByText('All').click()
            .wait('@loadAllTemplates').its('status').should('eq', 200)
            .get('.ui-multiselect-trigger-icon').click()
            .get(':nth-child(1) > .ui-multiselect-item > .ui-chkbox > .ui-chkbox-box').click()
            .get('.type-dropdown-wrap > :nth-child(3) > .mat-focus-indicator').should('be.enabled')
            .get('.type-dropdown-wrap > :nth-child(3) > .mat-focus-indicator').click()
            .wait('@updateInspections').its('status').should('eq', 201)

        cy.log('deleting added inspection')
            .wait('@getCals').its('status').should('eq', 200)
            .get('.ui-chkbox-box').click({ force: true })
            .get('.m-1 > .mat-focus-indicator').should('be.enabled')
            .get('.ui-chkbox-icon').click()
            .get('path').click()
            .wait('@deleteInspection').its('status').should('eq', 201)
            .get('.no-files-found > span').should('contain.text', 'No Inspections Added')
    });

    it('Should Link and UnLink RFIs to Task', () => {

        cy.server().route('POST', '/scheduler/task_rfi_link/link_rfi').as('updateRFIs')
        cy.server().route('DELETE', '/scheduler/task_rfi_link/delete_link/**/**').as('UnLinkRFI')

        cy.log('Clicking on RFI button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.NOT_STARTED2).click()
            .wait(2000)
            .clickElement('rfi')
            .get('.close-tab').should('contain.text', 'Action Panel - RFIs')
            .get('.close-label').should('exist')
            .get('.m-1 > .mat-focus-indicator').should('be.enabled')

        cy.log('Linking RFI')
            .get('[bindlabel="user_defined_id"] > .ng-select-container > .ng-arrow-wrapper').click()
        cy.findByText(schedulerConstants.LINK_RFI).click()
            .get('.action-panel-content-wrapper').should('contain.text', 'RFI ID')
            .get('.action-panel-content-wrapper').should('contain.text', 'Subject')
            .get('.action-panel-content-wrapper').should('contain.text', 'Status')
            .get('.action-panel-content-wrapper').should('contain.text', 'Due-Date')
            .get('.action-panel-content-wrapper').should('contain.text', 'Assignee')
        cy.findByText('Link RFI').click()
            .wait('@updateRFIs').its('status').should('eq', 201)

        cy.log('UnLinking RFI')
        cy.findByText('UnLink').click()
            .wait('@UnLinkRFI').its('status').should('eq', 201)
    });

    it('Should Allocate and delete material in Task', () => {

        cy.server().route('GET', '/scheduler/project_bom?page=1&limit=20&project_id=**').as('getPBOMs')

        cy.log('Clicking on material allocation button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.NOT_STARTED2).click()
            .wait(2000)
            .clickElement('material_allocation')
            .get('.close-tab').should('contain.text', 'Action Panel - Material Allocation')
            .get('.close-label').should('exist')
            .get('.m-1 > .mat-focus-indicator').should('be.enabled')
            .get('.material-allocation').should('contain.text', 'No Materials Have been Allocated yet.')

        cy.log('Allocating material')
            .get('.footer').contains('Allocate Materials').click()
            .wait('@getPBOMs').its('status').should('eq', 200)
            .get('.highlighted-tab').should('contain.text', 'Choose Materials')
            .get('.search-box').should('exist')
            .get('.default-cancel-button').should('exist')
            .get('.default-button').should('exist')
            .get(':nth-child(1) > :nth-child(1) > [data-cy=checkbox] > .ui-chkbox > .ui-chkbox-box').click({ force: true })
            .get('.default-button').click()

        cy.log('Deleting Allocated material')
            .get('.highlighted-tab').should('contain.text', 'Confirmation')
            .get('.mat-raised-button').should('exist')
            .get('.trash-td').click()
            .get('.no-material').should('contain.text', 'No Materials Have been Allocated yet.')
            .get('.default-cancel-button').click()
            .get('.close-label').click()
    });

    it('Should Allocate Resource in Task', () => {

        cy.server().route('GET', '/scheduler/project_resource_config/fields/**').as('getResourceFields')
        cy.server().route('GET', '/scheduler/resource_master?page=1&limit=20').as('getResourceMasterRecords')
        cy.server().route('POST', '/scheduler/resource_master').as('getResourcesMaster')
        cy.server().route('POST', '/scheduler/project_resource').as('getprojectResources')
        cy.server().route('GET', '/scheduler/project_resource?page=1&limit=20&project_id=**').as('getAddedResources')
        cy.server().route('GET', '/scheduler/resource_master?page=1.05&limit=20').as('getResourceList')
        cy.server().route('GET', '/scheduler/resource_master?search_term=***&category=name&page=1&limit=20').as('getSearchResult')
        cy.server().route('PUT', '/scheduler/resource_allocation/**/**').as('getResourceError')
        cy.server().route('GET', '/scheduler/resource_allocation/609cbc6401dc7000742db382/**').as('AllocateResource')


        cy.log('Creating new Resource')
            .getRandomString().then(ResourceName => {
                addResourceMaster(ResourceName)
                resourceMasterName = ResourceName

                cy.log('Adding resource to project')
                    .get('.ap-down-arrow').click()
                    .get('.ap-project-search > .ap-text-sm').type(schedulerConstants.SCHEDULER_TASKBOARD_PROJECT)
                    .get('.ap-project-item').click()
                    .wait('@getTenantMembers').its('status').should('eq', 200)

                    .clickElement('Scheduler')
                    .clickElement('Resources')

                    .wait('@getAddedResources')
                    .clickElement('addMaterial')
                    .clickElement('addResource')
                    .wait('@getResourceList').its('status').should('eq', 200)
                    .get('.modal-header').should('contain.text', 'Add Resources')
                    .get('.header-wrapper > .search-wrapper > .search-box')
                    .type(resourceMasterName)
                    .wait('@getSearchResult').its('status').should('eq', 200)
                    .get('app-table.ng-star-inserted > [data-cy=table] > [data-cy=p-treeTable] > .ui-treetable > .ui-treetable-scrollable-wrapper > .ui-treetable-scrollable-view > .ui-treetable-scrollable-header > .ui-treetable-scrollable-header-box > .ui-treetable-scrollable-header-table > .ui-treetable-thead > [data-cy=headerrow] > [style="min-width: 100px;"] > .ng-star-inserted > .ui-chkbox > .ui-chkbox-box').click()
                    .get('.end-button-group > .mat-focus-indicator').click()
                    .get('.end-button-group > .mat-focus-indicator').click()
                    .wait('@getprojectResources').its('status').should('eq', 200)

                    .clickElement('Scheduler')
                    .clickElement('Task Board')

                cy.log('Clicking on Resource allocation button')
                    .wait('@getTaskStatus').its('status').should('eq', 200)
                cy.findByText(schedulerConstants.NOT_STARTED3).click()
                    .wait(2000)
                    .clickElement('resource_allocation')
                    .wait('@getResourceFields').its('status').should('eq', 200)
                    .get('.close-tab').should('contain.text', 'Action Panel - Resource Allocation')
                    .get('.close-label').should('exist')

                cy.log('Allocating Resource')
                    .get('.footer').contains('Allocate Resources').click()
                    .get('.form-control').should('exist')
                    .get('.form-control').type(resourceMasterName)
                    .get('.ui-chkbox-box').click()
                    .get('.footer').contains('Next').click()
                    .get('.footer').contains('Allocate').click()
                    .wait('@AllocateResource').its('status').should('eq', 200)
                    .wait('@getResourceError').its('status').should('eq', 400)
                    .get('.close-label').click()
            })
    });

    it('Should Add Comment to task', () => {

        cy.server().route('POST', '/scheduler/comment/scheduler_task/**').as('updateComment')
        cy.server().route('GET', '/scheduler/comment/scheduler_task/**').as('getcommentList')

        cy.log('Clicking on button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.findByText(schedulerConstants.STARTED2).click()
            .wait(2000)
            .clickElement('comments')
            .get('.close-tab').should('contain.text', 'Action Panel - Comments')
            .get('.close-label').should('exist')
            .get('#input-comment').should('exist')
            .get('.send-comment-button').should('exist')

        cy.log('Adding comment')
            .get('#input-comment').type(schedulerConstants.TASK_COMMENT)
            .get('.send-comment-button').click()
            .wait('@updateComment').its('status').should('eq', 201)
            .wait('@getcommentList').its('status').should('eq', 200)
            .get('.close-label').click()
    });

    it.skip('Should move task to started and completed columns then validate counts', () => {

        cy.log('Clicking on button')
            .wait('@getTaskStatus').its('status').should('eq', 200)
        cy.get('app-card.ng-tns-c335-11 > [data-cy=eachtask]').drag('.middle-board > .single-board')
    });

    it('Should validate filter fields and perform action on it', () => {

        cy.log('Validating all filter fields')
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .clickElement('filterIcon')
            .get('.filter-container').should('contain.text', 'Activity Code Filter')
            .get('.filter-container').should('contain.text', 'Tag Filter')
            .get('.filter-container').should('contain.text', 'Assignee')
            .get('.filter-container').should('contain.text', 'Date Filter')
            .get('.filter-container').should('contain.text', 'More Filters')
            .get('[icon="pi pi-refresh"]').should('exist')
            .get('[icon="pi pi-check"]').should('exist')

        cy.log('Filtering critical activities')
        cy.findByText('More Filters').click()
            .get(':nth-child(1) > .ng-untouched > .ui-chkbox > .ui-chkbox-box').click()
            .get('[icon="pi pi-check"]').click()
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .get(':nth-child(3) > .single-board').should('contain.text', 'Concrete')
            .get('[icon="pi pi-refresh"]').click()
            .wait('@getTaskStatus').its('status').should('eq', 200)

        cy.log('Filtering Non-critical activities')
        cy.findByText('More Filters').click({ force: true })
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .get(':nth-child(2) > .ng-untouched > .ui-chkbox > .ui-chkbox-box').click({ force: true })
            .get('[icon="pi pi-check"]').click({ force: true })

            .get('.middle-board > .single-board').should('contain.text', 'Excavation')
            .get('[icon="pi pi-refresh"]').click({ force: true })
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .get('[data-cy=filterIcon]').click({ force: true })
    });

    it('Should perform creating and deleting custome view  ', () => {

        cy.server().route('GET', '/cmb/activity_code').as('getActivityCodes')

        cy.log('Adding new custom view')
            .wait('@getTaskStatus').its('status').should('eq', 200)
            .get('.view-name').click()
            .get('.create-view > .view-name').click()
            .wait('@getActivityCodes').its('status').should('eq', 200)
            .get('.modal-heading').should('contain.text', 'Create Custom View')
            .get('#customViewName').should('exist')
            .get('.search-section > input').should('exist')
            .get('.close').should('exist')

        cy.log('Validating save button')
            .get('.modal-body').contains('Save').should('be.disabled')
            .get('#customViewName').type('Custom view')
            .get('.modal-body').contains('Save').should('be.enabled')
            .get('.close').click()
    });

})

const deleteAttachedFile = function () {

    cy.log('Deleting attached file')
        .wait(3000)
        .get(':nth-child(3) > .file > .ng-fa-icon > .svg-inline--fa > path')
        .click({ force: true })
        .wait('@deleteAttaches')
        .get('.file-list-content').should('contain.text', 'No Files Selected')

}

const addResourceMaster = function (ResourceName) {
    cy.getRandomString().then(resourcecCode => {
        cy.log('Adding new Resource')
            .visitPage('https://dev.app.dev-apollo.com/cs/resource-master')
            .wait('@getResourceMasterRecords').its('status').should('eq', 200)
            .clickElement('addMaterial')
            .clickElement('addRow')
            .get(':nth-child(2) > .row-edit-input').clear()
            .get(':nth-child(2) > .row-edit-input').type(resourcecCode)
            .get(':nth-child(3) > .row-edit-input').clear()
            .get(':nth-child(3) > .row-edit-input').type(ResourceName)
            .get('.ng-arrow-wrapper').click()
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .get('#hoursId').clear()
            .get('#hoursId').type('2')
            .get(':nth-child(6) > .row-edit-input').clear()
            .get(':nth-child(6) > .row-edit-input').type('2{enter}')
            .wait('@getResourcesMaster').its('status').should('eq', 201)
            .get('.contentDiv').should('contain.text', 'New Resource is Added')
    })
}