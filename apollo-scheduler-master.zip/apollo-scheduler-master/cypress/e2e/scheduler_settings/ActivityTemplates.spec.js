const ActivityTemplatesConstants = require('../../support/constants')


describe('Scheduler Activity Templates', () => {

    beforeEach(() => {

        cy.server().route('GET', '/scheduler/activity_template/published').as('getActivityTemplates')
        cy.server().route('POST', '/scheduler/activity_template').as('createActivityTemplate')
        cy.visitPage('/cs/activity-templates')

    })

    it('Should verify activity template landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getActivityTemplates').its('status').should('eq', 200)
            .get('a.ui-sidebar-close').should('exist').click()
            .findByDataCy('edit').should('exist')
            .findByDataCy('addnew').should('exist')
            .findByDataCy('viewTemplate').should('exist')
            .findByDataCy('time').should('exist')
            .findByDataCy('clearselect').should('exist')
            .findByDataCy('zoom').should('exist')
    });
    it('Should able to create new template', () => {

        cy.log('Verifying landing page fields')
            .wait('@getActivityTemplates').its('status').should('eq', 200)
            .get('a.ui-sidebar-close').should('exist').click()
            .clickElement('addnew')
        cy.getRandomString().then((randomTemplateName) => {
            cy.get('h4.modal-heading').should('contain.text', ' Create New Template')
                .get('div.modal-label.name').should('contain.text', ' Template Name')
                .get('div.description .modal-label').should('contain.text', 'Template Description')
                .get('[placeholder="Enter Template Name"]').type(randomTemplateName)
                .get('[placeholder="Enter Template Description"]').type('template description')
                .get('button[type="submit"]').click()
                .wait('@createActivityTemplate').its('status').should('eq', 201)
        })

    });
})
