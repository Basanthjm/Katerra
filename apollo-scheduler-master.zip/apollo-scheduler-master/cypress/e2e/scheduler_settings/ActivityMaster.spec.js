const ActivityMasterConstants = require('../../support/constants')
let activityCode = "cypress"

describe('Scheduler Activity Master', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/activity_master?limit=10&page=1').as('getActivityMaster')
        cy.server().route('POST', '/cmb/activity_master').as('createActivity')
        cy.server().route('DELETE', '/cmb/activity_master/bulk').as('deleteActivity')
        cy.server().route('PATCH', '/cmb/activity_master/**').as('editActivity')
        cy.visitPage('/cs/activity-master/list')

    })

    it('Should verify activity master landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getActivityMaster').its('status').should('eq', 200)
            .findByDataCy('search').should('exist')
            .findByDataCy('fileUpload').should('exist')
            .findByDataCy('download').should('exist')
            .findByDataCy('create').should('exist')
            .findByDataCy('trash').should('exist')
            .findByDataCy('more').should('exist')
            .findByDataCy('count').should('exist')
    });
    it('Should validate counts of activities', () => {

        cy.log('Verifying all activities counts')
            .wait('@getActivityMaster').then((xhr) => {
                const activitiesCount = xhr.response.body.data.total_activities
                cy.log('number of activities->', activitiesCount)
                    .findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
            })

    });
    it('Should search for Non-existing activity and validate count', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.getRandomString().then((randomActivity) => {
            cy.server().route('GET', '/cmb/activity_master?limit=10&page=1&search_term=' + randomActivity).as('getSearchActivity')

            cy.log('search non existing activities')
            cy.enterText('search', randomActivity)
                .wait('@getSearchActivity').then((xhr) => {
                    const activitiesCount = xhr.response.body.data.total_activities
                    cy.findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
                })
        })
    });
    it('Should verify sucess button enabled after adding required fields while creating new activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.getRandomString().then((randomActivity) => {
            cy.clickElement('create')
                .findByDataCy('success').should('be.disabled')
                .findByDataCy('cancel').should('be.enabled')
                .enterText('data', randomActivity)
                .enterText('activityNameInput', randomActivity)
                .findByDataCy('success').should('be.enabled')


        })
    });
    it('Should able to create new activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.getRandomString().then((randomActivity) => {
            activityCode = randomActivity + '_code'
            cy.clickElement('create')
                .findByDataCy('success').should('be.disabled')
                .findByDataCy('cancel').should('be.enabled')
                .enterText('data', activityCode)
                .clickElement('createNewActivity')
                .get('app-popup .modal-heading').should('contain.text', 'Select Cost Code')
                .get('app-popup [role="checkbox"]').then((checkbox) => {
                    checkbox[2].click()
                })
            cy.clickElement('save')
                .enterText('activityNameInput', randomActivity)
                .enterText('inputUom', 'randomActivity')
                .clickElement('success')
                .wait('@createActivity').its('status').should('eq', 201)

        })
    });
    it('Should search for created activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.server().route('GET', '/cmb/activity_master?limit=10&page=1&search_term=' + activityCode).as('getSearchActivity')
        cy.log('search created activity')
        cy.enterText('search', activityCode)
            .wait('@getSearchActivity').then((xhr) => {
                const activitiesCount = xhr.response.body.data.total_activities
                cy.findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
            })

    });
    it('Should able to add sub activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.server().route('GET', '/cmb/activity_master?limit=10&page=1&search_term=' + activityCode).as('getSearchActivity')
        cy.log('search created activity')
        cy.enterText('search', activityCode)
            .wait('@getSearchActivity').then((xhr) => {
                const activitiesCount = xhr.response.body.data.total_activities
                cy.findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
                    .clickElement('plus')


            })

    });
    it('Should able to edit created activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.server().route('GET', '/cmb/activity_master?limit=10&page=1&search_term=' + activityCode).as('getSearchActivity')
        cy.log('search created activity')
        cy.enterText('search', activityCode)
            .wait('@getSearchActivity').then((xhr) => {
                const activitiesCount = xhr.response.body.data.total_activities
                activityCode = activityCode + '_edit'
                cy.findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
                    .clickElement('edit')
                    .enterText('data', "_edit")
                    .clickElement('createNewActivity')
                    .get('app-popup .modal-heading').should('contain.text', 'Select Cost Code')
                    .get('app-popup [role="checkbox"]').then((checkbox) => {
                        checkbox[3].click()
                    })
                cy.clickElement('save')
                    .enterText('activityNameInput', "_edit")
                    .enterText('inputUom', 'randomActivity')
                    .clickElement('success')
                    .wait('@editActivity').its('status').should('eq', 200)

            })

    });
    it('Should able to delete created activity', () => {

        cy.wait('@getActivityMaster').its('status').should('eq', 200)
        cy.server().route('GET', '/cmb/activity_master?limit=10&page=1&search_term=' + activityCode).as('getSearchActivity')
        cy.log('search created activity')
        cy.enterText('search', activityCode)
            .wait('@getSearchActivity').then((xhr) => {
                const activitiesCount = xhr.response.body.data.total_activities
                cy.findByDataCy('count').should('contain.text', ' Total : ' + activitiesCount + ' Activities. ')
                    .clickElement('checkbox')
                    .clickElement('trash')
                    .get('div.ui-confirmdialog').should('exist')
                    .get('span.ui-dialog-title').should('contain.text', 'Confirmation')
                    .get('span.ui-confirmdialog-message').should('contain.text', 'Are you sure that you want to delete?')
                    .get('[ng-reflect-label="Yes"]').should('exist').click()
                    .wait('@deleteActivity').its('status').should('eq', 200)
            })

    });
})
