import '../../support/setup-tests'

let newSUR_Reasons
let newResource_Type

describe('Scheduler configurations', () => {

    beforeEach(() => {
        cy.server().route('GET', '/cmb/V1/configurations').as('getConfigs')
        cy.server().route('PATCH', '/cmb/V1/configurations/sur').as('updateSUR')
        cy.visitPage('https://dev.app.dev-apollo.com/cs/config/list')

    })

    it('Should verify configuration landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getConfigs').its('status').should('eq', 200)
            .get('.content-header').should('contain.text', 'Configuration')
            .get('#ui-tabpanel-0-label').should('contain.text', 'SUR')
            .get('#ui-tabpanel-1-label').should('contain.text', 'Resource Master')
    });

    it('Should Add,Search,Edit and delete SUR-Reasons type configurations', () => {

        cy.getRandomString().then(SUR_Reasons => {

            cy.log('Adding new Reason Type configuration')
                .wait('@getConfigs').its('status').should('eq', 200)
                .get('#ui-tabpanel-0 > .main-section > .reasonDiv > :nth-child(1)')
                .should('contain.text', 'Reasons')
                .get('.main-div').contains('Add').click()
                .enterText('surReason', SUR_Reasons)
                .clickElement('saveRecord')
                .wait('@updateSUR').its('status').should('eq', 200)

            newSUR_Reasons = SUR_Reasons

            cy.log('Searching SUR Reason configuration')
            cy.findByPlaceholderText('Search Reason')
                .type(newSUR_Reasons)
                .get('#surList')
                .should('contain.text', newSUR_Reasons)

            cy.log('Editing SUR Reason configuration')
            cy.get('#surList')
                .contains(newSUR_Reasons).trigger('mouseover')
            cy.wait(2000)
                .findByDataCy('startEdit')
                .click({ force: true })
                .findByDataCy('surReason')
                .clear()
            cy.findByPlaceholderText('Enter SUR Reason')
                .type('Non ' + newSUR_Reasons)
                .get('.edit-options > .ng-star-inserted > [data-cy=save]')
                .click()
                .wait('@updateSUR').its('status')
                .should('eq', 200)

            // cy.log('Deleting RFI Type configuration')
            // cy.findByPlaceholderText('Search Reason')
            //     .clear()
            // cy.findByPlaceholderText('Search Reason')
            //     .type('Non ' + newSUR_Reasons)
            //     .get(':nth-child(2) > [data-layer="Content"]')
            //     .click({ force: true })

        })
    })

    it('Should Add,Search,Edit and delete Resource type configurations', () => {

        cy.server().route('PATCH', '/cmb/V1/configurations/resource').as('updateResource')

        cy.getRandomString().then(Resource_Type => {

            cy.log('Adding new Resource type configuration')
                .wait('@getConfigs').its('status').should('eq', 200)
                .get('#ui-tabpanel-1-label > .ui-tabview-title').click()
                .get('#ui-tabpanel-1 > .main-section > .reasonDiv > :nth-child(1)')
                .should('contain.text', 'Resource Type')
                .get('#ui-tabpanel-1 > .main-section').contains('Add').click()
            cy.findByPlaceholderText('Enter Resource Type')
                .type(Resource_Type)
                .get('[data-cy=save] > .ui-button-text').click()
                .wait('@updateResource').its('status').should('eq', 200)

            newResource_Type = Resource_Type

            cy.log('Searching Resource configuration')
            cy.findByPlaceholderText('Search Resource Type')
                .type(newResource_Type)
            cy.get('#resourceList')
                .should('contain.text', newResource_Type)

            cy.log('Editing Resource configuration')
            cy.get('#resourceList')
                .contains(newResource_Type).trigger('mouseover')
            cy.wait(2000)
                .findByDataCy('edit')
                .click({ force: true })
            cy.findByPlaceholderText('Enter Resource Type')
                .clear()
            cy.findByPlaceholderText('Enter Resource Type')
                .type('Non ' +newResource_Type)
                .get('.edit-options > .ng-star-inserted > [data-cy=save]')
                .click()
                .wait('@updateResource').its('status')
                .should('eq', 200)

            // cy.log('Deleting Resource Type configuration')
            // cy.findByPlaceholderText('Search Reason')
            //     .clear()
            // cy.findByPlaceholderText('Search Reason')
            //     .type('Non ' + newSUR_Reasons)
            //     .get(':nth-child(2) > [data-layer="Content"]')
            //     .click({ force: true })

        })
    })
})