const ActivityTemplatesConstants = require('../../support/constants')
let mainTag
let subTag


describe('Scheduler Activity Templates', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/activity_code').as('getActivityTags')
        cy.server().route('POST', '/cmb/activity_code').as('createActivityTags')
        cy.server().route('GET', '/cmb/activity_code/**').as('getActivityTagsDetails')
        cy.server().route('PUT', '/cmb/activity_code/**').as('updateActivityTags')
        cy.server().route('DELETE', '/cmb/activity_code/**').as('deleteActivity')
        cy.visitPage('cs/tags/list')

    })

    it('Should verify tags landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .findByDataCy('add').should('exist')
            .get('[placeholder="Search Tag"]').should('exist')
            .findByDataCy('more').should('exist')
    });
    it('Should able to create new tag', () => {

        cy.log('Creating new tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .clickElement('add')
        cy.getRandomString().then((randomTagName) => {
            cy.get('.ng-star-inserted > .ng-pristine').type(randomTagName)
                .get('[src="assets/icons/TickBlue.svg"]').click()
                .wait('@createActivityTags').its('status').should('eq', 200)
            mainTag = randomTagName
        })

    });
    it('Should search for created tag', () => {
        cy.log('Searching for created tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .get('[placeholder="Search Tag"]').type(mainTag)
            .get('app-name-cell-renderer .ng-star-inserted').should('contain.text', ' ' + mainTag.toUpperCase() + ' ')

    });
    it('Should able to add new sub tag under created tag', () => {
        cy.log('Searching for created tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .get('[placeholder="Search Tag"]').type(mainTag)
            .get('app-name-cell-renderer .ng-star-inserted').should('contain.text', ' ' + mainTag.toUpperCase() + ' ')
            .get('app-name-cell-renderer .ng-star-inserted').click()
            .wait('@getActivityTagsDetails').its('status').should('eq', 200)
            .get(':nth-child(1) > [style="width: 40px;"] > .fa').click()
        cy.getRandomString().then((randomTagName) => {
            cy.get('.ng-star-inserted  .ng-pristine').type(randomTagName)
                .get('i.tick-icon').click()
                .wait('@createActivityTags').its('status').should('eq', 200)
            subTag = randomTagName
        })


    });
    it('Should search for created sub tag', () => {
        cy.log('Searching for created sub tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .get('[placeholder="Search Tag"]').type(subTag)
            .get('div.no-data-section span').should('contain.text', ' No Tags Found ')

    });
    it('Should able to edit and delete sub tag', () => {
        cy.log('Searching for created tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .get('[placeholder="Search Tag"]').type(mainTag)
            .get('app-name-cell-renderer .ng-star-inserted').should('contain.text', ' ' + mainTag.toUpperCase() + ' ')
            .get('app-name-cell-renderer .ng-star-inserted').click()
            .wait('@getActivityTagsDetails').its('status').should('eq', 200)
            .get('i.pi-chevron-right').click()
            .get('i.edit-icon').last().click({ force: true })
            .get('.ng-star-inserted  .ng-pristine').type('_edit')
            .get('i.tick-icon').click()
            .wait('@updateActivityTags').its('status').should('eq', 200)
            .get('i.delete-icon').last().click()
            .get('div.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Tag')
            .get('span.ui-confirmdialog-message').should('contain.text', 'Are you sure you want to delete the tag?')
            .clickElement('confirm')
            .wait('@deleteActivity').its('status').should('eq', 200)

    });
    it('Should able to edit and delete created tag', () => {
        cy.log('Searching for created tag')
            .wait('@getActivityTags').its('status').should('eq', 200)
            .get('[placeholder="Search Tag"]').type(mainTag)
            .get('app-name-cell-renderer .ng-star-inserted').should('contain.text', ' ' + mainTag.toUpperCase() + ' ')
            .get('app-name-cell-renderer .ng-star-inserted').click()
            .wait('@getActivityTagsDetails').its('status').should('eq', 200)
            .get('i.edit-icon').click({ force: true })
            .get('.ng-star-inserted  .ng-pristine').type('_edit')
            .get('i.tick-icon').click()
            .wait('@updateActivityTags').its('status').should('eq', 200)
            .get('i.delete-icon').click()
            .get('div.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Tag')
            .get('span.ui-confirmdialog-message').should('contain.text', 'Are you sure you want to delete the tag?')
            .clickElement('confirm')
            .wait('@deleteActivity').its('status').should('eq', 200)

    });
})
