import '../../support/setup-tests'
const materialMasterConstants = require('../../support/constants')

let materialMaster

describe('Material Master', () => {

    beforeEach(() => {
        cy.server().route('GET', '/scheduler/material_master?page=1&limit=20').as('getMaterialMasterList')
        cy.server().route('GET', '/scheduler/material_master/search/materials?search_term=**&category=description&page=1&limit=20').as('getSearch')
        cy.server().route('POST', '/scheduler/material_master').as('getMaterials')
        cy.server().route('PUT', '/scheduler/material_master/**').as('updateMaterials')
        cy.visitPage('https://dev.app.dev-apollo.com/cs/material')
    })

    it('Should validate Material Master landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getMaterialMasterList').its('status').should('eq', 200)
            .get('.title-bar').should('contain.text', 'Material Master')
            .findByDataCy('search').should('exist')
            .findByDataCy('imports').should('exist')
            .clickElement('imports')
            .findByDataCy('downloadCsv').should('exist')
            .findByDataCy('importCsv').should('exist')
            .findByDataCy('createObject').should('exist')
            .findByDataCy('generateReport').should('exist')
            .findByDataCy('export').should('exist')
            .findByDataCy('addMaterial').should('exist')
            .clickElement('addMaterial')
            .findByDataCy('addColumn').should('exist')
            .findByDataCy('addRow').should('exist')
            .findByDataCy('delete').should('exist')

        cy.log('Verifying material master column names')
            .get('[data-cy=headerrow] > .text-left').should('contain.text', 'Description')
            .get('[data-cy=headerrow] > :nth-child(4)').should('contain.text', 'Material Code')
            .get('[data-cy=headerrow] > :nth-child(5)').should('contain.text', 'Unit')
            .get('[data-cy=headerrow] > :nth-child(6)').should('contain.text', 'Quantity')
            .get('[data-cy=headerrow] > :nth-child(7)').should('contain.text', 'Rate')

    })

    it('Should validate Material Master total Records', () => {

        cy.wait('@getMaterialMasterList').then((xhr) => {
            const materialMasterCount = xhr.response.body.total_materials
            cy.log('Materil master records ->', materialMasterCount)
            cy.findByText(`${materialMasterCount} Records`).should('exist')
        })

    });

    it('Should add new material(ROW)', () => {

        cy.getRandomString().then(materialDescription => {
            addMeterialMaster(materialDescription)
            materialMaster = materialDescription
        })
    });

    it('Should search and delete material master', () => {

        cy.log('Searching material master')
            .enterText('search', materialMaster)
            .wait('@getSearch').its('status').should('eq', 200)
            .get('[data-cy=bodyrow] > .text-left').should('contain.text', materialMaster)

        deleteMaterialMaster()
    });

    it('Should search non-existing material and validate message', () => {

        cy.log('Searching non exisiting material')
            .wait('@getMaterialMasterList').its('status').should('eq', 200)
            .enterText('search', materialMasterConstants.EMPTY_SEARCH)
            .wait('@getSearch').its('status').should('eq', 404)
            .get('.no-material').should('contain.text', 'No Materials found')
            .findByDataCy('search').clear()
            .wait('@getMaterialMasterList')
    });

    it('Should add new material, Edit and delete it', () => {

        cy.getRandomString().then(materialDescription => {
            addMeterialMaster(materialDescription)

            cy.log('Searching for added material')
                .enterText('search', materialDescription)
                .wait('@getSearch').its('status').should('eq', 200)

            cy.log('Editing maeterial')
            cy.get('[data-cy=bodyrow] > .text-left').rightclick()
            cy.findByText('Edit').click({ force: true })

            cy.getRandomString().then(editDescription => {
                cy.get('.text-left > .row-edit-input').clear()
                    .get('.text-left > .row-edit-input').type(editDescription)
                    .get(':nth-child(4) > .row-edit-input').clear()
                    .get(':nth-child(4) > .row-edit-input').type(editDescription)
                    .get(':nth-child(7) > .row-edit-input').clear()
                    .get(':nth-child(7) > .row-edit-input').type('3{enter}')
                    .wait('@updateMaterials').its('status').should('eq', 200)
                    .get('.contentDiv').should('contain.text', 'Material is successfully updated')

                cy.log('Searching for Edited material')
                    .findByDataCy('search').clear()
                    .enterText('search', editDescription)
                    .wait('@getSearch').its('status').should('eq', 200)

                deleteMaterialMaster()

            })
        })
    });

    it('Should add new material(COLUMN) and delete it', () => {

        cy.server().route('DELETE', '/scheduler/material_master/config/**').as('deleteColumn')
        cy.getRandomString().then(materialDescription => {
            addMeterialMaster(materialDescription)

            cy.log('Adding new material column wise')
                .clickElement('addMaterial')
                .findByDataCy('addColumn').should('exist')
                .findByDataCy('addRow').should('exist')
                .clickElement('addColumn')

            cy.log('Adding column name')
                .get('[data-cy=headerrow] > :nth-child(8)').type('Cost{enter}')

            cy.log('Searching for added material')
                .enterText('search', materialDescription)
                .wait('@getSearch').its('status').should('eq', 200)
                .get('[data-cy=bodyrow] > :nth-child(8)').rightclick()
            cy.findByText('Edit').click({ force: true })
                .get(':nth-child(8) > .row-edit-input').type('200${enter}')
                .wait('@updateMaterials').its('status').should('eq', 200)
                .get('.more-options').click()
            cy.findByText('Delete Column').click({ force: true })
                .wait('@deleteColumn').its('status').should('eq', 200)
        })
    });

    it('Should create material object and delete it', () => {

        cy.getRandomString().then(materialDescription => {
            addMeterialMaster(materialDescription)
            cy.getRandomString().then(materialDescription => {
                cy.getRandomString().then(materialObjectName => {
                    cy.reload()
                    addMeterialMaster(materialDescription)

                    cy.log('Searching for added material')
                        .enterText('search', 'cy')
                        .get('[style="min-width: 100px;"] > .ng-star-inserted > .ui-chkbox > .ui-chkbox-box')
                        .click()
                        .wait('@getSearch').its('status').should('eq', 200)

                    cy.log('Creating new material object')
                        .clickElement('imports')
                        .clickElement('createObject')

                    cy.log('Validating create object table fields')
                        .get('.header > span').should('contain.text', 'Create Object')
                        .get('.data-table').should('contain.text', 'Material Description')
                        .get('.data-table').should('contain.text', 'Code')
                        .get('.data-table').should('contain.text', 'Quantity')
                        .get('.data-table').should('contain.text', 'Unit')

                        .get('.footer').should('contain.text', 'Add Materials')
                        .get('.footer').should('contain.text', 'Cancel')


                    cy.log('Adding object details')
                        .get(':nth-child(2) > :nth-child(1) > .fullwidth-input')
                        .type(materialObjectName)
                        .get(':nth-child(2) > .fullwidth-input')
                        .clear()
                        .type(materialObjectName)
                        .get('.button-group > [ng-reflect-ng-class="[object Object]"]')
                        .click()
                        .wait('@getMaterials').its('status').should('eq', 201)
                        .get('.contentDiv').should('contain.text', 'The Object is Added successfully')

                    cy.log('Searching material master')
                        .findByDataCy('search').clear()
                        .enterText('search', materialObjectName)
                        .wait('@getSearch').its('status').should('eq', 200)
                        .get('[data-cy=bodyrow] > .text-left').should('contain.text', materialObjectName)

                    deleteMaterialMaster()

                    cy.log('deleting all material master')
                        .findByDataCy('search').clear()
                        .enterText('search', 'cy')
                        .wait('@getSearch').its('status').should('eq', 200)

                    deleteMaterialMaster()
                })
            })
        })
    });

    it('Should validate material master template and export records', () => {

        cy.server().route('GET', '/scheduler/material_master/export/csv').as('exportCsv')

        cy.log('Validating material master template')
            .wait('@getMaterialMasterList').its('status').should('eq', 200)
            .clickElement('imports')
            .clickElement('downloadCsv')
            .get('.contentDiv').should('contain.text', 'The material master template has been successfully downloaded')

        cy.log('Exporting material master recodrs')
            .clickElement('export')
            .wait('@exportCsv').its('status').should('eq', 200)
            .get('.contentDiv').should('contain.text', 'The material master has been successfully exported')
    });

    it('Should export Material Demand Report', () => {

        cy.server().route('GET', '/cmb/projects').as('getProjects')
        cy.server().route('GET', '/scheduler/material_allocation/material/allocation/report?project_id_list=***&scale=week').as('getDemandReport')

        cy.log('Exporting material demand report')
            .wait('@getMaterialMasterList').its('status').should('eq', 200)
            .clickElement('imports')
            .clickElement('generateReport')
            .wait('@getProjects').its('status').should('eq', 200)

        cy.log('Validating demand report fields')
            .get('.modal-header').should('contain.text', 'Material Requirement Report - CSV')
            .get('.modal-body').should('contain.text', 'Select Project')
            .get('.modal-body').should('contain.text', 'Select Scale')
            .get('.modal-footer').should('contain.text', 'Cancel')
            .get('.modal-footer').should('contain.text', 'Export')
            .get('.ng-arrow-wrapper').click()
        cy.findByText('Day').should('exist')
        cy.findByText('Week').should('exist')
        cy.findByText('Month').should('exist')

        cy.log('selecting non-existing-project for demand report')
            .get('.search-div > .ng-untouched').type(materialMasterConstants.DEMAND_REPORT_PROJECT1)
            .get('#treeDiv').should('contain.text', 'No records found')

        cy.log('selecting existing-project-project for demand report')
            .get('.search-div > .ng-untouched').clear()
            .get('.search-div > .ng-untouched').type(materialMasterConstants.DEMAND_REPORT_PROJECT2)
            .get('.ui-treenode-label > .ng-star-inserted').click()
            .get('.ng-arrow-wrapper').click()
        cy.findByText('Week').click()
            .get('.modal-footer').contains('Export').click()
            .wait('@getDemandReport').its('status').should('eq', 200)

    });
    
})

const addMeterialMaster = function (materialDescription) {

    cy.log('Adding new material')
        .wait('@getMaterialMasterList').its('status').should('eq', 200)
        .clickElement('addMaterial')
        .clickElement('addRow')
        .get('.text-left > .row-edit-input').clear()
        .get('.text-left > .row-edit-input').type(materialDescription)
        .get(':nth-child(4) > .row-edit-input').clear()
        .get(':nth-child(4) > .row-edit-input').type(materialDescription)
        .get(':nth-child(7) > .row-edit-input').clear()
        .get(':nth-child(7) > .row-edit-input').type('2{enter}')
        .wait('@getMaterials').its('status').should('eq', 201)
        .get('.contentDiv').should('contain.text', 'New Material is Added')
}

const deleteMaterialMaster = function () {

    cy.server().route('DELETE', '/scheduler/material_master/**').as('deleteMaterial')

    cy.log('Deleting material master')
        .get('[style="min-width: 100px;"] > .ng-star-inserted > .ui-chkbox > .ui-chkbox-box').click()
        .clickElement('delete')
        .get('.discard-modal-header').should('contain.text', 'Delete Materials')
        .get('.modal-title').should('contain.text', 'Are you sure you want to delete')
        .get('.modal-body').contains('Confirm').click()
        .wait('@deleteMaterial').its('status').should('eq', 200)
}