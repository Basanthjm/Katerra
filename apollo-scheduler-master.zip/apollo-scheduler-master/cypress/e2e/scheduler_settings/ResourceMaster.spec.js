import '../../support/setup-tests'
const resourceMasterConstants = require('../../support/constants')

let resourceMasterName

describe('Resource Master', () => {

    beforeEach(() => {
        cy.server().route('GET', '/scheduler/resource_master?page=1&limit=20').as('getResourceMasterRecords')
        cy.server().route('GET', '/scheduler/resource_master?search_term=**&category=name&page=1&limit=20').as('getSearch')
        cy.server().route('POST', '/scheduler/resource_master').as('getResources')
        cy.server().route('PUT', '/scheduler/resource_master/**').as('updateResource')
        cy.visitPage('https://dev.app.dev-apollo.com/cs/resource-master')
    })

    it('Should validate Resource Master landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getResourceMasterRecords').its('status').should('eq', 200)
            .get('.title-bar').should('contain.text', 'Resource Master')
            .findByDataCy('search').should('exist')
            .findByDataCy('imports').should('exist')
            .clickElement('imports')
            .findByDataCy('importCsv').should('exist')
            .findByDataCy('ResourceTemplate').should('exist')
            .findByDataCy('resourceAllocationReport').should('exist')
            .findByDataCy('export').should('exist')
            .findByDataCy('addMaterial').should('exist')
            .clickElement('addMaterial')
            .findByDataCy('addColumn').should('exist')
            .findByDataCy('addRow').should('exist')
            .findByDataCy('delete').should('exist')

        cy.log('Verifying material master column names')
            .get('[data-cy=materilTable]').should('contain.text', 'Resource Code')
            .get('[data-cy=materilTable]').should('contain.text', 'Resource Name')
            .get('[data-cy=materilTable]').should('contain.text', 'Type')
            .get('[data-cy=materilTable]').should('contain.text', 'Max. Hrs./Day')
            .get('[data-cy=materilTable]').should('contain.text', 'Rate')
    })

    it('Should validate Resource Master total Records', () => {

        cy.wait('@getResourceMasterRecords').then((xhr) => {
            const resourceMasterCount = xhr.response.body.total_resources
            cy.log('Resource master records ->', resourceMasterCount)
            cy.findByText(`${resourceMasterCount} Records`).should('exist')
        })

    })

    it('Should add new Resource(ROW)', () => {

        cy.getRandomString().then(ResourceName => {
            addResourcecMaster(ResourceName)
            resourceMasterName = ResourceName
        })
    });

    it('Should search and delete Resource master', () => {

        cy.log('Searching Resource master')
            .wait('@getResourceMasterRecords')
            .enterText('search', resourceMasterName)
            .wait('@getSearch').its('status').should('eq', 200)
            .get('[data-cy=bodyrow] > :nth-child(3)').should('contain.text', resourceMasterName)
            //.findByDataCy('search').clear()

        deleteResourceMaster()
    });

    it('Should add new Resource , Edit and delete it', () => {

        cy.getRandomString().then(ResourceName => {
            addResourcecMaster(ResourceName)

            cy.log('Searching for added material')
                .enterText('search', ResourceName)
                .wait('@getSearch').its('status').should('eq', 200)

            cy.log('Editing maeterial')
            cy.get('[data-cy=bodyrow] > :nth-child(2)').rightclick()
            cy.findByText('Edit').click({ force: true })

            cy.getRandomString().then(editResourceCode => {
                cy.get(':nth-child(2) > .row-edit-input').clear()
                    .get(':nth-child(2) > .row-edit-input').type(editResourceCode)
                    .get(':nth-child(3) > .row-edit-input').clear()
                    .get(':nth-child(3) > .row-edit-input').type(editResourceCode)
                    .get('#hoursId').clear()
                    .get('#hoursId').type('3{enter}')
                    .wait('@updateResource').its('status').should('eq', 200)
                    .get('.contentDiv').should('contain.text', 'Resource is successfully updated')

                cy.log('Searching for Edited material')
                    .findByDataCy('search').clear()
                    .enterText('search', editResourceCode)
                    .wait('@getSearch').its('status').should('eq', 200)

                deleteResourceMaster()

            })
        })
    });

    it('Should add new Resource (COLUMN) and delete it', () => {

        cy.server().route('DELETE', '/scheduler/resource_master_config/**').as('deleteColumn')
        cy.getRandomString().then(ResourceName => {
            addResourcecMaster(ResourceName)

            cy.log('Adding new resourcec column wise')
                .clickElement('addMaterial')
                .findByDataCy('addColumn').should('exist')
                .findByDataCy('addRow').should('exist')
                .clickElement('addColumn')

            cy.log('Adding column name')
              .get('[data-cy=headerrow] > :nth-child(7)').type('Cost{enter}')

            cy.log('Searching for added resource')
                .enterText('search', ResourceName)
                .wait('@getSearch').its('status').should('eq', 200)
                .get('[data-cy=bodyrow] > :nth-child(7)').rightclick()
            cy.findByText('Edit').click({ force: true })
                .get(':nth-child(7) > .row-edit-input').type('200${enter}')
                .wait('@updateResource').its('status').should('eq', 200)
                .get('.more-options').click()
            cy.findByText('Delete Column').click({ force: true })
                .wait('@deleteColumn').its('status').should('eq', 200)
        })
    });

    it('Should validate Resource template and export records', () => {

        cy.server().route('GET', '/scheduler/resource_master/export/csv?template').as('exportCsvTemplate')
        cy.server().route('GET', '/scheduler/resource_master/export/csv').as('exportResourceRecords')


        cy.log('Validating material master template')
          .wait('@getResourceMasterRecords').its('status').should('eq', 200)
            .clickElement('imports')
            .clickElement('ResourceTemplate')
            .wait('@exportCsvTemplate').its('status').should('eq', 200)

        cy.log('Exporting material master recodrs')
            .clickElement('export')
            .wait('@exportResourceRecords').its('status').should('eq', 200)
            .get('.contentDiv').should('contain.text', 'The resource master has been successfully exported')
    });

    it('Should Export Resource allocation report', () => {

        cy.server().route('GET', '/cmb/projects').as('getProjects')
        cy.server().route('GET', '/scheduler/resource_allocation/resource/allocation/report?project_id_list=***&scale=week').as('getDemandReport')

        cy.log('Exporting resource alocation report')
        .wait('@getResourceMasterRecords').its('status').should('eq', 200)
            .clickElement('imports')
            .clickElement('resourceAllocationReport')
            .wait('@getProjects').its('status').should('eq', 200)

        cy.log('Validating demand report fields')
            .get('.modal-header').should('contain.text', 'Resource Allocation Report - CSV')
            .get('.modal-body').should('contain.text', 'Select Project')
            .get('.modal-body').should('contain.text', 'Select Scale')
            .get('.modal-footer').should('contain.text', 'Cancel')
            .get('.modal-footer').should('contain.text', 'Export')
            .get('.ng-arrow-wrapper').click()
        cy.findByText('Day').should('exist')
        cy.findByText('Week').should('exist')
        cy.findByText('Month').should('exist')

        cy.log('selecting non-existing-project for demand report')
            .get('.search-div > .ng-untouched').type(resourceMasterConstants.DEMAND_REPORT_PROJECT1)
            .get('#treeDiv').should('contain.text', 'No records found')

        cy.log('selecting existing-project-project for demand report')
            .get('.search-div > .ng-untouched').clear()
            .get('.search-div > .ng-untouched').type(resourceMasterConstants.DEMAND_REPORT_PROJECT2)
            .get('.ui-treenode-label > .ng-star-inserted').click()
            .get('.ng-arrow-wrapper').click()
        cy.findByText('Week').click()
            .get('.modal-footer').contains('Export').click()
            .wait('@getDemandReport').its('status').should('eq', 200)
    });
})

const addResourcecMaster = function (ResourceName) { 
    cy.getRandomString().then(resourcecCode => {
        cy.log('Adding new Resource')
            .wait('@getResourceMasterRecords').its('status').should('eq', 200)
            .clickElement('addMaterial')
            .clickElement('addRow')
            .get(':nth-child(2) > .row-edit-input').clear()
            .get(':nth-child(2) > .row-edit-input').type(resourcecCode)
            .get(':nth-child(3) > .row-edit-input').clear()
            .get(':nth-child(3) > .row-edit-input').type(ResourceName)
            .get('.ng-arrow-wrapper').click()
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .get('#hoursId').clear()
            .get('#hoursId').type('2')
            .get(':nth-child(6) > .row-edit-input').clear()
            .get(':nth-child(6) > .row-edit-input').type('2{enter}')
            .wait('@getResources').its('status').should('eq', 201)
            .get('.contentDiv').should('contain.text', 'New Resource is Added')
    })
}

const deleteResourceMaster = function () {

    cy.server().route('DELETE', '/scheduler/resource_master/**').as('deleteResource')

    cy.log('Deleting Resource master')
        .get('[style="min-width: 100px;"] > .ng-star-inserted > .ui-chkbox > .ui-chkbox-box').click()
        .clickElement('delete')
        .get('.discard-modal-header').should('contain.text', 'Delete Resources')
        .get('.modal-title').should('contain.text', 'Are you sure you want to delete')
        .get('.modal-body').contains('Cancel').should('exist')
        .get('.modal-body').contains('Confirm').click()
        .wait('@deleteResource').its('status').should('eq', 200)
}