import '../../support/setup-tests'
import { getUser } from '../../support/users'

const punchListConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Collaboration Punch List', () => {

    let collabPunchListTittle

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cmb/templates/punchlist').as('getPLTemplates')
        cy.server().route('GET', '/cna/forms/punchlist?project_id=**').as('getPLCounts')
        cy.server().route('GET', '/cna/forms/punchlist?project_id=**').as('getPLCounts')
        cy.server().route('POST', '/cna/reports/**/PUNCHLIST/csv').as('getCSVfile')
        cy.server().route('POST', '/cna/reports/ListPunchlist').as('getPDFfile')
        cy.server().route('POST', '/cna/forms/punchlist/_draft').as('punchListDraft')
        cy.server().route('DELETE', '/cna/forms/punchlist/**/_draft?project_id=**').as('deleteDraft')
        cy.server().route('GET', '/cna/forms/punchlist/**?project_id=**').as('createPunchList')
        cy.server().route('GET', '/cna/V2/project/**/history/PUNCHLIST/**').as('getPLHistory')
        cy.server().route('GET', '/cna/comments/punchitemtask/**').as('getPLTasks')
        cy.server().route('PATCH', '/cna/forms/punchlist/**').as('updatePL')
        cy.server().route('POST', '/cna/comments/punchitemtask/**').as('updateComments')
        cy.server().route('PATCH', '/cna/forms/punchlist/**/plugin/PUNCH_ITEM_TASK/**/CLOSED').as('closeTask')
        cy.server().route('PATCH', '/cna/forms/punchlist/**/state').as('getPLState')
        cy.server().route('DELETE', '/cna/forms/punchlist/**?project_id=**').as('deletePL')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(punchListConstants.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Punch List')

    })

    it('Should verify Punch List landing page and counts', () => {

        cy.log('Verifying all Punch List landing fileds and counts')
            .wait('@getPLCounts').then((xhr) => {
                const punchlistCounts = xhr.response.body.data.count
                cy.log('number of punch lists->', punchlistCounts)
                if (punchlistCounts > 50) {
                    cy.findByText(`1-50 of ${punchlistCounts}`).should('exist')
                }
                else {
                    cy.findByText(`1-${punchlistCounts} of ${punchlistCounts}`).should('exist')
                }

            })

        cy.findByDataCy('all_punch_item').should('exist')
            .findByDataCy('my_punch_item').should('exist')
            .findByDataCy('search').should('exist')
            .findByDataCy('create_punch').should('exist')
            .findByDataCy('export').should('exist')
            .clickElement('export')
            .findByDataCy('csv').should('exist')
            .findByDataCy('pdf').should('exist')
            .findByDataCy('filters').should('exist')

    });

    it('Should check all fields of filter and functionlity of clear All and reset', () => {

        cy.wait('@getPLTemplates').its('status').should('eq', 200)
        cy.log('Checking filter fields')
            .clickElement('filters')
            .findByDataCy('punch_manager').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('priority').should('exist')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('state').should('exist')
            .findByDataCy('created_by').should('exist')
            .findByDataCy('created_at').should('exist')
            .findByDataCy('updated_at').should('exist')
            .findByDataCy('clear-all').should('exist')
            .findByDataCy('reset').should('exist')
            .findByDataCy('apply_filters').should('exist')

        cy.log('Checking Clear All functionlaity')
        fillALLFilters()
        cy.clickElement('clear-all')
            .clickElement('filters')
        fillALLFilters()
        cy.clickElement('reset')
    });

    it('Should check Columns , My punch items and exports pdfs', () => {

        cy.log('Checking punch list Column names')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .get('.ag-header-row > [col-id="punchlist_id"]').should('exist')
            .get('.ag-header-row > [col-id="title"]').should('exist')
            .get('.ag-header-row > [col-id="type"]').should('exist')
            .get('.ag-header-row > [col-id="assignee"]').should('exist')
            .get('.ag-header-row > [col-id="due_date"]').should('exist')
            .get('.ag-header-row > [col-id="priority"]').should('exist')
            .get('.ag-header-row > [col-id="punchlist_manager"]').should('exist')

        cy.log('Checking Export-CSV and Pdf')
            .clickElement('export')
            .clickElement('csv')
            .wait('@getCSVfile').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'CSV created successfully')

            .clickElement('export')
            .clickElement('pdf')
            .wait('@getPDFfile').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'PDF created successfully')

        cy.log('Checking my punch items')
            .clickElement('my_punch_item')
    });

    it('Should check all create punch item fields', () => {

        cy.log('Checking create punch item fields')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .clickElement('create_punch')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .get('.rfiHeader').should('contain.text', 'Create Punch Item')
            .findByDataCy('title').should('exist')
            .findByDataCy('punch_manager').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('location').should('exist')
            .findByDataCy('priority').should('exist')
            .findByDataCy('responsible_contractor').should('exist')
            .findByDataCy('cost_impact').should('exist')
            .findByDataCy('schedule_impact').should('exist')
            .findByDataCy('save_draft').should('exist')
            .findByDataCy('create_punch_item').should('exist')

        cy.log('Checking Distribution list section fields')
            .get('.card-header').contains('Distribution List').should('exist')
            .findByDataCy('add_distribution_list').should('exist')
            .clickElement('add_distribution_list')
            .get('.modal-header').should('contain.text', 'Distribution List')
            .get('.modal-body').should('contain.text', 'Only members who are part of project will be added to Distribution List')
            .findByDataCy('search').should('exist')
            .findByDataCy('cancel').should('exist')
            .findByDataCy('add').should('exist')
            .clickElement('close_dist_modal')

        cy.log('Checking upload file section fields')
            .get('.card-header').contains('Uploaded Files').should('exist')
            .findByDataCy('add_uploaded_files_section').should('exist')
            .clickElement('add_uploaded_files_section')
            .get('.modal-header').should('contain.text', 'Upload File')
            .get('.mat-tab-labels').contains('Local').should('exist')
            .get('.mat-tab-labels').contains('Documents').should('exist')
            .get('.mat-tab-labels').contains('Photos').should('exist')
            .get('.mat-tab-labels').contains('Drawings').should('exist')
            .findByDataCy('upload').should('exist')
            .clickElement('close_attachments_popup')

        cy.log('Checking spec section fields')
            .get('.card-header').contains('Spec Section').should('exist')
            .findByDataCy('add_spec_section').should('exist')
            .clickElement('add_spec_section')
            .get('.modal-header').should('contain.text', 'Specification Section')
            .findByDataCy('close-spec').should('exist')
            .findByDataCy('add-spec').should('exist')
            .clickElement('close')
    });

    it('Should create empty punch list draft and then discarded it', () => {

        cy.log('Verfying mandatory field Error message')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .clickElement('create_punch')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .get('.rfiHeader').should('contain.text', 'Create Punch Item')
            .clickElement('create_punch_item')
            .get('.ui-toast-detail')
            .should('contain.text', 'Please fill all mandatory fields.')

        cy.log('Creating empty draft')
            .clickElement('save_draft')
            .wait('@punchListDraft').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft created.')

        cy.log('Checking status of lunch list')
            .get('.col-xl-12 > .badge').should('contain.text', 'DRAFT')

        cy.log('checking last updated on')
        const todaysDate = Cypress.moment().format('MM/DD/YYYY')
        cy.get('.col-xl-7 > .row > .col-xl-12 > .text-muted').should('contain', 'Last Updated On: ' + todaysDate)

        cy.log('discarded draft')
            .clickElement('discard_draft')
            .wait('@deleteDraft').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft discarded.')
            .wait('@getPLTemplates').its('status').should('eq', 200)
    });

    it('Should create draft by adding all fields then discard it', () => {

        cy.log('Creating punchlist')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .clickElement('create_punch')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .get('.rfiHeader').should('contain.text', 'Create Punch Item')
        cy.getRandomString().then(punchListTittle => {
            cy.findByDataCy('title').type(punchListTittle)

            cy.log('Adding all mandatory fields')
            cy.clickElement('punch_manager')
                .get('[role="option"] span').then(role => {
                    role[0].click()
                })
            cy.clickElement('type')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.clickElement('assignee')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.clickElement('due_date')
            cy.get('.ui-datepicker-today > .ui-state-default')
                .click()
            cy.clickElement('priority')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.enterText('responsible_contractor', punchListConstants.RESPONSIBLE_CONTRACTOR)
                .get('.ql-editor')
                .type(punchListConstants.PUNCHLIST_DESC)
                .clickElement('save_draft')
                .wait('@punchListDraft').its('status').should('eq', 201)
                .get('.ui-toast-detail')
                .should('contain.text', 'Draft created.')
                .wait('@getPLHistory').its('status').should('eq', 200)

            cy.log('Checking status of lunch list')
                .get('.col-xl-12 > .badge').should('contain.text', 'DRAFT')

            cy.log('checking last updated on')
            const todaysDate = Cypress.moment().format('MM/DD/YYYY')
            cy.get('.col-xl-7 > .row > .col-xl-12 > .text-muted').should('contain', 'Last Updated On: ' + todaysDate)

            discardPunchList()
        })
    });

    it('Should create new punch list,search,validate and discard it', () => {

        cy.log('Creating punchlist')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .clickElement('create_punch')
            .wait('@getPLTemplates').its('status').should('eq', 200)
            .get('.rfiHeader').should('contain.text', 'Create Punch Item')
        cy.getRandomString().then(punchListTittle => {
            cy.findByDataCy('title').type(punchListTittle)
            collabPunchListTittle = punchListTittle
            cy.log('Adding all mandatory fields')
            cy.clickElement('punch_manager')
                .get('[role="option"] span').then(role => {
                    role[0].click()
                })
            cy.clickElement('type')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.clickElement('assignee')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.clickElement('due_date')
            cy.get('.ui-datepicker-today > .ui-state-default')
                .click()
            cy.clickElement('priority')
                .get('[role="option"] span').then(role => {
                    role[1].click()
                })
            cy.enterText('responsible_contractor', punchListConstants.RESPONSIBLE_CONTRACTOR)
                .get('.ql-editor')
                .type(punchListConstants.PUNCHLIST_DESC)
                .clickElement('save_draft')
                .wait('@punchListDraft').its('status').should('eq', 201)
                .get('.ui-toast-detail')
                .should('contain.text', 'Draft created.')
                .wait('@getPLHistory').its('status').should('eq', 200)

            cy.log('Searching for created punch list')
                .clickElement('Collaboration')
                .clickElement('Punch List')
                .wait('@getPLTemplates').its('status').should('eq', 200)
                .enterText('search', collabPunchListTittle)
                .get('.ag-center-cols-viewport').should('contain.text', collabPunchListTittle)
            cy.findByText(collabPunchListTittle).click()

            discardPunchList()
        })
    });

    it('Should create new punch list,close,reopen and delete it', () => {

        createPunchList()
        closePunchList()

        cy.log('Reopening closed punch list')
            .findByDataCy('re_open_punch').should('exist')
            .clickElement('re_open_punch')
            .get('.modal-title')
            .should('contain.text', 'Reopen Punch Item')
            .get('.modal-body')
            .should('contain.text', 'Are you sure you want to reopen this punch item?')
            .get('.modal-footer > .btn-primary')
            .click()
            .wait('@getPLState').its('status').should('eq', 200)
            .clickElement('close_punch')
            .wait('@getPLState').its('status').should('eq', 200)

        deletePunchList()

    });

    it('Should Edit and validate History of punch list details', () => {

        createPunchList()

        cy.log('Verifying edit details columns')
            .findByDataCy('sGeneralInfo').should('exist')
            .findByDataCy('sTask').should('exist')
            .findByDataCy('dlist').should('exist')
            .findByDataCy('spec').should('exist')
            .findByDataCy('history').should('exist')

        cy.log('Editing punch list-Tittle')
            .get('.row > :nth-child(1) > .form-group').trigger('mouseover')
            .findByDataCy('edit_title').click({ force: true })
        cy.wait(2000)
        cy.getRandomString().then(editTittle => {
            cy.findByDataCy('title').clear()
            cy.findByDataCy('title').type(editTittle)
                .findByDataCy('cancel_title').should('exist')
                .clickElement('save_title')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')


            cy.log('Editing punch manager')
                .get('.row > :nth-child(2) > .form-group').trigger('mouseover')
                .findByDataCy('edit_punch_manager').click({ force: true })
            cy.clickElement('punch_manager')
                .get('[role="option"] span').then(role => {
                    role[0].click()
                })
            cy.findByDataCy('cancel_punch_manager').should('exist')
                .clickElement('save_punch_manager')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')

            cy.log('Editing punch type')
                .get('.row > :nth-child(3) > .form-group').trigger('mouseover')
                .findByDataCy('edit_type').click({ force: true })
            cy.clickElement('type')
                .get('[role="option"] span').then(role => {
                    role[2].click()
                })
            cy.findByDataCy('cancel_type').should('exist')
                .clickElement('save_type')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')

            cy.log('Adding location')
                .get('.row > :nth-child(7) > .form-group').trigger('mouseover')
                .findByDataCy('edit_location').click({ force: true })
                .clickElement('cross')
                .clickElement('plus')
                .get('.ui-tree-toggler').click({ force: true })
                .get('.treeHeight').contains('Ground floor').click()
                .get('.modal-footer').contains('Confirm').click()
                .clickElement('save_location')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')

            cy.log('Editing punch priority')
                .get('.row > :nth-child(8) > .form-group').trigger('mouseover')
                .findByDataCy('edit_priority').click({ force: true })
            cy.clickElement('priority')
                .get('[role="option"] span').then(role => {
                    role[2].click()
                })
            cy.findByDataCy('cancel_priority').should('exist')
                .clickElement('save_priority')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')

            cy.log('Editing punch description')
                .get('.col-xl-12 > .form-group').trigger('mouseover')
                .findByDataCy('edit_description').click({ force: true })
                .get('.ql-editor').clear()
                .get('.ql-editor')
                .type(punchListConstants.EDIT_DESC)
            cy.findByDataCy('cancel_description').should('exist')
                .clickElement('save_description')
                .wait('@updatePL').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Punch Item updated.')

            cy.log('Validating Edting History')
                .clickElement('history')
                .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
                .get('.history-section-body').should('contain.text', 'Draft created')
                .get('.history-section-body').should('contain.text', 'Punch Item created')
                .get('.history-section-body').should('contain.text', 'Title updated to ' + editTittle)
                .get('.history-section-body').should('contain.text', 'Location updated to Ground floor from --')
                .get('.history-section-body').should('contain.text', 'Description updated to Hey! there editing PL description')

            closePunchList()
            deletePunchList()
        })
    });

    it('Should Add punch item Task,Respond and Validate History', () => {

        createPunchList()

        cy.log('Verifying punch item column names and fields')
            .findByDataCy('sTask').should('exist')
            .clickElement('sTask')
            .get('#task-item > .card-header').should('contain.text', 'Punch Item Task')
            .get('#task-item > .card-body').should('contain.text', 'Assignee')
            .get('#task-item > .card-body').should('contain.text', 'Due Date')
            .get('#task-item > .card-body').should('contain.text', 'Comments')
            .get('#task-item > .card-body').should('contain.text', 'Closed On')
            .get('#task-item > .card-body').should('contain.text', 'Action')
            .get('#task-item > .card-body').should('contain.text', 'Assignee')
            .findByDataCy('punchlistTaskActionBtn').should('exist')

        cy.log('Editing punch item tasks')
            .clickElement('editFields')
        cy.clickElement('assignee')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('dueDate')
            .get('.ui-datepicker-today > .ui-state-default')
            .findByDataCy('remove').should('exist')
            .findByDataCy('check').should('exist')
            .clickElement('check')

        cy.log('Adding response to task')
            .clickElement('punchlistTaskActionBtn')
            .get('.modal-header').should('contain.text', 'Response')
            .get('.empty-msg').should('contain.text', 'No comments have been added as yet')
            .findByDataCy('close_task').should('exist')
            .verifyElementDisabled('close_task')
            .verifyElementDisabled('add')
            .clickElement('open_attach_popup')
            .get('.mat-tab-labels').contains('Documents').click()
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains('Cypress.pdf').click()
            .clickElement('upload')
            .get('.ql-editor')
            .type('FYI : Adding response')
            .clickElement('add')
            .wait('@updateComments').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Comment added successfully.')
        cy.clickElement('close')

        cy.log('Validating Edting History')
            .clickElement('history')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)

        closePunchList()
        deletePunchList()

    });

    it('Should Add distribution List and validate History', () => {

        createPunchList()

        cy.log('Adding Distribution list')
            .clickElement('dlist')
            .get('#distAndAttachments').should('contain.text', 'Distribution List')
            .get('#distAndAttachments').should('contain.text', "Click on '+ New' to add members.")
            .clickElement('add_distribution_list')
            .get('.modal-title').should('contain.text', 'Distribution List')
            .get('.modal-content').should('contain.text', 'Only members who are part of project')
            .get('.modal-content').should('contain.text', 'Distribution Groups')
            .enterText('search', 'cy')
            .get(':nth-child(2) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()

        cy.log('Adding user')
            .get('.mat-tab-header').should('contain.text', 'Users').click()
            .enterText('search_users', punchListConstants.RFI_DISTRIBUTION_USER)
            .wait(2000)
            .get(':nth-child(1) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()
            .findByDataCy('cancel').should('exist')
            .clickElement('add')
            .wait('@updatePL').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Punch Item updated.')

        cy.log('Deleting user')
            .clickElement('remove_dist0')
            .get('.modal-header').should('contain.text', 'Delete')
            .get('.modal-footer').contains('Yes').click()

        cy.log('Validating Edting History')
            .clickElement('history')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', punchListConstants.RFI_DISTRIBUTION_USER + ' added to Distribution list')
            .get('.history-section-body').should('contain.text', punchListConstants.RFI_DISTRIBUTION_USER + ' removed from Distribution list')

        closePunchList()
        deletePunchList()

    });

    it('Should upload files in punch list and validate History', () => {

        cy.server().route('DELETE', '/cna/attachments/**/**').as('deleteFile')
        cy.server().route('POST', '/cna/attachments/punchlist/**').as('uploadFile')

        createPunchList()

        cy.log('uploading files')
            .clickElement('dlist')
            .get('#distAndAttachments').should('contain.text', 'Uploaded Files')
            .get('#distAndAttachments').should('contain.text', "Click on '+ New' to upload files.")
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').should('contain.text', 'Upload File')

        const yourFixturePath = 'code.png';
        cy.log('Uploading file from local')
            .get('.mat-tab-labels').contains('Local').click()
            .get("[data-cy='browse_files']").attachFile(yourFixturePath, { force: true });

        cy.log('Uploading file from Documents')
            .get('.mat-tab-labels').contains(' Documents ').click()
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains(punchListConstants.UPLOAD_DOC).click()

        cy.log('Uploading photos')
            .get('.mat-tab-labels').contains('Photos').click()
            .clickElement('select_photos_0')

        cy.log('Uploading Drawings')
            .get('.mat-tab-labels').contains('Drawings').should('exist')

        cy.clickElement('upload')
        cy.wait('@uploadFile').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Attachment(s) saved successfully')

        cy.log('Deleting uploaded files')
            .clickElement('delete_uploaded_files_section_0')
            .get('.modal-title').should('contain.text', 'Delete File')
            .get('.modal-content').contains('OK').click()
            .wait('@deleteFile').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'File deleted successfully')

        cy.clickElement('delete_uploaded_files_section_0')
            .get('.modal-content').contains('OK').click()

        cy.log('Validating punch list History for uploading files')
            .clickElement('history')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', punchListConstants.UPLOAD_DOC + ' added')
            .get('.history-section-body').should('contain.text', punchListConstants.UPLOAD_DOC + ' removed')

        closePunchList()
        deletePunchList()
    });

    it('Should add new specification and validate History', () => {

        createPunchList()

        cy.log('Attaching specification')
            .clickElement('spec')
            .get('#specsAndDrawings').should('contain.text', 'Spec Section')
            .get('#specsAndDrawings').should('contain.text', "Click on '+ New' to add spec documents.")

        cy.log('Verifying Drawings')
            .get('#specsAndDrawings').should('contain.text', 'Associated Drawings')
            .get('#specsAndDrawings').should('contain.text', 'No Associated drawings found.')

        cy.log('Adding specification')
            .clickElement('add_spec_section')
            .get('.modal-title').should('contain.text', 'Specification Section')
            .get('.ui-tree-toggler').click()
            .get('.ui-tree-container').contains('review - material').click()
            .clickElement('add-spec')
            .wait('@updatePL').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Punch Item updated.')

        cy.log('Deleting specifications')
            .clickElement('delete_spec_section_0')
            .get('.modal-title').should('contain.text', 'Delete Spec')
            .get('.modal-content').contains('OK').click()
            .wait('@updatePL').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Punch Item updated.')

        cy.log('Validating punch list History for attaching specification')
            .clickElement('history')
            .get('app-history-section > .card > .card-header').should('contain.text', 'Punch Item History')
            .get('.history-section-body').should('contain.text', 'Date')
            .get('.history-section-body').should('contain.text', 'Action By')
            .get('.history-section-body').should('contain.text', 'Action')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', 'Katerra - review - material added')
            .get('.history-section-body').should('contain.text', 'Katerra - review - material removed')

        closePunchList()
        deletePunchList()
    });

})

const fillALLFilters = () => {

    cy.clickElement('punch_manager')
        .get('li.ui-multiselect-item')
        .then((manager) => {
            manager[0].click()
        })
    cy.clickElement('punch_manager')

    cy.clickElement('type')
        .get('li.ui-multiselect-item')
        .then((type) => {
            type[0].click()
        })
    cy.clickElement('type')

    cy.clickElement('assignee')
        .get('li.ui-multiselect-item')
        .then((assignee) => {
            assignee[0].click()
        })
    cy.clickElement('assignee')

    cy.clickElement('due_date')
    cy.get('.ui-datepicker-today > .ui-state-default')
        .click()
    cy.get('.sidebar-header').click()
    cy.clickElement('state')
        .get('li.ui-multiselect-item')
        .then((state) => {
            state[0].click()
        })
    cy.clickElement('state')

    cy.clickElement('created_by')
        .get('li.ui-multiselect-item')
        .then((created_by) => {
            created_by[0].click()
        })
    cy.clickElement('created_by')

    cy.clickElement('updated_by')
        .get('li.ui-multiselect-item')
        .then((updated_by) => {
            updated_by[0].click()
        })
    cy.clickElement('updated_by')

    cy.clickElement('created_at')
    cy.get('.ui-datepicker-today > .ui-state-default')
        .click()
    cy.get('.sidebar-header').click()

    cy.clickElement('updated_at')
    cy.get('.ui-datepicker-today > .ui-state-default')
        .click()
    cy.get('.sidebar-header').click()

}
const createPunchList = () => {

    cy.log('Creating punchlist')
        .wait('@getPLTemplates').its('status').should('eq', 200)
        .clickElement('create_punch')
        .wait('@getPLTemplates').its('status').should('eq', 200)
        .get('.rfiHeader').should('contain.text', 'Create Punch Item')
    cy.getRandomString().then(punchListTittle => {
        cy.findByDataCy('title').type(punchListTittle)
        cy.wait(1000)
        cy.log('Adding all mandatory fields')
        cy.clickElement('punch_manager')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
        cy.clickElement('type')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('assignee')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('due_date')
        cy.get('.ui-datepicker-today > .ui-state-default')
            .click()
        cy.clickElement('priority')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.enterText('responsible_contractor', punchListConstants.RESPONSIBLE_CONTRACTOR)
            .get('.ql-editor')
            .type(punchListConstants.PUNCHLIST_DESC)
            .clickElement('save_draft')
            .wait('@punchListDraft').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft created.')
            .wait('@getPLHistory').its('status').should('eq', 200)
            .get('.loading > .fa').should('not.be.visible', { timeout: 3000 })

        cy.log('Creating punch list')
            .clickElement('create_punch_item')
            .wait('@createPunchList').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Punch Item created')

        cy.log('Checking status of lunch list')
            .get('.col-xl-12 > .badge').should('contain.text', 'Open')

        const todaysDate = Cypress.moment().format('MM/DD/YYYY')

        cy.log('checking created on')
            .get('.col-xl-12 > .text-muted.ng-star-inserted').should('contain', 'Created On: ' + todaysDate)

        cy.log('checking last updated on')
            .get('.col-xl-12 > :nth-child(5)').should('contain', 'Last Updated On: ' + todaysDate)

    })
}
const discardPunchList = () => {

    cy.log('discarded draft')
        .clickElement('discard_draft')
        .wait('@deleteDraft').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Draft discarded.')
        .wait('@getPLTemplates').its('status').should('eq', 200)
}
const closePunchList = () => {
    cy.log('Closing punch list task')
        .findByDataCy('sTask').click({ force: true })
        .wait(2000)
        .clickElement('punchlistTaskActionBtn')

    cy.log('Adding commmets')
        .verifyElementDisabled('add')
        .verifyElementDisabled('close_task')
        .get('.ql-editor')
        .type('closing task')
        .clickElement('add')
        .wait('@updateComments').its('status').should('eq', 201)
        .get('.ui-toast-detail')
        .should('contain.text', 'Comment added successfully.')
        .clickElement('close_task')
        .wait('@closeTask').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Punch Item Task Closed.')

    cy.log('Closing punch item')
        .clickElement('close_punch')
        .wait('@getPLState').its('status').should('eq', 200)

    cy.log('Checking status of lunch list')
        .get('.col-xl-12 > .badge').should('contain.text', 'Closed')

}
const deletePunchList = () => {

    cy.log('Deleting punch list')
        .clickElement('delete_punch_item')
        .get('.modal-title')
        .should('contain.text', 'Delete Punch Item')
        .get('.modal-body')
        .should('contain.text', 'Are you sure you want to delete this punch item?')
        .get('.modal-footer > .btn-primary')
        .click()
        .wait('@deletePL').its('status').should('eq', 200)
        .wait('@getPLTemplates').its('status').should('eq', 200)
} 