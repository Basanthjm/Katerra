import '../../support/setup-tests'
const DailyLogsData = require('../../support/constants')
describe('Collaboration DailyLogs', () => {

    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cmb/project-template-association/dailylog/project/**').as('getDailyLogTemplates')
        cy.server().route('POST', '/cna/V1/project/**/dailylog/**').as('postDailyLog')
        cy.server().route('PUT', '/cna/V1/project/**/dailylog/**').as('updateDailyLog')
        cy.server().route('GET', '/cna/V1/project/**/dailylog?template_id=**').as('getDailyLogs')
        cy.server().route('DELETE', '/cna/V1/project/**/dailylog/**').as('deleteDailyLogs')
        cy.server().route('GET', '**/tenant/locations?projectId=**').as('getProjectLocations')
        cy.server().route('POST', '**/cna/V1/project/**/dailylog/filtered/logs').as('postfilteredLogs')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(DailyLogsData.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Daily Log')

    })
    it('Should validate dailylog landing page buttons', () => {
        cy.wait('@getDailyLogTemplates').its('status').should('eq', 200)
            .log('verifying all buttons in dailylog landing page')
            .findByDataCy('view_more_logs').should('be.visible').and('have.attr', 'href')
            .findByDataCy('export').should('exist')
            .findByDataCy('select_data').should('exist')
            .get('.dailyLogContainer .headerSec h1').should('exist')
    })
    it('Should able to add new log of template', () => {
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_0')
                    .clickElement('new_0')
                    .clickElement('cancelWeatherLog_01')
                    .clickElement('new_0')
                    .get('p-dropdown[data-cy="time_01"]').click()
                    .get('[role="option"] span').then((role) => {
                        role[3].click()
                    })
                cy.get('textarea[data-cy="text_01"]').type('test')
                cy.get('#ui-panel-0 [data-cy="createLog_01"]').click()
                cy.wait('@postDailyLog').its('status').should('eq', 201)

            }
        })

    })
    it('Should able to edit created log of template', () => {
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_0')
                cy.wait('@getDailyLogs').then((xhr) => {
                    const dailyLogCount = xhr.response.body.length
                    if (dailyLogCount > 0) {
                        cy.findByDataCy('edit_log_0').click({ force: true })
                            .get('p-dropdown[data-cy="time_0"]').click()
                            .get('[role="option"] span').then((role) => {
                                role[2].click()
                            })
                        cy.get('textarea[data-cy="Text_01"]').type('edit test')
                            .clickElement('update_log_0')
                            .wait('@updateDailyLog').its('status').should('eq', 200)
                            .get('.ui-toast-summary').should('exist')
                    }
                })

            }
        })

    })
    it('Should able to delete created log of template', () => {
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_0')
                cy.wait('@getDailyLogs').then((xhr) => {
                    const dailyLogCount = xhr.response.body.length
                    if (dailyLogCount > 0) {
                        cy.findByDataCy('delete_log_0').click({ force: true })
                            .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Log')
                            .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete log?')
                        cy.findByRole('button', { name: 'Cancel' }).should('exist')
                        cy.findByRole('button', { name: 'OK' }).should('exist').click()
                            .wait('@deleteDailyLogs').its('status').should('eq', 200)
                    }
                })

            }
        })

    })
    it('Should able to select previous date and add,edit,delete log of template', () => {
        cy.wait('@getDailyLogTemplates').its('status').should('eq', 200)
            .clickElement('select_data')
            .get('.ui-datepicker-prev').click()
            .get(':nth-child(3) > :nth-child(4) > .ui-state-default').click()

        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_0')
                    .clickElement('new_0')
                    .clickElement('cancelWeatherLog_01')
                    .clickElement('new_0')
                    .get('p-dropdown[data-cy="time_01"]').click()
                    .get('[role="option"] span').then((role) => {
                        role[3].click()
                    })
                cy.get('textarea[data-cy="text_01"]').type('test')
                    .get('[data-cy="panel_0"] [data-cy="createLog_01"]').click()
                    .wait('@postDailyLog').its('status').should('eq', 201)

                    .findByDataCy('edit_log_0').click({ force: true })
                    .get('p-dropdown[data-cy="time_0"]').click()
                    .get('[role="option"] span').then((role) => {
                        role[2].click()
                    })
                cy.get('textarea[data-cy="Text_01"]').type('edit test')
                    .clickElement('update_log_0')
                    .wait('@updateDailyLog').its('status').should('eq', 200)
                    .get('.ui-toast-summary').should('exist')

                cy.findByDataCy('delete_log_0').click({ force: true })
                    .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Log')
                    .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete log?')
                cy.findByRole('button', { name: 'Cancel' }).should('exist')
                cy.findByRole('button', { name: 'OK' }).should('exist').click()
                    .wait('@deleteDailyLogs').its('status').should('eq', 200)
                    .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .clickElement('select_data')
                    .get('.ui-datepicker-next').click()
                    .get('.ui-state-highlight').click()

            }
        })

    })
    it('Should able to add new log of postman template', () => {
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_1')
                    .clickElement('new_1')
                    .clickElement('cancelLog_01')
                    .clickElement('new_1')
                cy.getRandomString().then((randomString) => {
                    cy.get('[data-cy="panel_1"] [data-cy="text_01"]').type(randomString)
                        .enterText('note_01', randomString)
                        .get('[data-cy="panel_1"] [data-cy="time_01"]').click()
                        .get('.ui-second-picker .pi-chevron-up').click()
                        .clickElement('yes_no_01')
                        .get('[role="option"] span').then((role) => {
                            role[2].click()
                        })

                })
                cy.get('#ui-panel-1 [data-cy="createLog_01"]').click()
                    .wait('@postDailyLog').its('status').should('eq', 201)
            }
        })

    })
    it('Should able to edit created log of postman template', () => {

        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_1')
                cy.wait('@getDailyLogs').then((xhr) => {
                    const dailyLogCount = xhr.response.body.length
                    if (dailyLogCount > 0) {
                        cy.get('[data-cy="editLog_1"]').click({ force: true })
                            .clickElement('cancel_lOg_1')
                            .get('[data-cy="editLog_1"]').click({ force: true })
                            .enterText('text_0', 'edit')
                            .enterText('note_1', 'edit')
                            .get('[data-cy="panel_1"] [data-cy="time_2"]').click()
                            .get('.ui-second-picker .pi-chevron-up').click()
                            .clickElement('yes_no_6')
                            .get('[role="option"] span').then((role) => {
                                role[2].click()
                            })
                        cy.get('input[placeholder="Type to Search"]').clear()
                            .type('cypress_')
                            .get('[role="option"] span').then((role) => {
                                role[1].click()
                            })
                        cy.clickElement('add_loc_8')
                        cy.wait('@getProjectLocations').then((xhr) => {
                            const locationsCount = xhr.response.body.locations.length
                            cy.get('#locationPopup').should('exist')
                            if (locationsCount == 0) {
                                cy.log('verifying location ')
                                cy.get('.modal-body div').should('contain.text', 'No location data available.')
                                cy.findByRole('button', { name: 'Confirm' }).should('be.disabled')
                                cy.findByRole('button', { name: 'Cancel' }).should('exist').click()

                            } else {
                                cy.get('.ui-tree-toggler').click()
                                cy.contains('Ground floor').click()
                                cy.findByRole('button', { name: 'Confirm' }).should('exist').click()

                            }

                        })
                        cy.clickElement('update_log_1')
                            .wait('@updateDailyLog').its('status').should('eq', 200)
                            .get('.ui-toast-summary').should('exist')


                    }
                })

            }
        })

    })
    it('Should able to delete created log of template', () => {
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_1')
                cy.wait('@getDailyLogs').then((xhr) => {
                    const dailyLogCount = xhr.response.body.length
                    if (dailyLogCount > 0) {
                        cy.findByDataCy('deleteLog_1').click({ force: true })
                            .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Log')
                            .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete log?')
                        cy.findByRole('button', { name: 'Cancel' }).should('exist')
                        cy.findByRole('button', { name: 'OK' }).should('exist').click()
                            .wait('@deleteDailyLogs').its('status').should('eq', 200)
                    }
                })

            }
        })

    })
    it('Should able to copy and delete logs from previous date ', () => {
        cy.wait('@getDailyLogTemplates').its('status').should('eq', 200)
            .clickElement('select_data')
            .get('.ui-datepicker-prev').click()
            .get(':nth-child(3) > :nth-child(4) > .ui-state-default').click()

        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_1')
                cy.wait('@getDailyLogs').then((xhr) => {
                    if (xhr.status == '400') {
                        cy.clickElement('new_1')
                            .clickElement('cancelLog_01')
                            .clickElement('new_1')
                        cy.getRandomString().then((randomString) => {
                            cy.get('[data-cy="panel_1"] [data-cy="text_01"]').type(randomString)
                                .enterText('note_01', randomString)
                                .get('[data-cy="panel_1"] [data-cy="time_01"]').click()
                                .get('.ui-second-picker .pi-chevron-up').click()
                                .clickElement('yes_no_01')
                                .get('[role="option"] span').then((role) => {
                                    role[2].click()
                                })

                        })
                        cy.get('[data-cy="panel_1"] [data-cy="createLog_01"]').click()
                            .wait('@postDailyLog').its('status').should('eq', 201)
                    }
                })
            }
        })
        cy.clickElement('select_data')
            .get('.ui-datepicker-next').click()
            .get('.ui-state-highlight').click()
        cy.wait('@getDailyLogTemplates').then((xhr) => {
            const dailyLogTemplateCount = xhr.response.body.length
            if (dailyLogTemplateCount > 0) {
                cy.clickElement('checkEditableFields_1')
                    .clickElement('Copy_Logs_1')
                    .wait('@getDailyLogs').its('status').should('eq', 400)
                    .get('.modal-content .ui-datepicker-trigger').click()
                    .get('.ui-datepicker-prev').click()
                    .get(':nth-child(3) > :nth-child(4) > .ui-state-default').click()
                    .get('p-tablecheckbox .ui-chkbox-box', { timeout: 60000 }).should('be.visible').click()
                cy.findByRole('button', { name: 'Save' }).should('exist').click()
                    .wait('@postDailyLog').its('status').should('eq', 201)
                cy.findByDataCy('deleteLog_1').click({ force: true })
                    .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Log')
                    .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete log?')
                cy.findByRole('button', { name: 'Cancel' }).should('exist')
                cy.findByRole('button', { name: 'OK' }).should('exist').click()
                    .wait('@deleteDailyLogs').its('status').should('eq', 200)
            }
        })
    })

    it('Should able to click on view more logs button, select date range and templates ', () => {
        cy.wait('@getDailyLogTemplates').its('status').should('eq', 200)
        cy.get('[data-cy="view_more_logs"]').invoke('removeAttr', 'target').click()
            .get('[data-cy="calendar"]', { timeout: 60000 }).should('be.visible').click()
            .get('.ui-datepicker-prev').click()
            .get(':nth-child(1) > .ui-datepicker-calendar-container  :nth-child(3) > :nth-child(2) > .ui-state-default').click()
            .get(':nth-child(1) > .ui-datepicker-calendar-container  :nth-child(3) > :nth-child(4) > .ui-state-default').click()
            .clickElement('projectDailyLogTemplates')
            .get('p-multiselect .ui-widget-header .ui-chkbox-box').click()
            .clickElement('apply')
            .wait('@postfilteredLogs').its('status').should('eq', 200)

    })
})
