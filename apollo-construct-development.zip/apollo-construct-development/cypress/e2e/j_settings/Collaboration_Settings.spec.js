import '../../support/setup-tests'
const settingsData = require('../../support/constants')
describe('Collaboration Settings', () => {

    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/tenant/projects/**').as('getProjectSettings')
        cy.server().route('GET', '/cmb/V1/inspection-template').as('getInspectionTemplate')
        cy.server().route('POST', '/cmb/project-template-association/INSPECTION').as('updateAssociatedInspectionTemplate')
        cy.server().route('DELETE', '/cmb/project-template-association').as('deleteAssociatedTemplate')
        cy.server().route('GET', '/cmb/dailylog-template').as('getDailyLogTemplate')
        cy.server().route('POST', '/cmb/project-template-association/DAILYLOG').as('updateAssociatedDailyLogTemplate')
        cy.server().route('GET', '/cmb/workflow').as('getWorkFlowTemplate')
        cy.server().route('POST', '/cmb/project-template-association/SUBMITTAL_WORKFLOW').as('updateAssociatedWorkFlowTemplate')
        cy.server().route('GET', '/cmb/V1/mom-template').as('getMomTemplate')
        cy.server().route('POST', '/cmb/project-template-association/MEETING_MINUTES').as('updateAssociatedMomTemplate')
        cy.server().route('GET', '/cmb/project-template-association/SUBMITTAL_WORKFLOW/project/**').as('getAssociatedTemplates')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(settingsData.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Settings')

    })
    it('Should validate settings landing page fields', () => {
        cy.wait('@getProjectSettings').its('status').should('eq', 200)
            .get(':nth-child(1) > .projectContainer  .col-lg-9').should('contain.text', 'Associated Inspection Templates')
            .get(':nth-child(2) > .projectContainer > .input-group > .col-lg-9').should('contain.text', 'Associated Daily Log Templates')
            .get(':nth-child(3) > .projectContainer > .input-group > .col-lg-9').should('contain.text', 'Associated Workflow Templates for Submittals')
            .get(':nth-child(4) > .projectContainer > .input-group > .col-lg-9').should('contain.text', 'Associated Meeting Templates')
            .log('verifying all edit buttons in settings page')
            .findByDataCy('edit_insp').should('exist')
            .findByDataCy('edit_dailylog').should('exist')
            .findByDataCy('edit_submittals').should('exist')
            .findByDataCy('edit_mom').should('exist')
            .log('verifying all search fields in settings page')
            .findByDataCy('search_insp').should('exist')
            .findByDataCy('search_daiylog').should('exist')
            .findByDataCy('search_workflow').should('exist')
            .findByDataCy('search_mom').should('exist')
    })
    it('Should validate Add,Search and delete inspection template', () => {
        cy.wait('@getProjectSettings').its('status').should('eq', 200)
        cy.log('Adding new inspection template')
            .clickElement('edit_insp')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Inspection Template to Project')
            .wait('@getInspectionTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .findByDataCy('save').should('be.disabled')
            .get('p-tablecheckbox .ui-chkbox-box').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@updateAssociatedInspectionTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            .log('search newly associated inspection template')
            .enterText('search_insp', 'cypress_automation')
            .get(':nth-child(1) > .projectContainer tbody tr').should('exist')
            .log('deleting associated inspection template')
            .clickElement('edit_insp')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Inspection Template to Project')
            .wait('@getInspectionTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .get('.ui-state-active').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@deleteAssociatedTemplate').its('status').should('eq', 200)




    })
    it('Should validate Add,Search and delete daily log template', () => {
        cy.wait('@getProjectSettings').its('status').should('eq', 200)
        cy.log('Adding new daily log template')
            .clickElement('edit_dailylog')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Daily Log Template to Project')
            .wait('@getDailyLogTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .findByDataCy('save').should('be.disabled')
            .get('p-tablecheckbox .ui-chkbox-box').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@updateAssociatedDailyLogTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('search newly associated daily log template')
            .enterText('search_daiylog', 'cypress_automation')
            .get(':nth-child(2) > .projectContainer tbody tr').should('exist')

            .log('deleting associated daily log template')
            .clickElement('edit_dailylog')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Daily Log Template to Project')
            .wait('@getDailyLogTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .get('.ui-state-active').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@deleteAssociatedTemplate').its('status').should('eq', 200)




    })
    it('Should validate Add,Search and delete work flow template', () => {
        cy.wait('@getProjectSettings').its('status').should('eq', 200)
        cy.log('Adding new work flow template')
            .clickElement('edit_submittals')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Submittal Workflow Template to Project')
            .wait('@getWorkFlowTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypresstest')
            .findByDataCy('save').should('be.disabled')
            .get('p-tablecheckbox .ui-chkbox-box').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@updateAssociatedWorkFlowTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('search newly associated work flow template')
            .enterText('search_workflow', 'cypresstest')
            .get(':nth-child(3) > .projectContainer tbody tr').should('exist')

            .log('deleting associated work flow template')
            .clickElement('edit_submittals')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Submittal Workflow Template to Project')
            .wait('@getWorkFlowTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypresstest')
            .get('.ui-state-active').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@deleteAssociatedTemplate').its('status').should('eq', 200)




    })
    it('Should validate Add,Search and delete meeting minutes template', () => {
        cy.wait('@getProjectSettings').its('status').should('eq', 200)
        cy.log('Adding new meeting minutes template')
            .clickElement('edit_mom')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Minutes of Meeting template to Project')
            .wait('@getMomTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .findByDataCy('save').should('be.disabled')
            .get('p-tablecheckbox .ui-chkbox-box').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@updateAssociatedMomTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('search newly associated meeting minutes template')
            .enterText('search_mom', 'cypress_automation')
            .get(':nth-child(4) > .projectContainer tbody tr').should('exist')

            .log('deleting associated meeting minutes template')
            .clickElement('edit_mom')
            .get('.modal-dialog').should('exist')
            .get('.modal-title').should('contain.text', 'Add Minutes of Meeting template to Project')
            .wait('@getMomTemplate').its('status').should('eq', 200)
            .enterText('search', 'cypress_automation')
            .get('.ui-state-active').click()
            .findByDataCy('save').should('not.be.disabled').click()
            .wait('@deleteAssociatedTemplate').its('status').should('eq', 200)




    })
    it('Should able to search for non existing associated inspection template', () => {
        cy.getRandomString().then(randomTemplate => {
            cy.wait('@getProjectSettings').its('status').should('eq', 200)

                .log('search non existing associated inspection template')
                .enterText('search_insp', 'randomTemplate')
                .get(':nth-child(1) > .projectContainer tbody tr').should('not.exist')
        })


    })
    it('Should able to search for non existing associated daily log template', () => {
        cy.getRandomString().then(randomTemplate => {
            cy.wait('@getProjectSettings').its('status').should('eq', 200)

                .log('search non existing associated daily log template')
                .enterText('search_daiylog', 'randomTemplate')
                .get(':nth-child(2) > .projectContainer tbody tr').should('not.exist')
        })


    })
    it('Should able to search for non existing associated work flow template', () => {
        cy.getRandomString().then(randomTemplate => {
            cy.wait('@getProjectSettings').its('status').should('eq', 200)
                .wait('@getAssociatedTemplates').then((xhr) => {
                    const status = xhr.status
                    if (status != '400') {
                        cy.log('search non existing associated work flow template')
                            .enterText('search_workflow', 'randomTemplate')
                            .get(':nth-child(3) > .projectContainer tbody tr').should('not.exist')

                    }

                })
        })


    })
    it('Should able to search for non existing associated meeting minutes template', () => {
        cy.getRandomString().then(randomTemplate => {
            cy.wait('@getProjectSettings').its('status').should('eq', 200)

                .log('search non existing associated meeting minutes template')
                .enterText('search_mom', 'randomTemplate')
                .get(':nth-child(4) > .projectContainer tbody tr').should('not.exist')
        })


    })


})