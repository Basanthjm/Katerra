const inspectionTempConstants = require('../../support/constants')
let InspectionTemplateName

describe('Collaboration Inspection Templates', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/V1/inspection-template').as('getInspectionTemplate')
        cy.server().route('GET', '/cmb/project-template-association/inspection/template/**').as('getInspectionAssociation')
        cy.server().route('DELETE', '/cmb/V1/inspection-template/**').as('deleteTemplate')
        cy.server().route('POST', '/cmb/project-template-association/inspection').as('getInspection')
        cy.server().route('GET', '/cmb/config_dropdown?feature=inspection').as('getInspectionFeatures')
        cy.server().route('GET', '/cmb/V1/inspection-template?type=**').as('getInspectionFilters')
        cy.visitPage('/construct/settings/inspection-template/list')

    })

    it('Should verify inspection template landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getInspectionTemplate').its('status').should('eq', 200)
            .get('.content-header').should('contain.text', 'Inspection Templates')
            .findByDataCy('add_new').should('exist')
            .findByDataCy('reset').should('exist')
            .clickElement('reset')
            .findByDataCy('Filter_by_type').should('exist')
            .findByDataCy('filtered_name_0').should('exist')
            .findByDataCy('filtered_name_1').should('exist')
            .findByDataCy('searchBox').should('exist')
    });

    it('Should validate counts of inspection templates', () => {

        cy.log('Verifying all inspection template counts')
            .wait('@getInspectionTemplate').then((xhr) => {
                const inspectionCounts = xhr.response.body.success.length
                cy.log('number of meetings->', inspectionCounts)
                cy.findByText(`1-${inspectionCounts} of ${inspectionCounts}`).should('exist')
            })

    });

    it('Should search for Non-existing template and validate message', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .enterText('searchBox', inspectionTempConstants.EMPTY_RFI_SEARCH)
            .get('.justify-content-center').should('contain.text', 'No Templates Found')
            .findByDataCy('searchBox').clear()
    });

    it('Should verify Add  new Inspection template fields', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .clickElement('add_new')
            .wait('@getInspectionFeatures').its('status').should('eq', 200)
            .get('.company-header').should('contain.text', 'New Inspection Template')
            .findByDataCy('Template_name').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('trade').should('exist')
            .findByDataCy('description').should('exist')
            .findByDataCy('goTofields').should('exist')
            .findByDataCy('projects').should('exist')
            .findByDataCy('Section_Name').should('exist')
            .findByDataCy('lable').should('exist')
            .findByDataCy('deleteRow').should('exist')
            .findByDataCy('new_label').should('exist')
            .findByDataCy('deleteSection').should('exist')
            .findByDataCy('sectionContainercollapsed').should('exist')
            .findByDataCy('newSection').should('exist')
            .findByDataCy('saveTemplate').should('exist')
            .findByDataCy('closeButton').should('exist')
    });

    it('Should Add new Inspection Template', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewInspectionTemplate(templateName)
                InspectionTemplateName = templateName
            })

    });

    it('Should Search created template and delete it', () => {

        searchTemplate()
        cy.clickElement('navigate_to_0')
            .wait('@getInspectionAssociation')
        deleteTemplate()

    });

    it('Should Create Template-Edit-Add projects and validate counts', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewInspectionTemplate(templateName)
                InspectionTemplateName = templateName
                searchTemplate()
            })

        cy.log('Editing project')
            .clickElement('navigate_to_0')
            .wait('@getInspectionAssociation')
            .clickElement('type')
            .get(':nth-child(2) > .ui-dropdown-item').click()
            .clickElement('trade')
            .get('[role="option"] span').then(role => {
                role[2].click()
            })

        addProjects()

        cy.log('Verying associated counts')
            .wait('@getInspectionAssociation').then((xhr) => {
                const projectsCounts = xhr.response.body.length
                cy.log('number of Associated projects->', projectsCounts)
                cy.findByText(`Associated Projects (${projectsCounts})`).should('exist')
            })

        deleteTemplate()
    });

    it('Should create template and validate by filter type', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewInspectionTemplate(templateName)
                InspectionTemplateName = templateName

                cy.log('Filtering by type')
                    .clickElement('reset')
                    .enterText('Filter_by_type', inspectionTempConstants.TEMPLATE_TYPE)
                    .clickElement('filtered_name_0')
                    .wait('@getInspectionFilters').its('status').should('eq', 200)
                    .get('[data-cy=navigate_to_0] > .content-box-lg')
                    .should('contain.text', inspectionTempConstants.TEMPLATE_TYPE)

                searchTemplate()
                cy.clickElement('navigate_to_0')
                    .wait('@getInspectionAssociation')
                deleteTemplate()
            })
    });

    it('Should create template,add two sections and delete', () => {

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewInspectionTemplate(templateName)
                InspectionTemplateName = templateName
                searchTemplate()

                cy.log('Adding section')
                cy.clickElement('navigate_to_0')
                    .wait('@getInspectionAssociation')
                    .clickElement('new_section')
                    .get(':nth-child(2) > :nth-child(1) > .p10 > [data-cy=section_name]')
                    .type('Section_02')
                    .get('#cdk-drop-list-4 > :nth-child(1) > :nth-child(1) > :nth-child(2) > [data-cy=lable]')
                    .type('Lab_01')
                    .get('#cdk-drop-list-4 > :nth-child(1) > :nth-child(2) > :nth-child(2) > [data-cy=lable]')
                    .type('Lab_02')
                    .get('#cdk-drop-list-4 > :nth-child(1) > :nth-child(3) > :nth-child(2) > [data-cy=lable]')
                    .type('Lab_03')
                    .clickElement('save_template')

                searchTemplate()

                cy.log('deleting section')
                    .clickElement('navigate_to_0')
                    .wait('@getInspectionAssociation')
                    .get(':nth-child(1) > :nth-child(2) > .p10 > span.pull-right > [data-cy=delete_section]')
                    .click()
                    .get('.ui-dialog-titlebar')
                    .should('contain.text', 'Delete Section?')
                    .get('.ui-dialog-content')
                    .should('contain.text', 'Are you sure you want to delete this section?')
                    .clickElement('confirm')

                deleteTemplate()

            })
    });

    it('Should create template,add project and validate it in Inspections', () => {

        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '**/cna/forms/inspection?project_id=**').as('getInspectionForms')

        cy.wait('@getInspectionTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewInspectionTemplate(templateName)
                InspectionTemplateName = templateName
                searchTemplate()
                cy.clickElement('navigate_to_0')
                    .wait('@getInspectionAssociation')
                addProjects()

                cy.log('Visit added project and validate template')
                    .get('.ap-down-arrow').click()
                    .get('.ap-project-search > .ap-text-sm').type(inspectionTempConstants.SEARCH_PROJECT)
                    .get('.ap-project-item').click()
                    .wait('@getTenantMembers').its('status').should('eq', 200)
                    .clickElement('Collaboration')
                    .clickElement('Inspections')
                    .wait('@getInspectionForms').its('status').should('eq', 200)
                    .clickElement('create_inspection')
                    .clickElement('inspection_template')
                    .get('.ui-dropdown-filter').type(InspectionTemplateName)
                cy.findByText(InspectionTemplateName).should('exist')

                cy.log('Visit inspection template and delete it')
                    .visitPage('/construct/settings/inspection-template/list')
                searchTemplate()
                cy.clickElement('navigate_to_0')
                    .wait('@getInspectionAssociation')
                deleteTemplate()
            })
    });
})

const addNewInspectionTemplate = function (templateName) {

    cy.log('Creating new template')
        .clickElement('add_new')
        .wait('@getInspectionFeatures').its('status').should('eq', 200)
        .enterText('Template_name', templateName)
        .clickElement('type')

    cy.get('.ui-dropdown-filter').type(inspectionTempConstants.TEMPLATE_TYPE)
    cy.get('.ui-dropdown-item').click()
        .clickElement('trade')
        .get('[role="option"] span').then(role => {
            role[1].click()
        })
    cy.enterText('description', 'Adding new template')
        .enterText('Section_Name', 'Sectio_01')
        .get(':nth-child(1) > :nth-child(2) > [data-cy=lable]').type('Lable_01')
        .get(':nth-child(2) > :nth-child(2) > [data-cy=lable]').type('Lable_02')
        .get(':nth-child(3) > :nth-child(2) > [data-cy=lable]').type('Lable_03')
        .clickElement('saveTemplate')
        .clickElement('skip')
}

const searchTemplate = function () {

    cy.log('Searching for template')
        .wait('@getInspectionTemplate').its('status').should('eq', 200)
        .enterText('searchBox', InspectionTemplateName)
        .findByDataCy('nameSort').should('exist')
        .findByDataCy('type').should('exist')
        .findByDataCy('navigate_to_0').should('contain.text', InspectionTemplateName)
}

const addProjects = function () {

    cy.log('Adding project')
        .clickElement('projects')
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .type(inspectionTempConstants.project_01)
    cy.findByText(inspectionTempConstants.project_01).click()
        .get('[icon="pi pi-angle-right"] > .ui-button-text').click({ force: true })
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .clear()

    cy.log('Adding another project')
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .type(inspectionTempConstants.project_02)
    cy.findByText(inspectionTempConstants.project_02).click()
        .get('[icon="pi pi-angle-right"] > .ui-button-text').click({ force: true })

    cy.clickElement('save')
        .wait('@getInspection').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Associated Projects updated.')

}

const deleteTemplate = function () {

    cy.log('Deleting template')
        .clickElement('delete_temp')
        .get('.ui-dialog-titlebar').should('contain.text', 'Delete Template?')
        .get('.ui-confirmdialog-message').should('contain.text', 'Are you sure you want to proceed?')
        .findByDataCy('reject').should('exist')
        .findByDataCy('confirm').should('exist')
        .clickElement('confirm')
        .wait('@deleteTemplate').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Inspection Template deleted')
}