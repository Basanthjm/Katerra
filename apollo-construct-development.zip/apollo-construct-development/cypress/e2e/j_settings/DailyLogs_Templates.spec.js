const dailyLogsTempData = require('../../support/constants')
let tempNameWithOutProj
let tempNameWithProj

describe('Collaboration Daily logs Templates', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/dailylog-template?**').as('getDailylogTemplate')
        cy.server().route('GET', '/cmb/dailylog-template/count').as('getDailylogTemplateCount')
        cy.server().route('POST', '/cmb/dailylog-template').as('postDailylogTemplate')
        cy.server().route('GET', '/cmb/dailylog-template/template_details/**').as('getDailylogTemplateDetails')
        cy.server().route('PATCH', '/cmb/dailylog-template/**').as('updateDailylogTemplate')
        cy.server().route('DELETE', '/cmb/dailylog-template/**').as('deleteDailylogTemplate')
        cy.server().route('POST', '/cmb/project-template-association/dailylog').as('updateTemplateProjects')
        cy.server().route('GET', '/cmb/project-template-association/dailylog/template/**').as('getTemplateProjects')

        cy.visitPage('/construct/settings/dailylog-template/list')

    })

    it('Should verify daily logs template landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getDailylogTemplate').its('status').should('eq', 200)
            .get('.content-header').should('contain.text', 'Daily Log Templates ')
            .findByDataCy('add_new').should('exist')
            .findByDataCy('more').should('exist')
            .findByDataCy('more')
            .click({ force: true })
            .findByDataCy('deletedButton').should('exist')
            .findByDataCy('previousDisabled').should('exist')
            .findByDataCy('nextDisabled').should('exist')
            .findByDataCy('searchBox').should('exist')
    });

    it('Should validate counts of daily log templates', () => {
        cy.log('Verifying  template counts')
            .wait('@getDailylogTemplate').its('status').should('eq', 200)
            .wait('@getDailylogTemplateCount').then((xhr) => {
                const dailyLogCount = xhr.response.body.data
                cy.log('number of daily logs ->', dailyLogCount)
                cy.findByText(`1-${dailyLogCount} of ${dailyLogCount}`).should('exist')
            })

    });

    it('Should search for Non-existing template name and validate message', () => {

        cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
        cy.getRandomString().then((randomString) => {
            cy.enterText('searchBox', randomString)
                .get('.justify-content-center').should('contain.text', 'No Template Found')
                .findByDataCy('searchBox').clear()
        })
    });
    it('Should verify Add new daily logs template fields', () => {

        cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
            .clickElement('add_new')
            .get('.company-header').should('contain.text', 'New Daily Log Template')
            .findByDataCy('name').should('exist')
            .findByDataCy('field_0').should('exist')
            .findByDataCy('type_0').should('exist')
            .findByDataCy('selectAll_0').should('exist')
            .findByDataCy('deleteRow_0').should('exist')
            .findByDataCy('addNewField').should('exist')
            .findByDataCy('createTemplate').should('exist')
            .findByDataCy('closeButton').should('exist')
    });
    it('Should Add new daily logs Template without associated projects', () => {

        cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewDailyLogTemplate(templateName)
                cy.get('.ui-toast-summary').should('exist')
                    .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .clickElement('skip')
                tempNameWithOutProj = templateName
            })

    });
    it('Should able to Search and open detail page of created template with out project', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')

        searchTemplate(tempNameWithOutProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)

    });
    it('Should able to verify nothing to update error message after clicking save changes button of non associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithOutProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('save_changes')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary').should('contain.text', 'Error')
            .get('.ui-toast-detail').should('contain.text', 'Nothing to update.')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

    });
    it('Should able to add new field,save changes and delete added field of non associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithOutProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('new_field')
            .log('field name should not be empty alert message')
            .clickElement('save_changes')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary').should('contain.text', 'Required')
            .get('.ui-toast-detail').should('contain.text', 'Field Name(s) should not be empty.')
            .getRandomString().then(randomString => {
                cy.enterText('fieldName_1', 'field_' + randomString)
                    .clickElement('types_1')
                    .get('[role="option"] span').then(role => {
                        role[1].click()
                    })
            })
        cy.clickElement('save_changes')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Save Changes')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.SAVE_CHANGES_CNFRM_DIALOG_MSG)
            .clickElement('confirm')
            .wait('@updateDailylogTemplate').its('status').should('eq', 200)

            .clickElement('deleteRow_1')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Daily Log Template field')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.DELETE_CNFRM_MSG)
            .clickElement('confirm')


    });
    it('Should able to add multiple projects and delete one project to non associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithOutProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('projects')
            .get('.ui-picklist-source-wrapper   .ui-picklist-filter').type('ui automation')
            .log('adding multiple projects')
            .get('.ui-picklist-source-wrapper li[style="display: block;"] .ui-helper-clearfix div').then(ele => {
                ele[1].click()
            })
        cy.get('span.pi-angle-right').click()
            .get('.ui-picklist-source-wrapper li[style="display: block;"] .ui-helper-clearfix div').click()
            .get('span.pi-angle-right').click()
            .clickElement('save')
            .wait('@updateTemplateProjects').its('status').should('eq', 200)
            .log('deleting one project')
            .get('.ui-picklist-target-wrapper li[style="display: block;"] .ui-helper-clearfix div').then(ele => {
                ele[1].click()
            })
        cy.get('span.pi-angle-left').click()
            .clickElement('save')
            .wait('@updateTemplateProjects').its('status').should('eq', 200)


    });
    it('Should able to delete template of non associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithOutProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('delete_temp')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Daily Log Template')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.DEL_TEMP_CNFRM_MSG)
            .clickElement('confirm')
            .wait('@deleteDailylogTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-detail').should('contain.text', 'Daily Log Template deleted')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

    });
    it('Should able to search for deleted template name ', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithOutProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')

        cy.log('Searching for template')
            .wait('@getDailylogTemplate').its('status').should('eq', 200)
            .enterText('searchBox', tempNameWithOutProj)
            .get('span.text-center').should('contain.text', 'No Template Found')

    });
    it('Should verify all alerts messages of Add new daily logs template and close', () => {

        cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
            .clickElement('add_new')
            .log('Verifying empty template name alert')
            .clickElement('createTemplate')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-detail').should('contain.text', 'Template Name should not be empty.')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('Verifying field name already in use')
            .enterText('field_0', 'cy_field_0')
            .enterText('field_1', 'cy_field_0')
            .clickElement('type_1')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-detail').should('contain.text', 'This field name is already in use in this template. Please enter a new name.')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('Verifying minimum one field required alert')
            .clickElement('deleteRow_0')
            .clickElement('deleteRow_0')
            .clickElement('deleteRow_0')
            .clickElement('deleteRow_0')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-detail').should('contain.text', 'Minimum one field required to create the template.')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            .log('Verifying unsaved changes will be lost popup')
            .clickElement('closeButton')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Unsaved Changes')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.UNSAVED_CHANGES_CNFRM_MSG)

            .clickElement('confirm')


    });
    it('Should Add new daily logs Template with projects', () => {

        cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewDailyLogTemplate(templateName)
                cy.get('.ui-toast-summary').should('exist')
                    .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .get('.ui-picklist-source-wrapper   .ui-picklist-filter').type('construct ui automation')
                    .log('adding multiple projects')
                    .get('.ui-picklist-source-wrapper li[style="display: block;"] .ui-helper-clearfix div').click()
                    .get('span.pi-angle-right').click()
                    .clickElement('save')
                cy.wait('@getDailylogTemplate').its('status').should('eq', 200)
                tempNameWithProj = templateName
            })

    });
    it('Should able to Search and open detail page of created template with project', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')

        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)

    });
    it('Should verify count of fields and associated projects of the template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').then((xhr) => {
                const fieldsCount = xhr.response.body.fields.length
                cy.log('number of fields ->', fieldsCount)
                    .get('[data-cy="fields"] span').should('contain.text', ' Fields (' + fieldsCount + ')')
            })
        cy.wait('@getTemplateProjects').then((xhr) => {
            const projectsCount = xhr.response.body.length
            cy.log('number of projects ->', projectsCount)
                .get('[data-cy="projects"] span').should('contain.text', ' Associated Projects (' + projectsCount + ')')
        })

    });
    it('Should able to verify nothing to update error message after clicking save changes button of template with associated projects', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('save_changes')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary').should('contain.text', 'Error')
            .get('.ui-toast-detail').should('contain.text', 'Nothing to update.')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

    });
    it('Should able to add new field,save changes and delete added field of non associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('new_field')
            .log('field name should not be empty alert message')
            .clickElement('save_changes')
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-summary').should('contain.text', 'Required')
            .get('.ui-toast-detail').should('contain.text', 'Field Name(s) should not be empty.')
            .getRandomString().then(randomString => {
                cy.enterText('fieldName_1', 'field_' + randomString)
                    .clickElement('types_1')
                    .get('[role="option"] span').then(role => {
                        role[1].click()
                    })
            })
        cy.clickElement('save_changes')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Save Changes')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.SAVE_CHANGES_CNFRM_DIALOG_MSG)
            .clickElement('confirm')
            .wait('@updateDailylogTemplate').its('status').should('eq', 200)

            .clickElement('deleteRow_1')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Daily Log Template field')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.DELETE_CNFRM_MSG)
            .clickElement('confirm')


    });
    it('Should able to add and delete one project of daily log template with associated projects', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .wait('@getTemplateProjects').its('status').should('eq', 200)
            .clickElement('projects')
            .get('.ui-picklist-source-wrapper   .ui-picklist-filter').type('ui automation')
            .log('adding multiple projects')
            .get('.ui-picklist-source-wrapper li[style="display: block;"] .ui-helper-clearfix div').click()
            .get('span.pi-angle-right').click()
            .clickElement('save')
            .wait('@updateTemplateProjects').its('status').should('eq', 200)
            .log('deleting one project')
            .get('.ui-picklist-target-wrapper li[style="display: block;"] .ui-helper-clearfix div').then(ele => {
                ele[1].click()
            })
        cy.get('span.pi-angle-left').click()
            .clickElement('save')
            .wait('@updateTemplateProjects').its('status').should('eq', 200)

    });
    it('Should able to edit template name', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')

        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('saveName')
            .get('[data-cy="name"]').type('_edit')
            .clickElement('updateTemplateName')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Save Changes')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.SAVE_CHANGES_CNFRM_DIALOG_MSG)
            .clickElement('confirm')
            .wait('@updateDailylogTemplate').its('status').should('eq', 200)
        tempNameWithProj = tempNameWithProj + '_edit'
        //.get('[data-cy="saveName"] img').click({ force: true })

    });

    it('Should able to delete template of associated project template', () => {
        cy.server().route('GET', '/cmb/dailylog-template/search/_list?q=' + tempNameWithProj + '&sort=name&limit=50&offset=0').as('getSearchedDailyLogs')
        searchTemplate(tempNameWithProj)
        cy.clickElement('col_0')
            .wait('@getDailylogTemplateDetails').its('status').should('eq', 200)
            .clickElement('delete_temp')
            .get('.ui-confirmdialog').should('exist')
            .get('span.ui-dialog-title').should('contain.text', 'Delete Daily Log Template')
            .get('.ui-confirmdialog-message').should('contain.text', dailyLogsTempData.DEL_TEMP_CNFRM_MSG)
            .clickElement('confirm')
            .wait('@deleteDailylogTemplate').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
            .get('.ui-toast-detail').should('contain.text', 'Daily Log Template deleted')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

    });




    const addNewDailyLogTemplate = function (templateName) {

        cy.log('Creating new template')
            .clickElement('add_new')
            .enterText('name', templateName)
            .enterText('field_0', 'cy_field_0')
            .clickElement('type_0')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('deleteRow_1')
            .clickElement('deleteRow_1')
            .clickElement('deleteRow_1')
            .clickElement('createTemplate')
            .wait('@postDailylogTemplate').its('status').should('eq', 201)


    }
    const searchTemplate = function (templateName) {

        cy.log('Searching for template')
            .wait('@getDailylogTemplate').its('status').should('eq', 200)
            .enterText('searchBox', templateName)
            .wait('@getSearchedDailyLogs').then((xhr) => {
                const dailyLogCount = xhr.response.body.count
                cy.log('number of daily logs ->', dailyLogCount)
                cy.findByText(`1-${dailyLogCount} of ${dailyLogCount}`).should('exist')
            })
    }


})