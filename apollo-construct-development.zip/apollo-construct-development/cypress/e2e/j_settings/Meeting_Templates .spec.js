const meetingTempConstants = require('../../support/constants')
let MeetingTemplateName

describe('Collaboration Meeting Templates', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/V1/mom-template').as('getMeetingTemplates')
        cy.server().route('GET', '/cmb/projects').as('getProjects')
        cy.server().route('DELETE', '/cmb/V1/mom-template/**').as('deleteTemplate')
        cy.server().route('PUT', '/cmb/V1/mom-template/**').as('updateTemplate')
        cy.server().route('POST', '/cmb/project-template-association/meeting_minutes').as('updateMeetingAssoction')
        cy.server().route('GET', '/cmb/project-template-association/meeting_minutes/template/**').as('getMeetingAssociation')
        cy.server().route('GET', '/cmb/V1/mom-template?deleted=true').as('getDeletedTemplates')
        cy.visitPage('/construct/settings/meeting-minutes/list')
    })

    it('Should verify meeting template landing page fields', () => {

        cy.log('Verifying landing page fields')
            .wait('@getMeetingTemplates').its('status').should('eq', 200)
            .get('.content-header').should('contain.text', 'Meeting Templates')
            .findByDataCy('add_new').should('exist')
            .clickElement('more')
            .findByDataCy('deleteTemplate').should('exist')
            .findByDataCy('searchBox').should('exist')
    });

    it('Should validate counts of meeting templates', () => {

        cy.log('Verifying all meeting template counts')
            .wait('@getMeetingTemplates').then((xhr) => {
                const meetingTempCounts = xhr.response.body.success.length
                cy.log('number of meeting templates->', meetingTempCounts)
                cy.findByText(`1-${meetingTempCounts} of ${meetingTempCounts}`).should('exist')
            })

    });

    it('Should search for Non-existing template and validate message', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .enterText('searchBox', meetingTempConstants.EMPTY_RFI_SEARCH)
            .get('.justify-content-center').should('contain.text', 'No Templates Found')
            .findByDataCy('searchBox').clear()
    });

    it('Should verify Add new meeting template fields', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .clickElement('add_new')
            .wait('@getProjects').its('status').should('eq', 200)
            .get('.col-8 > .lg-font').should('contain.text', 'New Meeting Template')
            .findByDataCy('template_name').should('exist')
            .findByDataCy('description').should('exist')
            .findByDataCy('fields').should('exist')
            .findByDataCy('projects').should('exist')
            .findByDataCy('category_0').should('exist')
            .findByDataCy('item_00').should('exist')
            .findByDataCy('category_1').should('exist')
            .findByDataCy('item_10').should('exist')
            .findByDataCy('category_0').should('exist')
            .findByDataCy('delete_0').should('exist')
            .findByDataCy('toggle_0').should('exist')
            .findByDataCy('new_category').should('exist')
            .findByDataCy('save_template').should('exist')
            .findByDataCy('closeButton').should('exist')
            .clickElement('closeButton')
            .get('.ui-dialog-titlebar').should('contain.text', 'Unsaved Changes')
            .get('.ui-confirmdialog-message').should('contain.text', 'Unsaved changes will be lost. Are you sure you want to proceed?')
            .findByDataCy('reject').should('exist')
            .findByDataCy('confirm').should('exist')
            .clickElement('confirm')

    })

    it('Should Add new Meeting Template', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewMeetingTemplate(templateName)
                MeetingTemplateName = templateName
            })
    });

    it('Should Search created template and delete it', () => {

        searchTemplate()
        cy.get('.template_nav').click()
            .wait('@getProjects')
        deleteTemplate()
    });

    it('Should Create Template-Edit-Add projects and validate counts', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewMeetingTemplate(templateName)
                MeetingTemplateName = templateName
                searchTemplate()
                cy.get('.template_nav').click()
                    .wait('@getProjects')
            })

        cy.log('Editing project')
            .findByDataCy('template_name').clear()
            .getRandomString().then(editTemplateName => {
                cy.enterText('template_name', editTemplateName)
                    .findByDataCy('description').clear()
                    .enterText('description', meetingTempConstants.MEETING_OVERVIEW)
                    .clickElement('SaveTemplate')
                    .wait('@updateTemplate').its('status').should('eq', 200)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Updated Successfully')
            })
        addProjects()

        cy.log('Verying associated counts')
            .wait('@updateMeetingAssoction').its('status').should('eq', 200)
        cy.findByText('Associated Projects (2)').should('exist')

        deleteTemplate()

    })

    it('Should create template with multiple catogories then delete thoes ', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewMeetingTemplate(templateName)
                MeetingTemplateName = templateName
                searchTemplate()
                cy.get('.template_nav').click()
                    .wait('@getProjects')

                cy.log('Adding catagories')

                    .clickElement('NewCategory')
                    .enterText('category_2', 'Cat 03')
                    .enterText('item_name_20', 'Item 03')

                    .clickElement('NewCategory')
                    .enterText('category_3', 'Cat 04')
                    .enterText('item_name_30', 'Item 04')

                    .clickElement('SaveTemplate')
                    .wait('@updateTemplate').its('status').should('eq', 200)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Updated Successfully')

                cy.log('Deleting added catagiories')
                    .clickElement('delete_0')
                    .get('.ui-dialog-titlebar').should('contain.text', 'Delete Field ?')
                    .get('.ui-confirmdialog-message').should('contain.text', 'Are you sure you want to delete this field?')
                    .findByDataCy('reject').should('exist')
                    .findByDataCy('confirm').should('exist')
                    .clickElement('confirm')
                    .clickElement('delete_0')
                    .clickElement('confirm')
                    .clickElement('delete_0')
                    .clickElement('confirm')

                deleteTemplate()
            })
    });

    it('Should delete template and validate in deleted templates', () => {

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewMeetingTemplate(templateName)
                MeetingTemplateName = templateName
                searchTemplate()
                cy.get('.template_nav').click()
                    .wait('@getProjects')
                deleteTemplate()
                cy.wait('@getMeetingTemplates')
                    .clickElement('more')
                    .clickElement('deleteTemplate')

                cy.log('Verying deleted templates counts')
                    .wait('@getDeletedTemplates').then((xhr) => {
                        const deleteMeetingTemps = xhr.response.body.success.length
                        cy.log('number of deleted meeting templates->', deleteMeetingTemps)
                        if (deleteMeetingTemps > 50) {
                            cy.findByText(`1-50 of ${deleteMeetingTemps}`).should('exist')
                        }
                        else {
                            cy.findByText(`1-${deleteMeetingTemps} of ${deleteMeetingTemps}`).should('exist')
                        }
                    })

                cy.log('Verify deleted templates page')
                    .get('.content-header').should('contain.text', 'Deleted Templates')
                    .findByDataCy('searchBox').should('exist')
                    .findByDataCy('nameSort').should('exist')
                    .findByDataCy('idSort').should('exist')
                    .findByDataCy('date created').should('exist')
                    .findByDataCy('last visited').should('exist')

                cy.log('Searching for deleted template')
                    .enterText('searchBox', MeetingTemplateName)
                    .get('.x-auto').should('contain.text', MeetingTemplateName)
                    .findByDataCy('searchBox').clear()
            })
    });

    it('Should create template,add project and validate it in meeting minutes', () => {

        cy.server().route('GET', '/cna/V1/project/**/meeting_minutes').as('getMeetingMins')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cmb/project-template-association/MEETING_MINUTES/project/**?details=true').as('getMeetingTemplate')

        cy.wait('@getMeetingTemplates').its('status').should('eq', 200)
            .getRandomString().then(templateName => {
                addNewMeetingTemplate(templateName)
                MeetingTemplateName = templateName
                searchTemplate()
                cy.get('.template_nav').click()
                    .wait('@getProjects')
                addProjects()

                cy.log('Visit added project and validate template')
                    .get('.ap-down-arrow').click()
                    .get('.ap-project-search > .ap-text-sm').type(meetingTempConstants.SEARCH_PROJECT)
                    .get('.ap-project-item').click()
                    .wait('@getTenantMembers').its('status').should('eq', 200)
                    .clickElement('Collaboration')
                    .clickElement('Meeting Minutes')
                    .wait('@getMeetingMins').its('status').should('eq', 200)
                    .clickElement('create_new')
                    .wait('@getMeetingTemplate').its('status').should('eq', 200)
                    .clickElement('meetingTemplateOption')
                    .get('.ui-dropdown-filter').type(MeetingTemplateName)
                cy.findByText(MeetingTemplateName).should('exist')

                cy.log('Visit inspection template and delete it')
                    .visitPage('/construct/settings/meeting-minutes/list')
                searchTemplate()
                cy.get('.template_nav').click()
                    .wait('@getProjects')
                deleteTemplate()
            })
    });
})

const addNewMeetingTemplate = function (templateName) {

    cy.log('Creating new template')
        .clickElement('add_new')
        .wait('@getProjects').its('status').should('eq', 200)
        .enterText('template_name', templateName)
        .enterText('description', 'Valid description')
        .enterText('category_0', 'Cat 01')
        .enterText('item_00', 'Item 01')
        .enterText('category_1', 'Cat 02')
        .enterText('item_10', 'Item 02')
        .clickElement('save_template')
        .clickElement('skip')
}
const searchTemplate = function () {

    cy.log('Searching for template')
        .wait('@getMeetingTemplates').its('status').should('eq', 200)
        .enterText('searchBox', MeetingTemplateName)
        .findByDataCy('vendor_id').should('contain.text', MeetingTemplateName)
}
const addProjects = function () {

    cy.log('Adding project')
        .clickElement('projects')
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .type(meetingTempConstants.project_01)
    cy.findByText(meetingTempConstants.project_01).click()
        .get('[icon="pi pi-angle-right"] > .ui-button-text').click({ force: true })
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .clear()

    cy.log('Adding another project')
        .get('.ui-picklist-source-wrapper > .ui-picklist-filter-container > .ui-picklist-filter')
        .type(meetingTempConstants.project_02)
    cy.findByText(meetingTempConstants.project_02).click()
        .get('[icon="pi pi-angle-right"] > .ui-button-text').click({ force: true })

    cy.clickElement('save')
}
const deleteTemplate = function () {

    cy.log('Deleting template')
        .clickElement('deleteTemplate')
        .get('.ui-dialog-titlebar').should('contain.text', 'Delete Template')
        .get('.ui-confirmdialog-message').should('contain.text', 'Are you sure you want to delete this meeting template?')
        .findByDataCy('reject').should('exist')
        .findByDataCy('confirm').should('exist')
        .clickElement('confirm')
        .wait('@deleteTemplate').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Template Deleted.')
}