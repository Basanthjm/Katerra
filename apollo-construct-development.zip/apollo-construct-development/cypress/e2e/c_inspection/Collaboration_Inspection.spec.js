import '../../support/setup-tests'
const inspectionData = require('../../support/constants')
let newInspection = inspectionData.OBSERVATION_NAME
describe('Collaboration Inspection', () => {

    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '**/cna/forms/inspection?project_id=**').as('getInspectionForms')
        cy.server().route('GET', '**/tenant/locations?projectId=**').as('getProjectLocations')
        cy.server().route('POST', '/cna/forms/inspection').as('createInspection')
        cy.server().route('GET', '**/cna/forms/inspection/**').as('getInspectionDetails')
        cy.server().route('PATCH', '**/cna/forms/inspection/**/state').as('updateInspectionState')
        cy.server().route('DELETE', '**cna/forms/inspection/**?project_id=**').as('deleteInspection')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(inspectionData.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Inspections')

    })
    it('Should validate inspection landing page buttons', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
            .log('verifying all buttons in inspection landing page')
            .findByDataCy('all_inspections').should('be.visible').and('have.attr', 'href')
            .findByDataCy('my_inspections').should('be.visible').and('have.attr', 'href')
            .findByDataCy('create_inspection').parent('a').should('be.visible').and('have.attr', 'href')
            .findByDataCy('insp_search').should('exist')
            .log('verify export button exist')
            .findByDataCy('export_inspection').should('exist')
            .findByDataCy('inspection_filter_button').should('exist')
    })
    it('Should verify fill mandatory field alert message while creating empty inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('clicking on create inspection page')
        cy.findByDataCy('create_inspection')
            .click()
            .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
            .findByDataCy('create_inspection')
            .click()
            .get('.ui-toast-summary')
            .should('exist')
        cy.contains('Please fill all mandatory fields.')
            .should('exist')
    })
    it('should validate count of inspection', () => {
        cy.wait('@getInspectionForms').then((xhr) => {
            const inspectionCount = xhr.response.body.data.count
            cy.log('number of Inspection ->', inspectionCount)
            if (inspectionCount == 0) {
                cy.get('.empty-msg span').should('exist').and('contain.text', 'No Inspections have been added yet')
            } else if (inspectionCount > 50) {
                cy.findByText(`1-50 of ${inspectionCount}`).should('exist')
                cy.findByDataCy('next').should('exist')
                cy.findByDataCy('last_page').should('exist')
            } else {
                cy.findByText(`1-${inspectionCount} of ${inspectionCount}`)
                    .should('exist')

            }

        })

    })
    it('Should able to create new inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomInspection) => {
            createInspection(randomInspection)
        })
    })
    it('should search non exist inspection and validate message', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search non existing inspection')
        cy.getRandomString().then((randomInspection) => {
            cy.enterText('insp_search', randomInspection)
                .get('.empty-msg').should('exist').and('contain.text', 'No results found.')
        })
    })
    it('should search and open detail page of created inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()

    })
    it('should verify close button enabled or not of created inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.wait('@getInspectionDetails').then((xhr) => {
            const inspectionStatus = xhr.response.body.data.sections[0].labels[0].status
            if (inspectionStatus == "") {
                cy.findByDataCy('close_insp').should('be.disabled')

            } else {
                cy.findByDataCy('close_insp').should('not.be.disabled')
            }

        })

    })
    it('should able to edit created inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.getRandomString().then((randomInspection) => {
            cy.log('Editing User defined ID')
            cy.findByText('User Defined ID').siblings('div')
                .click()
                .findByDataCy('edit_user_defined_id')
                .click({ force: true })
                .findByDataCy('user_defined_id')
                .clear()
                .type(randomInspection)
                .findByDataCy('save_user_defined_id')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            newInspection = randomInspection

            cy.log('Editing Trade')
            cy.findByText('Trade').siblings('div')
                .click()
                .findByDataCy('edit_trade')
                .click({ force: true })
                .findByDataCy('trade')
                .click()
                .get('.ui-dropdown-filter').type(inspectionData.EDIT_TRADE)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_trade')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Inspector')
            cy.findByText('Inspector').siblings('div')
                .click()
                .findByDataCy('edit_inspector')
                .click({ force: true })
                .findByDataCy('inspector')
                .click()
                .get('.ui-dropdown-filter').type(inspectionData.EDIT_ASSIGN_TO)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_inspector')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Point of contact')
            cy.findByText('Inspector').siblings('div')
                .click()
                .findByDataCy('edit_point_of_contact')
                .click({ force: true })
                .findByDataCy('point_of_contact')
                .click()
                .get('.ui-dropdown-filter').type(inspectionData.EDIT_ASSIGN_TO)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_point_of_contact')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Responsible Contractor')
            cy.findByText('Responsible Contractor').siblings('div')
                .click()
                .findByDataCy('edit_responsible_contractor')
                .click({ force: true })
                .get('input[placeholder="Company"]').clear()
                .type('katerra')
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_responsible_contractor')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Description')
            cy.findByText('Description').siblings('div')
                .click()
                .findByDataCy('edit_description')
                .click({ force: true })
                .findByDataCy('description')
                .type('edit description')
                .findByDataCy('save_description')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Inspection updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        })



    })
    it('should able to add and delete upload file while editing created inspection', () => {
        cy.server().route('GET', '**/cna/attachments/inspection/**').as('getAttachedFiles')
        cy.server().route('GET', '**/cna/V1/project/**/album/**/photos').as('getPhotos')
        cy.server().route('POST', '**/cna/attachments/inspection/**').as('uploadFile')
        cy.server().route('DELETE', '**/cna/attachments/**').as('deleteFile')
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.wait('@getAttachedFiles').then((xhr) => {
            let fileCount = xhr.response.body.data.length
            cy.log('number of fileCount ->', fileCount)
            if (fileCount > 0) {
                cy.get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            }

            fileCount = fileCount + 1
            cy.log('Upload file from documents')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains('Documents').click()
                .get('.ui-tree-toggler').click()
                .get('.treeFolder .ui-tree-toggler').click()
                .get('.ui-tree-container').contains('Cypress.pdf').click()
                .clickElement('upload')
                .wait('@uploadFile').its('status').should('eq', 201)
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            fileCount = fileCount + 1
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .log('Upload file from photos')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains(' Photos ').click()
                .wait('@getPhotos').its('status').should('eq', 200)
                .clickElement('select_photos_0')
                .clickElement('upload')
                .wait('@uploadFile').its('status').should('eq', 201)
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            fileCount = fileCount + 1
            const yourFixturePath = 'Cypress.pdf' // the file to be uploaded, from the cypress/fixtures/ directory
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .log('Upload pdf file from local')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains(' Local ').click()
                .clickElement('browse_files')
            cy.get('[type="file"]').attachFile(yourFixturePath, { force: true })
                .clickElement('upload')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('be.visible')

        })
        cy.log('deleting uploaded file')
            .log('clicking cancel button of delete file pop up')
            .clickElement('delete_uploaded_files_section_0')
            .get('#confirmPopup').should('exist')
            .get('#confirmPopup .modal-title').should('contain.text', 'Delete File')
            .get('.msg-break').should('contain.text', inspectionData.DEL_UPLOAD_FILE_TXT)
            .get('#confirmPopup .btn-outline-secondary').should('exist').click()

        cy.log('clicking OK button of delete file pop up')
            .clickElement('delete_uploaded_files_section_0')
            .get('#confirmPopup').should('exist')
            .findByRole('button', { name: 'OK' }).should('exist').click()
            .wait('@deleteFile').its('status').should('eq', 200)



    })
    it('should able to add and delete spec section while editing of created inspection', () => {

        cy.server().route('GET', '**/cna/V2/project/**/specifications/**').as('getSpecifications')
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.wait('@getInspectionDetails').then((xhr) => {
            let specificationCount = xhr.response.body.data.form_plugins.spec_section.value.length
            cy.log('number of specificationCount ->', specificationCount)
            if (specificationCount > 0) {
                cy.get('app-spec-section .badge-secondary').should('contain.text', specificationCount)
            }
            specificationCount = specificationCount + 1
            cy.log('Add specification')
                .log('Cancel add specification section popup')
                .clickElement('add_spec_section')
                .wait('@getSpecifications').its('status').should('eq', 200)
                .get('.modal-title').should('contain.text', 'Specification Section')
                .clickElement('close-spec')

                .log('Add specification')
                .clickElement('add_spec_section')
                .wait('@getSpecifications').its('status').should('eq', 200)
                .get('.modal-title').should('contain.text', 'Specification Section')
                .get('.ui-tree-toggler').click()
                .get('.ui-tree-container').contains('review - material').click()
                .clickElement('add-spec')
                .get('.ui-toast-detail').should('contain.text', 'Inspection updated.')
                .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-spec-section .badge-secondary').should('contain.text', specificationCount)

            cy.log('Deleting specifications')
                .log('clicking cancel button of delete spec pop up')
                .clickElement('delete_spec_section_0')
                .get('#confirmPopup').should('exist')
                .get('#confirmPopup .modal-title').should('contain.text', 'Delete Spec')
                .get('.msg-break').should('contain.text', inspectionData.DEL_SPEC_TXT)
                .get('#confirmPopup .btn-outline-secondary').should('exist').click()

            cy.log('clicking OK button of delete spec pop up')
                .clickElement('delete_spec_section_0')
                .get('#confirmPopup').should('exist')
                .findByRole('button', { name: 'OK' }).should('exist').click()

        })



    })
    it('Should verify count of associated drawing,add and delete distribution group while editing', () => {
        cy.server().route('PUT', '**/cmb/V1/distribution-list/**/group_users?admin_users=1').as('updatedDistributionlistUsers')
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.wait('@getInspectionDetails').then((xhr) => {
            let associatedDrawingsCount = xhr.response.body.data.associated_drawings.length
            let distributionListCount = xhr.response.body.data.distribution_list.users.length
            cy.log('number of associatedDrawingsCount ->', associatedDrawingsCount)
            if (associatedDrawingsCount > 0) {
                cy.get('app-associated-drawings-section .badge-secondary').should('contain.text', associatedDrawingsCount)

            } else if (associatedDrawingsCount == 0) {
                cy.get('app-associated-drawings-section .text-muted').should('contain.text', ' No Associated drawings found. ')

            }
            if (distributionListCount > 0) {
                cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)

            } else if (distributionListCount == 0) {
                cy.get('app-distribution-list-section .text-muted').should('contain.text', ' Click on \'+ New\' to add members. ')

            }
            cy.log('add empty distribution group')
                .clickElement('add_distribution_list')
                .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                .get('.modal-content').should('contain.text', inspectionData.ADD_D_LIST_TXT)
                .enterText('search', 'AutoTest_QA')
                .wait(1000)
                .get('#distPopup .ui-chkbox-icon').then((checkbox) => {
                    checkbox[0].click()
                })
                .clickElement('add')
                .get('.ui-toast-summary').should('exist')
                .get('.ui-toast-detail').should('contain.text', inspectionData.ADD_D_LIST_INFO_TXTX)

            cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                let addedUserCount = xhr.response.body.result.distribution_list.length
                if (addedUserCount > 0) {
                    distributionListCount = distributionListCount + addedUserCount
                    cy.get('.ui-toast-detail').should('contain.text', 'Inspection updated.')
                    cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                }

            })

            cy.log('adding non empty distribution group')
                .clickElement('add_distribution_list')
                .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                .get('.modal-content').should('contain.text', inspectionData.ADD_D_LIST_TXT)
                .enterText('search', 'cypress')
                .wait(1000)
                .get('.ui-chkbox-icon').then((role) => {
                    role[0].click()
                })
            cy.clickElement('add')
                .get('.ui-toast-summary').should('exist')
                .get('.ui-toast-detail').should('contain.text', inspectionData.ADD_D_LIST_INFO_TXTX)

            cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                let addedUserCount = xhr.response.body.result.distribution_list.length
                if (addedUserCount > 0) {
                    distributionListCount = distributionListCount + addedUserCount
                    cy.get('.ui-toast-detail').should('contain.text', 'Inspection updated.')
                    cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                }



                cy.log('adding user')
                    .clickElement('add_distribution_list')
                    .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                    .get('.modal-content').should('contain.text', inspectionData.ADD_D_LIST_TXT)
                    .get('.mat-tab-header').should('contain.text', 'Users').click()
                    .get('.ui-chkbox-icon').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('add')
                    .get('.ui-toast-summary').should('exist')
                    .get('.ui-toast-detail').should('contain.text', inspectionData.ADD_D_LIST_INFO_TXTX)
                    .get('.ui-toast-detail').should('contain.text', 'Inspection updated.')
                    .get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount + 1)
            })

            cy.log('Deleting User')
                .log('clicking cancel button of delete distribution list pop up')
                .clickElement('remove_dist0')
                .get('#confirmPopup').should('exist')
                .get('#confirmPopup .modal-title').should('contain.text', 'Delete')
                .get('.msg-break').should('contain.text', inspectionData.DEL_USER_TXT)
                .get('#confirmPopup .btn-outline-secondary').should('exist').click()

            cy.log('clicking Yes button of delete distribution list pop up')
                .clickElement('remove_dist0')
                .get('#confirmPopup').should('exist')
                .findByRole('button', { name: 'Yes' }).should('exist').click()
        })


    })
    it('should able to update result of fill inspection section', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
            .get('div.statusBarContainer label').should('have.class', 'uninspected')
            .clickElement('lable_pass_0')
            .get('div.statusBarContainer label').should('have.class', 'pass')
            .clickElement('lable_fail_0')
            .get('div.statusBarContainer label').should('have.class', 'fail')
            .clickElement('lable_na_0')
            .get('div.statusBarContainer label').should('have.class', 'na')
            .clickElement('mark_all_as_0')
            .clickElement('mark_all_as_pass_0')
            .get('div.statusBarContainer label').should('have.class', 'pass')
            .clickElement('mark_all_as_0')
            .clickElement('mark_all_as_fail_0')
            .get('div.statusBarContainer label').should('have.class', 'fail')
            .clickElement('mark_all_as_0')
            .clickElement('mark_all_as_na_0')
            .get('div.statusBarContainer label').should('have.class', 'na')
            .findByDataCy('section_export_0').should('exist')


    })
    it('should able to add,delete comment and validate attachement of fill inspection section', () => {
        cy.server().route('POST', '**/cna/comments/inspection_label/**').as('addComments')
        cy.server().route('DELETE', '**/cna/comments/inspection_label/**').as('deleteComments')
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
            .clickElement('view_comment_0')
            .enterText('comment_0', 'cbhsdh')
            .clickElement('add_comment_0')
        cy.wait('@addComments').its('status').should('eq', 201)
            .get('.ui-toast-summary').should('exist')
        cy.contains('Comment Added Successfully').should('exist')
            .clickElement('delete_comment_0')
            .get('#confirmPopup .modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete File')
            .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete this comment?')
        cy.findByRole('button', { name: 'OK' }).should('exist').click()
        cy.wait('@deleteComments').its('status').should('eq', 200)
            .get('.ui-toast-summary').should('exist')
        cy.contains('Deleted Successfully').should('exist')
            .clickElement('close_comments')
            .clickElement('view_label_attach_0')
            .get('#attachmentsPopup').should('exist')
            .get('#attachmentsPopup .close').click()

    })

    it('should able to close,reopen and delete created inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('search inspection')
        cy.enterText('insp_search', newInspection)
            .get('a[data-cy="inspection_id"]').click()
        cy.wait('@getInspectionDetails').then((xhr) => {
            const inspectionStatus = xhr.response.body.data.sections[0].labels[0].status
            if (inspectionStatus == "") {
                cy.findByDataCy('close_insp').should('be.disabled')
                    .clickElement('lable_pass_0')
                closeInspection()
                reOpenInspection()
                closeInspection()
                deleteInspection()


            } else {
                cy.findByDataCy('close_insp').should('not.be.disabled')
            }

        })

    })

    it('Should verify filters fields of inspection', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('verifying all fields in filters')
            .findByDataCy('inspection_filter_button').should('exist').click()
            .get('.sidebar-header > .d-inline-block').should('contain.text', 'Filters')
            .findByDataCy('clear-all').should('exist')
            .findByDataCy('created_by').should('exist')
            .findByDataCy('point_of_contact').should('exist')
            .findByDataCy('inspector').should('exist')
            .findByDataCy('state').should('exist')
            .findByDataCy('inspection_template').should('exist')
            .findByDataCy('trade').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('inspection_date').should('exist')
            .findByDataCy('description').should('exist')
            .findByDataCy('reset').should('exist')
            .findByDataCy('apply_filters').should('exist')
    })
    it('Should verify clear all and reset functionality of observation filters', () => {
        cy.wait('@getInspectionForms').its('status').should('eq', 200)
        cy.log('clicking on filters button')
            .findByDataCy('inspection_filter_button').should('exist').click()
        fillALLFilters()
        cy.clickElement('clear-all')
        fillALLFilters()
        cy.clickElement('reset')


    })
})
const createInspection = (inspectionName) => {
    cy.log('clicking on create inspection page')
    cy.clickElement('create_inspection')
        .get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
        .findByDataCy('user_defined_id').type(inspectionName)
        .findByDataCy('type').click()
        .get('.ui-dropdown-filter').type(inspectionData.TYPE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('inspection_template')
        .get('.ui-dropdown-filter').type(inspectionData.TEMPLATENAME)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('trade')
        .get('.ui-dropdown-filter').type(inspectionData.TRADE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('inspection_date').click()
        .get('.ui-state-highlight').click()

    cy.clickElement('inspector')
        .get('.ui-dropdown-filter').type(inspectionData.ASSIGN_TO)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('point_of_contact')
        .get('.ui-dropdown-filter').type(inspectionData.ASSIGN_TO)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.findByDataCy('responsible_contractor').type('katerra')
        .get('[role="option"] span')
        .then((role) => {
            role[0].click()
        })
    cy.findByDataCy('priority').click()
        .get('.ui-dropdown-filter').type(inspectionData.PRIORITY)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })


    cy.get('div.input-icons i.fa-plus').click()
    cy.wait('@getProjectLocations').then((xhr) => {
        const locationsCount = xhr.response.body.locations.length
        cy.get('#locationPopup').should('exist')
        if (locationsCount == 0) {
            cy.log('verifying location ')
            cy.get('.modal-body div').should('contain.text', 'No location data available.')
            cy.findByRole('button', { name: 'Confirm' }).should('be.disabled')

        }
        cy.findByRole('button', { name: 'Cancel' }).should('exist').click()
    })

    cy.clickElement('create_inspection')
    cy.wait('@createInspection').its('status').should('eq', 201)
    cy.get('.ui-toast-summary').should('exist')
    cy.contains('Inspection created.').should('exist')
    newInspection = inspectionName
}
const closeInspection = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('closing created Inspection')
        .clickElement('close_insp')
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Close Inspection')
        .get('.modal-body label').should('exist').and('contain.text', 'Are you sure you want to close Inspection?')
        .get('.comment-modal-footer .btn-outline-secondary').should('exist')
    cy.findByRole('button', { name: 'Confirm' }).should('exist').click()
        .wait('@updateInspectionState').its('status').should('eq', 200)
        .get('.ui-toast-summary').should('exist')
    cy.contains('Inspection Status Updated.').should('exist')

}
const reOpenInspection = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('reopening closed inspection')
        .clickElement('repoen_insp')
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Reopen Inspection')
        .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to Reopen Inspection?')
    cy.findByRole('button', { name: 'OK' }).should('exist').click()
        .get('.ui-toast-summary').should('exist')
    cy.contains('Inspection Status Updated.').should('exist')
        .wait('@updateInspectionState').its('status').should('eq', 200)
}
const deleteInspection = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('deleting closed inspection')
        .clickElement('delete_insp')
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Inspection')
        .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete this Inspection? If you choose to proceed, the link with Drawings (if any) will also be deleted.')
    cy.findByRole('button', { name: 'Cancel' }).should('exist').click()

        .clickElement('delete_insp')


        .get('.modal-content').should('exist')
    cy.findByRole('button', { name: 'OK' }).should('exist').click()
        .wait('@deleteInspection').its('status').should('eq', 200)
        .get('.ui-toast-summary').should('exist')
    cy.contains('Inspection Deleted').should('exist')


}
const fillALLFilters = () => {
    cy.clickElement('created_by')
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.clickElement('created_by')

    cy.get('p-multiselect[data-cy="point_of_contact"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="point_of_contact"]').click()

    cy.get('p-multiselect[data-cy="inspector"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="inspector"]').click()

    cy.get('p-multiselect[data-cy="state"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="state"]').click()

    cy.get('p-multiselect[data-cy="inspection_template"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="inspection_template"]').click()

    cy.get('p-multiselect[data-cy="trade"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="trade"]').click()

    cy.get('p-multiselect[data-cy="type"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="type"]').click()

    cy.get('p-calendar[data-cy="inspection_date"]').click()
        .get('.ui-state-highlight').click()
        .get('.ui-state-highlight').click()
    cy.contains('Inspection Date').click()

    cy.get('input[data-cy="description"]').type('cypress testing')


}