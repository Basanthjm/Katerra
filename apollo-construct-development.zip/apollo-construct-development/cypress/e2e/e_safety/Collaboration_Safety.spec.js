import '../../support/setup-tests'
import { getUser } from '../../support/users'

const safetyConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Collaboration Safety ', () => {

    let collaborationSafetyTittle

    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cna/forms/safety?project_id=**').as('getSafetyListCount')
        cy.server().route('GET', '/tenant/members?sortKey=name&sort=1&pageSize=500&type=project&typeId=**&includeUsers=true').as('getTenantMembers')
        cy.server().route('GET', '/cmb/config_dropdown/**').as('getSafetyConfig')
        cy.server().route('GET', '/cna/V2/project/**/history/SAFETY/**').as('getSafetyHistory')
        cy.server().route('PATCH', '/cna/forms/safety/**/state').as('updateSafetyState')
        cy.server().route('DELETE', '/cna/forms/safety/**project_id=**').as('deleteSafety')
        cy.server().route('PATCH', '/cna/forms/safety/**').as('updateSafetyDetails')
        cy.server().route('GET', '/cmb/list_view/safety').as('getSafetyList')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(safetyConstants.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Safety')

    })

    it('should check safety landing page fields', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        cy.get('.page-header').should('contain.text', 'List Safety Observations')
            .findByDataCy('searchField').should('exist')
            .findByDataCy('Create-Safety').should('exist')
            .findByDataCy('more').should('exist')
            .clickElement('more')
            .findByDataCy('CSV').should('exist')
            .findByDataCy('PDF').should('exist')
            .findByDataCy('filters').should('exist')

    });

    it('Should check all fields of filter and functionlity of clear All', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        cy.log('Checking filter fields')
            .clickElement('filters')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('created_by').should('exist')
            .findByDataCy('company_involved').should('exist')
            .findByDataCy('work_activity').should('exist')
            .findByDataCy('potential').should('exist')
            .findByDataCy('effect').should('exist')
            .findByDataCy('state').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('due_date').should('exist')

        cy.log('Checking Clear All functionlaity')
        // data-cy duplictae //

    });

    it('Should validate safety list counts', () => {

        cy.wait('@getSafetyListCount').then((xhr) => {
            const safetyListCounts = xhr.response.body.data.count
            cy.log('number of safetys ->', safetyListCounts)
            if (safetyListCounts > 50) {
                cy.findByText(`1-50 of ${safetyListCounts}`).should('exist')
            }
            else {
                cy.findByText(`1-${safetyListCounts} of ${safetyListCounts}`).should('exist')
            }
        })

    });

    it('Should search for empty safety and validate message', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        cy.findByDataCy('searchField')
            .type(safetyConstants.EMPTY_RFI_SEARCH)
            .get('.empty-msg')
            .should('contain.text', 'No results found.')
            .get('.search-cont > .form-control')
            .clear()

    });

    it('Should create safety draft and discard and validate History', () => {

        cy.server().route('GET', '/cna/V2/project/**/history/SAFETY/**').as('getSafetyHistory')
        cy.server().route('POST', '/cna/forms/safety/_draft').as('updateDrfat')

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        cy.log('Creating empty draft')
            .clickElement('Create-Safety')
            .wait('@getSafetyConfig').its('status').should('eq', 200)
            .get('.header-md').should('contain.text', 'Create Safety Observation')
            .clickElement('save-draft')
            .wait('@updateDrfat').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft created.')

        cy.log('Validating safety History for creating draft')
        cy.wait('@getSafetyHistory').then((xhr) => {
            cy.clickElement('safetyHistory')
            const safetydraftCreatedDateAndTime = xhr.response.body.success[0].updated_at
            cy.log(safetydraftCreatedDateAndTime)
            cy.findByText(safetydraftCreatedDateAndTime).should('exist')
            cy.get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            cy.get('#safetyHistory').should('contain.text', 'Draft created')
        })

        cy.log('Discarding draft')
        cy.findByText('Discard Draft').click()
            .wait('@getSafetyListCount').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft discarded successfully.')

    });

    it('Should create Safety, Export and validate counts', () => {

        cy.server().route('POST', '/cna/reports/SAFETY').as('ExportReport')

        cy.reload()
        cy.wait('@getSafetyListCount').then((xhr) => {
            const safetyListCountsBefore = xhr.response.body.data.count
            cy.log('number of safetys ->', safetyListCountsBefore)

            cy.log('Creating safety')
            cy.server().route('GET', '/cmb/config_dropdown/**').as('getSafetyConfig')
            cy.clickElement('Create-Safety')
            cy.wait('@getSafetyConfig').its('status').should('eq', 200)
            cy.clickElement('assignee')
            cy.get(':nth-child(1) > .ui-multiselect-item').click()
            cy.clickElement('due_date')
            cy.get('.ui-datepicker-today > .ui-state-default').click()
            cy.getRandomString().then(safetyTittle => {
                cy.findByDataCy('title').type(safetyTittle)
                collaborationSafetyTittle = safetyTittle
                cy.clickElement('potential')
                    .get('[role="option"] span').then(role => {
                        role[1].click()
                    })
                cy.clickElement('type')
                    .get('[role="option"] span').then(role => {
                        role[1].click()
                    })
                cy.clickElement('effect')
                    .get('[role="option"] span').then(role => {
                        role[1].click()
                    })
                cy.get('.ql-editor').type('Safety precutions')
                cy.clickElement('create-safety')
                cy.wait('@getSafetyHistory').its('status').should('eq', 200)

                cy.log('Exporting into pdf')
                cy.findByText('Export').click()
                    .wait('@ExportReport').its('status').should('eq', 201)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Report Exported')

            })

            cy.clickElement('Collaboration')
            cy.clickElement('Safety')
            const safetyListCounts = safetyListCountsBefore + 1
            cy.log('number of safetys ->', safetyListCounts)
            if (safetyListCounts > 50) {
                cy.findByText(`1-50 of ${safetyListCounts}`).should('exist')
            }
            else {
                cy.findByText(`1-${safetyListCounts} of ${safetyListCounts}`).should('exist')
            }

        })

    });

    it('Should serach created safety and delete it', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        cy.findByDataCy('searchField')
            .type(collaborationSafetyTittle)
        cy.get('[data-cy=route_title_0] > .table-column')
            .should('contain.text', collaborationSafetyTittle)
            .click()
            .wait('@getSafetyHistory').its('status').should('eq', 200)
        deleteSafety()

    });

    it('Should verify create safety page fields', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
            .clickElement('Create-Safety')
            .wait('@getSafetyConfig').its('status').should('eq', 200)
            .findByDataCy('assignee').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('title').should('exist')
            .findByDataCy('potential').should('exist')
            .findByDataCy('type').should('exist')
            .findByDataCy('trade').should('exist')
            .findByDataCy('effect').should('exist')
            .findByDataCy('work_activity').should('exist')
            .findByDataCy('company_involved').should('exist')
            .findByDataCy('location').should('exist')
            .findByDataCy('description').should('exist')
    });

    it('Should verify all Edit safety page fields', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()

        cy.log('Verifyig Top edit header fields')
            .findByDataCy('safetyDetails').should('exist')
            .findByDataCy('distribution').should('exist')
            .findByDataCy('uploadedFiles').should('exist')
            .findByDataCy('correctiveActions').should('exist')
            .findByDataCy('safetyHistory').should('exist')

        cy.log('Verifyig distribution list fields')
            .clickElement('distribution')
            .get('.card-header').contains('Distribution List').should('exist')
            .findByDataCy('add_distribution_list').should('exist')

        cy.log('Verifyig add distribution list fields')
            .clickElement('add_distribution_list')
            .get('.modal-title').contains('Distribution List').should('exist')
            .findByDataCy('search').should('exist')
            .findByDataCy('cancel').should('exist')
            .findByDataCy('add').should('exist')
            .clickElement('cancel')

        cy.log('Verifyig Upload files fields')
            .get('.card-header').contains('Uploaded Files').should('exist')
            .findByDataCy('add_uploaded_files_section').should('exist')
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').contains('Upload File').should('exist')
            .get('.mat-tab-labels').contains(' Selected Files (0)').should('exist')
            .get('.mat-tab-labels').contains('Local').should('exist')
            .get('.mat-tab-labels').contains('Documents').should('exist')
            .get('.mat-tab-labels').contains('Photos').should('exist')
            .get('.mat-tab-labels').contains('Drawings').should('exist')
            .findByDataCy('upload').should('exist')
            .findByDataCy('close_attachments_popup').should('exist')
            .clickElement('close_attachments_popup')

        cy.log('Verifyig corrective actions fields')
            .get('.card-header').contains('Corrective Actions').should('exist')
            .findByDataCy('details-description-area').should('exist')
            .findByDataCy('edit-icon').should('exist')
            .findByDataCy('add-corrective-actions').should('exist')

        cy.log('Verifyig add corrective actions fields')
            .clickElement('add-corrective-actions')
            .findByDataCy('Sequential').should('exist')
            .findByDataCy('Parallel').should('exist')
            .findByDataCy('name0').should('exist')
            .findByDataCy('assignee0').should('exist')
            .findByDataCy('duration0').should('exist')
            .findByDataCy('due_date0').should('exist')
            .findByDataCy('Remove-action0').should('exist')
            .findByDataCy('Save-action0').should('exist')
            .clickElement('Remove-action0')

        cy.log('Verifyig History tab columns')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', 'Safety Observation History')
            .get('#safetyHistory').contains('Date').should('exist')
            .get('#safetyHistory').contains('Action By').should('exist')
            .get('#safetyHistory').contains('Action').should('exist')

        deleteSafety()
    });

    it('Should create safety,Close,Re-open and delete and validate History', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()

        cy.log('Closing safety')
            .clickElement('Close-Safety')
            .get('.modal-title').should('contain.text', 'Close Safety Observation?')
            .get('.comment-modal-footer').contains('Yes').click()
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation closed.')

        cy.log('Re-opening safety')
            .clickElement('reopen-safety')
            .get('.modal-title').should('contain.text', 'Reopen Safety Observation')
            .get('.modal-footer').contains('OK').click()
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation Reopened.')

        cy.log('Again closing to delete safety')
            .clickElement('Close-Safety')
        cy.get('.comment-modal-footer').contains('Yes').click()
            .wait('@updateSafetyDetails').its('status').should('eq', 200)

        cy.log('Validating safety History for creating, Re-opening and closing')
            .wait('@getSafetyHistory')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#safetyHistory').should('contain.text', 'Safety Observation created')
            .get('#safetyHistory').should('contain.text', 'Safety Observation closed')
            .get('#safetyHistory').should('contain.text', 'Safety Observation reopened')

        cy.log('Deleting safety')
            .clickElement('delete-safety')
            .get('.modal-title').should('contain.text', 'Delete Safety Observation')
            .get('.modal-footer').contains('OK').click()
            .wait('@deleteSafety').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation Deleted.')
            .wait('@getSafetyListCount').its('status').should('eq', 200)
    });

    it('Should Edit Safety observation details and validate History', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()
        cy.log('Veryfing Assignee filed edit,save,cancle tools')
            .get(':nth-child(1) > .form-group').trigger('mouseover')
            .findByDataCy('edit_assignee').click({ force: true })
            .findByDataCy('assignee').should('contain.text', loggedInUser.name)
            .findByDataCy('save_assignee').click()
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation updated.')

        cy.log('Veryfing due date edit tool')
            .get(':nth-child(2) > .form-group').trigger('mouseover')
            .findByDataCy('edit_due_date').should('exist')

        cy.log('Editing Tittle')
        cy.get(':nth-child(3) > .form-group').trigger('mouseover')
            .findByDataCy('edit_title').click({ force: true })
            .get('.form-control').clear()
            .get('.form-control').type(safetyConstants.SAFETY_TITTLE)
            .findByDataCy('save_title').click()
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation updated.')

        cy.log('Veryfing potential edit tool')
            .get(':nth-child(4) > .form-group').trigger('mouseover')
            .findByDataCy('edit_potential').should('exist')

        cy.log('Veryfing type edit tool')
            .get(':nth-child(5) > .form-group').trigger('mouseover')
            .findByDataCy('edit_type').should('exist')

        cy.log('Veryfing subtype edit tool')
            .get(':nth-child(6) > .form-group').trigger('mouseover')
            .findByDataCy('edit_sub_type').should('exist')

        cy.log('Editing Trade')
            .get(':nth-child(7) > .form-group').trigger('mouseover')
            .findByDataCy('edit_trade').click({ force: true })
            .clickElement('trade')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .findByDataCy('cancel_trade').should('exist')
            .clickElement('save_trade')
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation updated.')

        cy.log('checking warning message')
            .get(':nth-child(7) > .form-group').trigger('mouseover')
            .findByDataCy('edit_work_activity').click({ force: true })
            .get(':nth-child(11) > .form-group').trigger('mouseover')
            .findByDataCy('edit_location').click({ force: true })
            .get('.ui-toast-detail')
            .should('contain.text', 'Please update one field at a time.')
            .clickElement('cancel_work_activity')

        cy.log('Adding location')
            .get(':nth-child(11) > .form-group').trigger('mouseover')
            .findByDataCy('edit_location').click({ force: true })
            .clickElement('plus')
            .get('.ui-tree-toggler').click({ force: true })
            .get('.treeHeight').contains('Ground floor').click()
            .get('.modal-footer').contains('Confirm').click()
            .clickElement('save_location')

        cy.log('Editing description')
            .get('.col-xl-12 > .form-group').trigger('mouseover')
            .findByDataCy('edit_description').click({ force: true })
            .get('.ql-editor').clear()
            .get('.ql-editor')
            .type(safetyConstants.SAFETY_DESCRIPTION)
            .clickElement('save_description')

        cy.log('Validating History for Editing safety details')
            .wait('@getSafetyHistory')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#safetyHistory').should('contain.text', 'Title updated to ' + safetyConstants.SAFETY_TITTLE)
            .get('#safetyHistory').should('contain.text', 'Description updated to ' + safetyConstants.SAFETY_DESCRIPTION)

        deleteSafety()

    });

    it('Should Add Distribution List and validate History', () => {

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()
        cy.log('Adding distribution groups')
            .get('#section3').should('contain.text', 'Distribution List')
            .clickElement('add_distribution_list')

        cy.log('Adding Distribution')
            .get('.modal-title').should('contain.text', 'Distribution List')
            .get('.modal-content').should('contain.text', 'Only members who are part of project')
            .get('.modal-content').should('contain.text', 'Distribution Groups')
            .enterText('search', 'cy')
            .get(':nth-child(1) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()

        cy.log('Adding user')
            .get('.mat-tab-header').should('contain.text', 'Users').click()
            .enterText('search_users', safetyConstants.RFI_DISTRIBUTION_USER)
            .get(':nth-child(1) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()

            .findByDataCy('cancel').should('exist')
            .clickElement('add')
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Observation updated.')

        cy.log('Validating History for adding distribution group')
            .wait('@getSafetyHistory')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#safetyHistory').should('contain.text', safetyConstants.RFI_DISTRIBUTION_USER + ' added to Distribution list')

        deleteSafety()
    });

    it('Should upload files and validate History', () => {

        cy.server().route('POST', '/cna/attachments/safety/**').as('uploadFile')
        cy.server().route('DELETE', '/cna/attachments/**/**').as('deleteFile')

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()
        cy.clickElement('distribution')
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').should('contain.text', 'Upload File')

        const yourFixturePath = 'code.png';
        cy.log('Uploading file from local')
            .get('.mat-tab-labels').contains('Local').click()
            .get("[data-cy='browse_files']").attachFile(yourFixturePath, { force: true });

        cy.log('Uploading file from Documents')
            .get('.mat-tab-labels').contains('Documents').click()
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains('Cypress.pdf').click()

        cy.log('Uploading photos')
            .get('.mat-tab-labels').contains('Photos').click()
            .clickElement('select_photos_0')

        cy.log('Uploading Drawings')
            .get('.mat-tab-labels').contains('Drawings').should('exist')

        cy.clickElement('upload')
        cy.wait('@uploadFile').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Attachment(s) saved successfully')

        cy.log('Deleting uploaded files')
            .clickElement('delete_uploaded_files_section_0')
            .get('.modal-title').should('contain.text', 'Delete File')
            .get('.modal-content').contains('OK').click()
            .wait('@deleteFile').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'File deleted successfully')

        cy.clickElement('delete_uploaded_files_section_0')
            .get('.modal-content').contains('OK').click()

        cy.log('Validating safety History for uploading files')
            .wait('@getSafetyHistory')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#safetyHistory').should('contain.text', 'Cypress.pdf added')
            .get('#safetyHistory').should('contain.text', 'Cypress.pdf removed')

        deleteSafety()

    });

    it('Should Add,Edit,close,Re-open and delete corrective Actions and validate History', () => {

        cy.server().route('GET', '/cna/comments/corrective_action/**').as('addCorrectiveActions')
        cy.server().route('POST', '/file_management/s3/upload_info').as('uploadInfo')
        cy.server().route('POST', '/cna/attachments/corrective_action/**').as('attchFileToCorrectiveActions')
        cy.server().route('POST', '/cna/comments/corrective_action/**').as('updateComments')
        cy.server().route('PATCH', '/cna/forms/safety/**/plugin/CORRECTIVE_ACTIONS/**').as('updateCorrectiveAction')
        cy.server().route('PATCH', '/cna/forms/safety/**/plugin/CORRECTIVE_ACTIONS/**/CLOSED').as('closeCorrectiveAction')
        cy.server().route('PATCH', '/cna/forms/safety/**/plugin/CORRECTIVE_ACTIONS/**/OPEN').as('openCorrectiveAction')
        cy.server().route('DELETE', '/cna/forms/safety/**/plugin/CORRECTIVE_ACTIONS/**').as('deleteCorrectiveAction')

        cy.wait('@getSafetyListCount').its('status').should('eq', 200)
        createSafety()
        cy.clickElement('correctiveActions')
            .get('#correctiveActions').should('contain.text', 'Corrective Actions ')

        cy.log('Adding Corrective Actions description')
            .clickElement('edit-icon')
            .findByDataCy('details-description-area').type(safetyConstants.CORRECTIVE_ACTIONS_DESC)
            .findByDataCy('cancle-desc').should('exist')
            .clickElement('save-desc')
            .wait('@updateSafetyDetails').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Corrective Action description updated.')

        cy.log('Adding Corrective Actions')
            .clickElement('add-corrective-actions')
            .findByDataCy('Sequential').should('exist')
            .findByDataCy('Parallel').should('exist')
            .enterText('name0', safetyConstants.CORRECTIVE_ACTION_NAME)
            .clickElement('assignee0')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .enterText('duration0', '1')
            .findByDataCy('Remove-action0').should('exist')
            .clickElement('Save-action0')
            .wait('@addCorrectiveActions').its('status').should('eq', 200)

        cy.log('Editing Corrective Actions')
            .clickElement('Edit-action0')
            .findByDataCy('name0').clear()
            .type(safetyConstants.CORRECTIVE_ACTION_NAME_EDIT)
            .findByDataCy('duration0').clear()
            .type('2')
            .findByDataCy('Cancel-changes0').should('exist')
            .clickElement('Update0')
            .wait('@updateCorrectiveAction').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Corrective Action Updated')

        // Scroll attribute not exist //
        // cy.log('Adding attachment in corrective actions')
        //     .clickElement('add-attachments0')
        //     .get('.modal-title').should('contain.text', 'Upload File')
        // const yourFixturePath = 'code.png';
        // cy.log('Uploading file from local')
        //     .get('.mat-tab-labels').contains('Local').click()
        //     .get("[data-cy='browse_files']").attachFile(yourFixturePath, { force: true });
        // cy.clickElement('upload')
        //     .wait('@uploadInfo').its('status').should('eq', 200)
        //     .wait('@attchFileToCorrectiveActions').its('status').should('eq', 201)
        //     .get('.ui-toast-detail')
        //     .should('contain.text', 'Corrective action attachment(s) saved successfully')

        // cy.log('Adding comments to corrective actions')
        //     .clickElement('add-comments0')
        //     .get('.ql-editor').type('Corretive actions comments are added')
        //     .get('.modal-footer').contains('Add Comment').click()
        //     .wait('@updateComments').its('status').should('eq', 201)
        //     .get('.close').click()

        cy.log('closing corrective actions')
            .findByDataCy('close-action0').click({ force: true })
            .get('.modal-body').should('contain.text', 'Are you sure you want to close this action?')
            .get('.modal-footer').contains('Okay').click()
            .wait('@closeCorrectiveAction').its('status').should('eq', 200)

        cy.log('Re-opening coreective actions')
            .findByDataCy('reopen-action0').click({ force: true })
            .get('.modal-body').should('contain.text', 'Are you sure you want to reopen the action?')
            .get('.modal-footer').contains('Okay').click()
            .wait('@openCorrectiveAction').its('status').should('eq', 200)

        cy.log('Delete coreective actions')
            .findByDataCy('Delete-action0').click({ force: true })
            .get('.modal-body').should('contain.text', 'Are you sure you want to delete this Corrective Action?')
            .get('.modal-footer').contains('Yes').click()
            .wait('@deleteCorrectiveAction').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety Corrective Action deleted.')

        cy.log('Validating safety History for creating, Re-opening and closing')
            .wait('@getSafetyHistory')
            .clickElement('safetyHistory')
            .get('#safetyHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#safetyHistory').should('contain.text', 'Safety Observation created')
            .get('#safetyHistory').should('contain.text', 'Corrective Action Description updated to ' + safetyConstants.CORRECTIVE_ACTIONS_DESC)
            .get('#safetyHistory').should('contain.text', 'New Corrective Action ' + safetyConstants.CORRECTIVE_ACTION_NAME + ' added')
            .get('#safetyHistory').should('contain.text', 'Task name updated to ' + safetyConstants.CORRECTIVE_ACTION_NAME_EDIT + ' from ' + safetyConstants.CORRECTIVE_ACTION_NAME)
            .get('#safetyHistory').should('contain.text', 'Duration of ' + safetyConstants.CORRECTIVE_ACTION_NAME_EDIT + ' update to 2 from 1')
            .get('#safetyHistory').should('contain.text', safetyConstants.CORRECTIVE_ACTION_NAME_EDIT + ' closed')
            .get('#safetyHistory').should('contain.text', safetyConstants.CORRECTIVE_ACTION_NAME_EDIT + ' reopened')
            .get('#safetyHistory').should('contain.text', 'Corrective Action ' + safetyConstants.CORRECTIVE_ACTION_NAME_EDIT + ' deleted')

    });
})

const createSafety = function () {

    let collaborationSafetyTittle

    cy.server().route('GET', '/cmb/config_dropdown/**').as('getSafetyConfig')

    cy.clickElement('Create-Safety')
    cy.wait('@getSafetyConfig').its('status').should('eq', 200)
    cy.clickElement('assignee')
    cy.get('.ui-multiselect-filter-container > .ui-inputtext').type(loggedInUser.name)
    cy.findByText(loggedInUser.name).click()
    cy.clickElement('due_date')
    cy.get('.ui-datepicker-today > .ui-state-default').click()
    cy.getRandomString().then(safetyTittle => {
        cy.findByDataCy('title').type(safetyTittle)
        collaborationSafetyTittle = safetyTittle
        cy.clickElement('potential')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('type')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.clickElement('effect')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
        cy.get('.ql-editor').type('Safety precutions')
        cy.clickElement('create-safety')
        cy.wait('@getSafetyHistory').its('status').should('eq', 200)

    })

}
const deleteSafety = function () {

    cy.clickElement('Close-Safety')
    cy.get('.modal-title').should('contain.text', 'Close Safety Observation?')
    cy.get('.comment-modal-footer').contains('Yes').click()
        .wait('@updateSafetyDetails').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Safety Observation closed.')

    cy.clickElement('delete-safety')
    cy.get('.modal-title').should('contain.text', 'Delete Safety Observation')
    cy.get('.modal-footer').contains('OK').click()
        .wait('@deleteSafety').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Safety Observation Deleted.')
        .wait('@getSafetyListCount').its('status').should('eq', 200)

}