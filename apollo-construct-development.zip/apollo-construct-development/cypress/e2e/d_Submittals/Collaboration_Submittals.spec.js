import '../../support/setup-tests'
const SubmittalsData = require('../../support/constants')
let newInspection = SubmittalsData.OBSERVATION_NAME
let newPackage = SubmittalsData.PACKAGE_NAME
let newSubmittals = SubmittalsData.SUBMITTAL_NAME
describe('Collaboration Submittals', () => {

    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '**/cna/forms/submittal?project_id=**').as('getSubmittalsForms')
        cy.server().route('GET', '**/cmb/templates/submittal').as('getSubmittalsTemplates')
        cy.server().route('GET', '**/cmb/V1/configurations/trades').as('getSubmittalsTrades')
        cy.server().route('GET', '**/cna/V1/project/**/unlinked-submittals/package').as('getUnlinkedSubmittals')
        cy.server().route('GET', '**/cna/V1/project/**/package/**').as('getPackageDetails')
        cy.server().route('GET', '**/cna/forms/submittal/**?project_id=**').as('getSubmittalDetails')
        cy.server().route('POST', '**/cna/V1/project/**/package').as('postCreatePackage')
        cy.server().route('DELETE', '**/cna/V1/project/**/package/**').as('deletePackage')
        cy.server().route('GET', '**/cna/V2/project/**/specifications/**').as('getSpecifications')
        cy.server().route('POST', '**cna/forms/submittal').as('postCreateSubmittal')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(SubmittalsData.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Submittals')

    })
    it('Should validate submittals landing page buttons', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .log('verifying all buttons in submittals landing page')
            .findByDataCy('all-submittals').should('be.visible').and('have.attr', 'href')
            .findByDataCy('my-submittals').should('be.visible').and('have.attr', 'href')
            .findByDataCy('create').should('exist')
            .clickElement('create')
            .findByDataCy('create_submittal').should('be.visible').and('have.attr', 'href')
            .findByDataCy('import_submittals').should('exist')
            .get('a[data-cy="package"]').should('be.visible').and('have.attr', 'href')
            .log('verify export button exist')
            .findByDataCy('more').should('exist')
            .findByDataCy('filters').should('exist')
    })
    it('Should verify fill mandatory field alert message while creating empty submittals', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.log('clicking on create submittals page')
            .clickElement('create')
            .clickElement('create_submittal')
            .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
            .wait('@getSubmittalsTemplates').its('status').should('eq', 200)
            .wait('@getSubmittalsTrades').its('status').should('eq', 200)
            .clickElement('create_submittal')
            .get('.ui-toast-summary').should('exist')
        cy.contains('Please fill all mandatory fields.').should('exist')
    })
    it('should validate count of submittals', () => {
        cy.wait('@getSubmittalsForms').then((xhr) => {
            const submittalsCount = xhr.response.body.data.count
            cy.log('number of submittalsCount ->', submittalsCount)
            if (submittalsCount == 0) {
                cy.get('.empty-msg span').should('exist').and('contain.text', 'No Submittals have been added yet')
            } else if (submittalsCount > 50) {
                cy.findByText(`1-50 of ${submittalsCount}`).should('exist')
                cy.findByDataCy('next').should('exist')
                cy.findByDataCy('last_page').should('exist')
            } else {
                cy.findByText(`1-${submittalsCount} of ${submittalsCount}`)
                    .should('exist')

            }

        })

    })
    it('Should able to save draft and delete draft of submittals', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.log('clicking on create submittals pages')
            .clickElement('create')
            .clickElement('create_submittal')
            .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
            .wait('@getSubmittalsTemplates').its('status').should('eq', 200)
            .wait('@getSubmittalsTrades').its('status').should('eq', 200)
            .clickElement('save_draft')
            .get('.ui-toast-summary').should('exist')
        cy.contains('Draft created.').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            .clickElement('Discard_Draft')
            .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Discard Submittal')
            .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to discard this submittal. Do you wish to proceed?')
        cy.findByRole('button', { name: 'Yes, Discard' }).should('exist').click()
            .get('.ui-toast-summary').should('exist')
        cy.contains('Draft discarded').should('exist')
    })
    it('Should verify alert message of save workflow of empty draft submittals', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.log('clicking on create submittals pages')
            .clickElement('create')
            .clickElement('create_submittal')
            .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
            .wait('@getSubmittalsTemplates').its('status').should('eq', 200)
            .wait('@getSubmittalsTrades').its('status').should('eq', 200)
            .clickElement('save_draft')
            .get('.ui-toast-summary').should('exist')
        cy.contains('Draft created.').should('exist')
            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            .clickElement('Save_Workflow')
            .get('.ui-toast-summary').should('exist')
        cy.contains('Nothing to update.').should('exist')
            .clickElement('Discard_Draft')
            .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Discard Submittal')
            .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to discard this submittal. Do you wish to proceed?')
        cy.findByRole('button', { name: 'Yes, Discard' }).should('exist').click()
            .get('.ui-toast-summary').should('exist')
        cy.contains('Draft discarded').should('exist')
    })
    it('Should able to create new package', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomPackage) => {
            createPackage(randomPackage)
        })
    })
    it('Should able to search created package and edit', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newPackage)
            .clickElement('submittal_id_0')
            .wait('@getPackageDetails').its('status').should('eq', 200)
        cy.getRandomString().then((editPackageName) => {
            cy.log('Editing Title')
            cy.findByText('TITLE').siblings('div')
                .click()
                .findByDataCy('edit_title')
                .click({ force: true })
                .findByDataCy('title')
                .clear()
                .type(editPackageName)
                .findByDataCy('save_title')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Package Updated Successfully').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            newPackage = editPackageName

            cy.log('Editing Number')
            cy.findByText('NUMBER').siblings('div')
                .click()
                .findByDataCy('edit_num')
                .click({ force: true })
                .findByDataCy('number')
                .clear()
                .type(editPackageName)
                .findByDataCy('save_num')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Package Updated Successfully').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Description')
            cy.findByText('DESCRIPTION').siblings('div')
                .click()
                .findByDataCy('edit_description')
                .click({ force: true })
                .findByDataCy('description')
                .type(SubmittalsData.EDIT_PACKAGE_DESC)
                .findByDataCy('save_description')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Package Updated Successfully').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        })

    })
    it('Should able to add and delete spec section of edit created package', () => {

        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newPackage)
            .clickElement('submittal_id_0')
        cy.wait('@getPackageDetails').then((xhr) => {
            let specificationCount = xhr.response.body.specifications.length
            cy.log('number of specificationCount ->', specificationCount)
            if (specificationCount > 0) {
                cy.get('app-spec-section .badge-secondary').should('contain.text', specificationCount)
            }
            specificationCount = specificationCount + 1
            cy.log('Add specification')
                .log('Cancel add specification section popup')
                .clickElement('add_spec_section')
                .wait('@getSpecifications').its('status').should('eq', 200)
                .get('.modal-title').should('contain.text', 'Specification Section')
                .clickElement('close-spec')

                .log('Add specification')
                .clickElement('add_spec_section')
                .wait('@getSpecifications').its('status').should('eq', 200)
                .get('.modal-title').should('contain.text', 'Specification Section')
                .get('.ui-tree-toggler').click()
                .get('.ui-tree-container').contains('review - material').click()
                .clickElement('add-spec')
                .get('.ui-toast-detail').should('contain.text', 'Spec Added.')
                .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-spec-section .badge-secondary').should('contain.text', specificationCount)

            cy.log('Deleting specifications')
                .log('clicking cancel button of delete spec pop up')
                .clickElement('delete_spec_section_0')
                .get('#confirmPopup').should('exist')
                .get('#confirmPopup .modal-title').should('contain.text', 'Delete Spec')
                .get('.msg-break').should('contain.text', SubmittalsData.DEL_SPEC_TXT)
                .get('#confirmPopup .btn-outline-secondary').should('exist').click()

            cy.log('clicking OK button of delete spec pop up')
                .clickElement('delete_spec_section_0')
                .get('#confirmPopup').should('exist')
                .findByRole('button', { name: 'OK' }).should('exist').click()

        })


    })
    it('should able to add and delete upload file of edit created package', () => {
        cy.server().route('GET', '**/cna/V1/project/**/album/**/photos').as('getPhotos')
        cy.server().route('POST', '**/cna/attachments/package/**').as('uploadFile')
        cy.server().route('DELETE', '**/cna/attachments/**').as('deleteFile')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newPackage)
            .clickElement('submittal_id_0')
        cy.wait('@getPackageDetails').then((xhr) => {
            let fileCount = xhr.response.body.attachments.length
            cy.log('number of fileCount ->', fileCount)
            if (fileCount > 0) {
                cy.get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            }

            fileCount = fileCount + 1
            cy.log('Upload file from documents')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains('Documents').click()
                .get('.ui-tree-toggler').click()
                .get('.treeFolder .ui-tree-toggler').click()
                .get('.ui-tree-container').contains('Cypress.pdf').click()
                .clickElement('upload')
                .wait('@uploadFile').its('status').should('eq', 201)
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            fileCount = fileCount + 1
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .log('Upload file from photos')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains(' Photos ').click()
                .wait('@getPhotos').its('status').should('eq', 200)
                .clickElement('select_photos_0')
                .clickElement('upload')
                .wait('@uploadFile').its('status').should('eq', 201)
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

            fileCount = fileCount + 1
            const yourFixturePath = 'Cypress.pdf' // the file to be uploaded, from the cypress/fixtures/ directory
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                .log('Upload pdf file from local')
                .clickElement('add_uploaded_files_section')
                .get('#attachmentsPopup').should('exist')
                .get('.mat-tab-labels').contains(' Local ').click()
                .clickElement('browse_files')
            cy.get('[type="file"]').attachFile(yourFixturePath, { force: true })
                .clickElement('upload')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('be.visible')

        })
        cy.log('deleting uploaded file')
            .log('clicking cancel button of delete file pop up')
            .clickElement('delete_uploaded_files_section_0')
            .get('#confirmPopup').should('exist')
            .get('#confirmPopup .modal-title').should('contain.text', 'Delete File')
            .get('.msg-break').should('contain.text', SubmittalsData.DEL_UPLOAD_FILE_TXT)
            .get('#confirmPopup .btn-outline-secondary').should('exist').click()

        cy.log('clicking OK button of delete file pop up')
            .clickElement('delete_uploaded_files_section_0')
            .get('#confirmPopup').should('exist')
            .findByRole('button', { name: 'OK' }).should('exist').click()
            .wait('@deleteFile').its('status').should('eq', 200)



    })
    it('Should able to add submittals to package while editing', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newPackage)
            .clickElement('submittal_id_0')
            .wait('@getPackageDetails').then((xhr) => {
                let submittalsCount = xhr.response.body.submittals.length
                if (submittalsCount > 0) {
                    cy.get('app-spec-section .badge-secondary').should('contain.text', submittalsCount)
                }
                submittalsCount = submittalsCount + 1
                cy.clickElement('add')
                    .get('.modal-content').should('exist')
                    .get('.modal-footer div').should('contain.text', SubmittalsData.ADD_SUBMITTALS_TEXT)
                cy.getRandomString().then((randomSubmittals) => {
                    cy.enterText('search_val', randomSubmittals)
                        .get('.centerDiv').should('exist').and('contain.text', SubmittalsData.NO_SUBMITTALS_TEXT)
                })
                cy.clickElement('Cancel')
                    .clickElement('add')
                    .findByDataCy('checkbox_0')
                    .click({ force: true })
                    //.clickElement('checkbox_0')
                    .get('.modal-content').should('exist')
                    .clickElement('Add_Submittals')
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Package Submittals Linked Successfully').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')



            })

    })
    it('Should able to delete new package', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newPackage)
            .get('table tbody tr a')
            .then((role) => {
                role[0].click()
            })
            .wait('@getPackageDetails').its('status').should('eq', 200)
        deletePackage()

    })
    it('should search non exist submittals and validate message', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.log('search non existing submittals')
        cy.getRandomString().then((randomSubmittal) => {
            cy.enterText('search', randomSubmittal)
                .get('.empty-msg').should('exist').and('contain.text', 'No results found.')
        })
    })
    it('Should able to create new submittals', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomSubmittals) => {
            createSubmittals(randomSubmittals)
        })
    })
    it('Should able to search created submittals and edit', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
            .wait('@getSubmittalDetails').its('status').should('eq', 200)
        cy.getRandomString().then((editSubmittals) => {
            cy.log('Editing Submittal ID')
            cy.findByText('Submittal ID').siblings('div')
                .click()
                .findByDataCy('edit_user_defined_id')
                .click({ force: true })
                .findByDataCy('user_defined_id')
                .clear()
                .type(editSubmittals)
                .findByDataCy('save_user_defined_id')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            newSubmittals = editSubmittals

            cy.log('Editing Title')
            cy.findByText('Title').siblings('div')
                .click()
                .findByDataCy('edit_title')
                .click({ force: true })
                .findByDataCy('title')
                .clear()
                .type(editSubmittals)
                .findByDataCy('save_title')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Type')
            cy.findByText('Type').siblings('div')
                .click()
                .findByDataCy('edit_type')
                .click({ force: true })
                .findByDataCy('type')
                .click()
                .get('.ui-dropdown-filter').type(SubmittalsData.EDIT_TYPE)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_type')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Trade')
            cy.findByText('Trade').siblings('div')
                .click()
                .findByDataCy('edit_trade')
                .click({ force: true })
                .findByDataCy('trade')
                .click()
                .get('.ui-dropdown-filter').type(SubmittalsData.EDIT_TRADE)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_trade')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Submittal Manager')
            cy.findByText('Submittal Manager').siblings('div')
                .click()
                .findByDataCy('edit_submittal_manager')
                .click({ force: true })
                .findByDataCy('submittal_manager')
                .click()
                .get('.ui-dropdown-filter').type(SubmittalsData.EDIT_ASSIGN_TO)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_submittal_manager')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Responsible Contractor')
            cy.findByText('Responsible Contractor').siblings('div')
                .click()
                .findByDataCy('edit_responsible_contractor')
                .click({ force: true })
                .get('input[placeholder="Company"]').clear()
                .type('katerra inc')
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_responsible_contractor')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')


            cy.log('Editing Description')
            cy.findByText('Description').siblings('div')
                .click()
                .findByDataCy('edit_description')
                .click({ force: true })
                .findByDataCy('description')
                .type('edit description')
                .findByDataCy('save_description')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')


        })
    })
    it('Should able to add and delete distribution group while editing', () => {
        cy.server().route('PUT', '**/cmb/V1/distribution-list/**/group_users?admin_users=1').as('updatedDistributionlistUsers')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
        cy.enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let distributionListCount = xhr.response.body.data.distribution_list.users.length

            if (distributionListCount > 0) {
                cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)

            } else if (distributionListCount == 0) {
                cy.get('app-distribution-list-section .text-muted').should('contain.text', ' Click on \'+ New\' to add members. ')

            }
            cy.log('add empty distribution group')
                .clickElement('add_distribution_list')
                .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                .get('.modal-content').should('contain.text', SubmittalsData.ADD_D_LIST_TXT)
                .enterText('search', 'AutoTest_QA')
                .get('#distPopup .ui-chkbox-icon').then((checkbox) => {
                    checkbox[0].click()
                })
                .clickElement('add')
                .get('.ui-toast-summary').should('exist')
                .get('.ui-toast-detail').should('contain.text', SubmittalsData.ADD_D_LIST_INFO_TXTX)

            cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                let addedUserCount = xhr.response.body.result.distribution_list.length
                if (addedUserCount > 0) {
                    distributionListCount = distributionListCount + addedUserCount
                    cy.get('.ui-toast-detail').should('exist')
                    cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                }

            })

            cy.log('adding non empty distribution group')
                .clickElement('add_distribution_list')
                .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                .get('.modal-content').should('contain.text', SubmittalsData.ADD_D_LIST_TXT)
                .enterText('search', 'cypress')
                .get('.ui-chkbox-icon').then((role) => {
                    role[0].click()
                })
            cy.clickElement('add')
                .get('.ui-toast-summary').should('exist')
                .get('.ui-toast-detail').should('contain.text', SubmittalsData.ADD_D_LIST_INFO_TXTX)

            cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                let addedUserCount = xhr.response.body.result.distribution_list.length
                if (addedUserCount > 0) {
                    distributionListCount = distributionListCount + addedUserCount
                    cy.get('.ui-toast-detail').should('exist')
                    cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                }

            })

            cy.log('adding user')
                .clickElement('add_distribution_list')
                .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                .get('.modal-content').should('contain.text', SubmittalsData.ADD_D_LIST_TXT)
                .get('.mat-tab-header').should('contain.text', 'Users').click()
                .get('.ui-chkbox-icon').then((role) => {
                    role[0].click()
                })
            cy.clickElement('add')
                .get('.ui-toast-summary').should('exist')
                .get('.ui-toast-detail').should('contain.text', SubmittalsData.ADD_D_LIST_INFO_TXTX)
                .get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount + 1)

            cy.log('Deleting User')
                .log('clicking cancel button of delete distribution list pop up')
                .clickElement('remove_dist0')
                .get('#confirmPopup').should('exist')
                .get('#confirmPopup .modal-title').should('contain.text', 'Delete')
                .get('.msg-break').should('contain.text', SubmittalsData.DEL_USER_TXT)
                .get('#confirmPopup .btn-outline-secondary').should('exist').click()

            cy.log('clicking Yes button of delete distribution list pop up')
                .clickElement('remove_dist0')
                .get('#confirmPopup').should('exist')
                .findByRole('button', { name: 'Yes' }).should('exist').click()
        })


    })
    it('Should verify minimum one workflow task required alert while deleting workflow', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskCount = xhr.response.body.data.workflow_tasks.length
            if (workFlowTaskCount == 1) {
                cy.clickElement('delete_action_0')
                cy.get('.ui-toast-detail').should('exist')
            }
        })
    })
    it('Should able to edit workflow', () => {
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskCount = xhr.response.body.data.workflow_tasks.length
            if (workFlowTaskCount => 1) {
                cy.clickElement('edit_task_0')
                    .enterText('task_name_0', 'edit')
                    .clickElement('update_task_0')
                cy.findByRole('button', { name: 'Yes, Update' }).should('exist').click()
                cy.get('.ui-toast-detail').should('exist')
            }
        })
    })
    it('Should able to add and delete new task for workflow', () => {
        cy.server().route('POST', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW').as('postCreateTask')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskCount = xhr.response.body.data.workflow_tasks.length
            if (workFlowTaskCount => 1) {
                cy.clickElement('add_task')
                    .enterText('task_name_1', SubmittalsData.WORKFLOW_TASK_02)
                    .clickElement('task_type_1')
                    .get('.ui-dropdown-filter').type('Finance')
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.enterText('task_duration_1', SubmittalsData.TASK_DURATION)
                    .clickElement('task_assignee_1')
                    .get('.ui-dropdown-filter').type(SubmittalsData.ASSIGN_TO)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('create_task_1')
                    .get('.ui-toast-detail').should('exist')
                    .wait('@postCreateTask').its('status').should('eq', 201)
                    .clickElement('delete_action_1')

                cy.findByRole('button', { name: 'Yes, Delete' }).should('exist').click()
                    .get('.ui-toast-detail').should('exist')

            }
        })
    })
    it('Should able to add and delete new task for workflow', () => {
        cy.server().route('POST', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW').as('postCreateTask')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskCount = xhr.response.body.data.workflow_tasks.length
            if (workFlowTaskCount => 1) {
                cy.clickElement('add_task')
                    .enterText('task_name_1', SubmittalsData.WORKFLOW_TASK_02)
                    .clickElement('task_type_1')
                    .get('.ui-dropdown-filter').type('Finance')
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.enterText('task_duration_1', SubmittalsData.TASK_DURATION)
                    .clickElement('task_assignee_1')
                    .get('.ui-dropdown-filter').type(SubmittalsData.ASSIGN_TO)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('create_task_1')
                    .get('.ui-toast-detail').should('exist')
                    .wait('@postCreateTask').its('status').should('eq', 201)
                    .clickElement('delete_action_1')

                cy.findByRole('button', { name: 'Yes, Delete' }).should('exist').click()
                    .get('.ui-toast-detail').should('exist')

            }
        })
    })
    it('Should able to approve task and close workflow', () => {
        cy.server().route('POST', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW').as('postCreateTask')
        cy.server().route('PATCH', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW/**/CLOSED').as('closeWorflow')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskCount = xhr.response.body.data.workflow_tasks.length
            if (workFlowTaskCount => 1) {
                cy.clickElement('respond_task_0')
                    .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', SubmittalsData.RESPOND_TASK_TEXT)
                    .clickElement('response')
                    .get('.ui-dropdown-filter').type('Approved')
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('reason')
                    .get('.ui-dropdown-filter').type('avbs')//test
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('end_workflow')
                    .wait('@closeWorflow').its('status').should('eq', 200)
                    .get('.ui-toast-detail').should('exist')

            }
        })
    })
    it('Should able to close workflow', () => {
        cy.server().route('POST', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW').as('postCreateTask')
        cy.server().route('PATCH', '**/cna/forms/submittal/**/plugin/SUBMITTAL_WORKFLOW/**/CLOSED').as('closeWorflow')
        cy.server().route('PATCH', '**/cna/forms/submittal/**/state').as('updateSubmittalState')
        cy.wait('@getSubmittalsForms').its('status').should('eq', 200)
            .enterText('search', newSubmittals)
            .clickElement('submittal_id_0')
        cy.wait('@getSubmittalDetails').then((xhr) => {
            let workFlowTaskStatus = xhr.response.body.data.workflow_tasks[0].status
            cy.log('workFlowStatus ' + workFlowTaskStatus)
            if (workFlowTaskStatus == 'OPEN') {
                cy.findByDataCy
                cy.clickElement('respond_task_0')
                    .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', SubmittalsData.RESPOND_TASK_TEXT)
                    .clickElement('response')
                    .get('.ui-dropdown-filter').type('Approved')
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('reason')
                    .get('.ui-dropdown-filter').type('avbs')//test
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('end_workflow')
                    .wait('@closeWorflow').its('status').should('eq', 200)
                    .get('.ui-toast-detail').should('exist')

            }
            cy.clickElement('Close_Submittal')
                .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', SubmittalsData.CLOSE_SUBMITTAL_TEXT)
                .clickElement('resolution')
                .get('.ui-dropdown-filter').type('Approved')
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .clickElement('close_submittal_popup')
                .wait('@updateSubmittalState').its('status').should('eq', 200)

        })
    })
})
const createPackage = (randomPackage) => {
    cy.log('clicking on create new package')
        .clickElement('create')
        .get('a[data-cy="package"]').click()
        .get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
        .wait('@getSubmittalsTemplates').its('status').should('eq', 200)
        .enterText('title', randomPackage)
        .enterText('number', randomPackage)
        .enterText('description', 'cypress testing')
        .clickElement('Create_Package')
        .wait('@postCreatePackage').its('status').should('eq', 201)
        .get('.ui-toast-summary').should('exist')
    cy.contains('Package Created Successfully').should('exist')
    newPackage = randomPackage
}
const deletePackage = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('deleting creating package')
        .clickElement('delete_pkg')
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Package')
        .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete this package. Do you wish to proceed?')
    cy.findByRole('button', { name: 'Yes, Delete' }).should('exist').click()
        .get('.ui-toast-summary').should('exist')
        .wait('@deletePackage').its('status').should('eq', 200)
    cy.contains('Package deleted Successfully').should('exist')


}
const createSubmittals = (randomSubmittals) => {
    cy.log('clicking on create submittals pages')
        .clickElement('create')
        .clickElement('create_submittal')
        .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
        .wait('@getSubmittalsTemplates').its('status').should('eq', 200)
        .wait('@getSubmittalsTrades').its('status').should('eq', 200)
        .enterText('user_defined_id', randomSubmittals)
        .enterText('title', randomSubmittals)
    cy.clickElement('type')
        .get('.ui-dropdown-filter').type(SubmittalsData.SUBMITTAL_TYPE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('trade')
        .get('.ui-dropdown-filter').type(SubmittalsData.TRADE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.clickElement('issue_date')
        .get('.ui-state-highlight').click()
    cy.clickElement('submittal_manager')
        .get('.ui-dropdown-filter').type(SubmittalsData.ASSIGN_TO)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.findByDataCy('responsible_contractor').type('katerra inc')
        .get('[role="option"] span')
        .then((role) => {
            role[0].click()
        })
    cy.clickElement('cost_impact')
        .get('.ui-dropdown-filter').type(SubmittalsData.COST_IMPACT)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.enterText('description', SubmittalsData.SUBMITTTAL_DESC)

        .clickElement('spec')
        .log('Add specification')
        .clickElement('add-spec')
        .wait('@getSpecifications').its('status').should('eq', 200)
        .get('.modal-title').should('contain.text', 'Specification Section')
        .get('.ui-tree-toggler').click()
        .get('.ui-tree-container').contains('review - material').click()
        .get('app-spec-section-popup [data-cy="add-spec"]').click()

        .clickElement('template-dd')
        .get('.ui-dropdown-filter').type('cypress')
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.enterText('task_name_0', SubmittalsData.WORKFLOW_TASK_01)
        .clickElement('task_assignee_0')
        .get('.ui-dropdown-filter').type(SubmittalsData.ASSIGN_TO)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })

    cy.clickElement('create_submittal')
        .wait('@postCreateSubmittal').its('status').should('eq', 201)


    newSubmittals = randomSubmittals
}