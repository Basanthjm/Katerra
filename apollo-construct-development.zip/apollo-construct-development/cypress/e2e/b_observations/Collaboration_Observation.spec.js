import '../../support/setup-tests'
const observationData = require('../../support/constants')
let newObservation = observationData.OBSERVATION_NAME
describe('Collaboration Observation', () => {
    beforeEach(() => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/projects?search=**').as('getSearchProject')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '**/cna/forms/observation?project_id=**').as('getObservationForms')
        cy.server().route('GET', '**/tenant/locations?projectId=**').as('getProjectLocations')
        cy.server().route('POST', '**/cna/forms/observation').as('createObservation')
        cy.server().route('PATCH', '**/cna/forms/observation/**/state').as('updateObservationState')
        cy.server().route('DELETE', '**/cna/forms/observation/**').as('deleteObservation')
        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)

        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(observationData.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()

        cy.wait('@getTenantMembers').its('status').should('eq', 200)
        cy.clickElement('Collaboration')
        cy.get('.ap-icon-observations').click()

    })
    it('Should validate observation landing page buttons', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('verifying all buttons in observation landing page')
        cy.findByDataCy('all_observations')
            .should('be.visible')
            .and('have.attr', 'href')
        cy.findByDataCy('my_observations')
            .should('be.visible')
            .and('have.attr', 'href')
        cy.findByDataCy('create_observation').parent('a')
            .should('be.visible')
            .and('have.attr', 'href')
        cy.log('verify export button exist')
        cy.findByDataCy('export').should('exist')
        cy.findByDataCy('observation_filter_button').should('exist')
    })
    it('Should verify fill mandatory field alert message while creating empty observation', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('clicking on create observation page')
        cy.findByDataCy('create_observation')
            .click()
            .get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
            .findByDataCy('Create_observation')
            .click()
            .get('.ui-toast-summary')
            .should('exist')
        cy.contains('Please fill all mandatory fields.')
            .should('exist')
    })
    it('Should able to save draft and delete draft of observation', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('clicking on create observation page')
        cy.findByDataCy('create_observation')
            .click()
        cy.findByDataCy('save_draft_observation')
            .click()
        cy.get('.ui-toast-summary')
            .should('exist')
        cy.contains('Draft created.')
            .should('exist')
        cy.findByDataCy('discard_draft')
            .click()
        cy.get('.ui-toast-summary')
            .should('exist')
        cy.contains('Draft discarded.')
            .should('exist')
    })
    it('Should able to create new observation,reopen,close and delete', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomObservation) => {
            createObservation(randomObservation)
            closeObservation()
            reOpenObservation()
            closeObservation()
            deleteObservation()
        })
    })
    it('should search non exist observation and validate message', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('search non existing observation')
        cy.getRandomString().then((randomObservation) => {
            cy.get('.searchInput-height-34').clear().type(randomObservation)
                .get('.empty-msg').should('exist').and('contain.text', 'No results found.')
        })
    })
    it('should validate count of observation', () => {
        cy.wait('@getObservationForms').then((xhr) => {
            const observationCount = xhr.response.body.data.count
            cy.log('number of Observations ->', observationCount)
            if (observationCount > 50) {
                cy.findByText(`1-50 of ${observationCount}`).should('exist')
                cy.findByDataCy('next').should('exist')
                cy.findByDataCy('lastpage').should('exist')

            } else {
                cy.findByText(`1-${observationCount} of ${observationCount}`)
                    .should('exist')

            }

        })

    })
    it('Should validate no result found message while search non existing data', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomObservation) => {
            cy.findByDataCy('create_observation').click()
                .get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
                .findByDataCy('assignee').click()
                .get('div.ui-multiselect-filter-container input')
                .clear()
                .type(randomObservation)
                .get('.ui-multiselect-empty-message').should('exist').and('contain.text', 'No results found')

                .findByDataCy('observation_type').click()
                .get('.ui-dropdown-filter').type(randomObservation)
                .get('.ui-dropdown-empty-message').should('exist').and('contain.text', 'No results found')

                .findByDataCy('trade').click()
                .get('.ui-dropdown-filter').type(randomObservation)
                .get('.ui-dropdown-empty-message').should('exist').and('contain.text', 'No results found')

                .findByDataCy('priority').click()
                .get('.ui-dropdown-filter').type(randomObservation)
                .get('.ui-dropdown-empty-message').should('exist').and('contain.text', 'No results found')

                .findByDataCy('observation_manager').click()
                .get('.ui-dropdown-filter').type(randomObservation)
                .get('.ui-dropdown-empty-message').should('exist').and('contain.text', 'No results found')

                .findByDataCy('responsible_contractor').type(randomObservation)
                .get('.ui-autocomplete-emptymessage', { timeout: 30000 }).should('be.visible').and('contain.text', 'No Results Found')

                .findByDataCy('reason').click()
                .get('.ui-dropdown-filter').type(randomObservation)
                .get('.ui-dropdown-empty-message').should('exist').and('contain.text', 'No results found')



        })
    })
    it('Should able to edit created Observation', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.getRandomString().then((randomObservation) => {
            createObservation(randomObservation)
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            cy.getRandomString().then((randomObservation) => {
                cy.log('Editing User defined ID')
                cy.findByText('User Defined ID').siblings('div')
                    .click()
                    .findByDataCy('edit_user_defined_id')
                    .click({ force: true })
                    .findByDataCy('user_defined_id')
                    .clear()
                    .type(randomObservation)
                    .findByDataCy('save_user_defined_id')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Assign To')
                cy.findByText('Assign To').siblings('div')
                    .click()
                    .findByDataCy('edit_assignee')
                    .click({ force: true })
                    .findByDataCy('assignee')
                    .click()
                    .get('div.ui-multiselect-filter-container input')
                    .clear()
                    .type(observationData.EDIT_ASSIGN_TO)
                    .get('li.ui-multiselect-item[style="display: block;"]')
                    .then((users) => {
                        users[0].click()
                    })
                    .findByDataCy('save_assignee')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Title')
                cy.findByText('Title').siblings('div')
                    .click()
                    .findByDataCy('edit_title')
                    .click({ force: true })
                    .findByDataCy('title')
                    .clear()
                    .type(randomObservation)
                    .findByDataCy('save_title')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Observation type')
                cy.findByText('Observation Type').siblings('div')
                    .click()
                    .findByDataCy('edit_observation_type')
                    .click({ force: true })
                    .findByDataCy('observation_type')
                    .click()
                    .get('.ui-dropdown-filter').type(observationData.EDIT_OBSERVATION_TYPE)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                    .findByDataCy('save_observation_type')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Trade')
                cy.findByText('Trade').siblings('div')
                    .click()
                    .findByDataCy('edit_trade')
                    .click({ force: true })
                    .findByDataCy('trade')
                    .click()
                    .get('.ui-dropdown-filter').type(observationData.EDIT_TRADE)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                    .findByDataCy('save_trade')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Observation manager')
                cy.findByText('Observation Manager').siblings('div')
                    .click()
                    .findByDataCy('edit_observation_manager')
                    .click({ force: true })
                    .findByDataCy('observation_manager')
                    .click()
                    .get('.ui-dropdown-filter').clear().type(observationData.EDIT_ASSIGN_TO)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                    .findByDataCy('save_observation_manager')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Responsible Contractor')
                cy.findByText('Responsible Contractor').siblings('div')
                    .click()
                    .findByDataCy('edit_responsible_contractor')
                    .click({ force: true })
                    .get('input[placeholder="Company"]').clear()
                    .type('katerra')
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                    .findByDataCy('save_responsible_contractor')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

                cy.log('Editing Reason')
                cy.findByText('Reason').siblings('div')
                    .click()
                    .findByDataCy('edit_reason')
                    .click({ force: true })
                    .findByDataCy('reason').click()
                    .get('.ui-dropdown-filter').type(observationData.EDIT_REASON)
                    .get('[role="option"] span').then((role) => {
                        role[0].click()
                    })
                    .findByDataCy('save_reason')
                    .click()
                    .get('.ui-toast-summary').should('exist')
                cy.contains('Observation updated.').should('exist')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')


            })
            closeObservation()
            deleteObservation()
        })
    })
    it('Should able to upload file while editing', () => {
        cy.server().route('GET', '**/cna/attachments/observation/**').as('getAttachedFiles')
        cy.server().route('POST', '**/cna/attachments/observation/**').as('uploadFile')
        cy.getRandomString().then((randomObservation) => {
            createObservation(randomObservation)
            cy.wait('@getObservationForms').its('status').should('eq', 200)
            cy.wait('@getAttachedFiles').then((xhr) => {
                let fileCount = xhr.response.body.data.length
                cy.log('number of fileCount ->', fileCount)
                if (fileCount > 0) {
                    cy.get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

                }

                fileCount = fileCount + 1
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .log('Upload file from documents')
                    .clickElement('add_uploaded_files_section')
                    .get('#attachmentsPopup').should('exist')
                    .get('.mat-tab-labels').contains('Documents').click()
                    .get('.ui-tree-toggler').click()
                    .get('.treeFolder .ui-tree-toggler').click()
                    .get('.ui-tree-container').contains('Cypress.pdf').click()
                    .clickElement('upload')
                    .wait('@uploadFile').its('status').should('eq', 201)
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

                fileCount = fileCount + 1
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .log('Upload file from photos')
                    .clickElement('add_uploaded_files_section')
                    .get('#attachmentsPopup').should('exist')
                    .get('.mat-tab-labels').contains(' Photos ').click()
                    .clickElement('select_photos_0')
                    .clickElement('upload')
                    .wait('@uploadFile').its('status').should('eq', 201)
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

                fileCount = fileCount + 1
                const yourFixturePath = 'Cypress.pdf' // the file to be uploaded, from the cypress/fixtures/ directory
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    .log('Upload pdf file from local')
                    .clickElement('add_uploaded_files_section')
                    .get('#attachmentsPopup').should('exist')
                    .get('.mat-tab-labels').contains(' Local ').click()
                    .clickElement('browse_files')
                cy.get('[type="file"]').attachFile(yourFixturePath, { force: true })
                    .clickElement('upload')
                cy.get('.ui-toast-summary', { timeout: 60000 }).should('be.visible')

                closeObservation()
                deleteObservation()
            })
        })
    })
    it('Should able to delete uploaded file, add and delete spec section while editing', () => {
        cy.server().route('GET', '**/cna/attachments/observation/**').as('getAttachedFiles')
        cy.server().route('POST', '**/cna/attachments/observation/**').as('uploadFile')
        cy.server().route('DELETE', '**/cna/attachments/**').as('deleteFile')
        cy.server().route('GET', '**/cna/forms/observation/**?project_id=**').as('getObservationDetails')
        cy.server().route('GET', '**/cna/V2/project/**/specifications/**').as('getSpecifications')
        cy.getRandomString().then((randomObservation) => {
            createObservation(randomObservation)
            cy.wait('@getObservationForms').its('status').should('eq', 200)
            cy.wait('@getAttachedFiles').then((xhr) => {
                let fileCount = xhr.response.body.data.length
                cy.log('number of fileCount ->', fileCount)
                cy.wait('@getObservationDetails').then((xhr) => {
                    let specificationCount = xhr.response.body.data.form_plugins.spec_section.value.length
                    cy.log('number of specificationCount ->', specificationCount)

                    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                    if (fileCount == 0) {
                        fileCount = fileCount + 1
                        cy.log('Upload file from documents')
                            .clickElement('add_uploaded_files_section')
                            .get('#attachmentsPopup').should('exist')
                            .get('.mat-tab-labels').contains('Documents').click()
                            .get('.ui-tree-toggler').click()
                            .get('.treeFolder .ui-tree-toggler').click()
                            .get('.ui-tree-container').contains('Cypress.pdf').click()
                            .clickElement('upload')
                            .wait('@uploadFile').its('status').should('eq', 201)
                            .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                            .get('app-uploaded-files-section .badge-secondary').should('contain.text', fileCount)

                    }
                    cy.log('clicking cancel button of delete file pop up')
                        .clickElement('delete_uploaded_files_section_0')
                        .get('#confirmPopup').should('exist')
                        .get('#confirmPopup .modal-title').should('contain.text', 'Delete File')
                        .get('.msg-break').should('contain.text', observationData.DEL_UPLOAD_FILE_TXT)
                        .get('#confirmPopup .btn-outline-secondary').should('exist').click()

                    cy.log('clicking OK button of delete file pop up')
                        .clickElement('delete_uploaded_files_section_0')
                        .get('#confirmPopup').should('exist')
                        .findByRole('button', { name: 'OK' }).should('exist').click()
                        .wait('@deleteFile').its('status').should('eq', 200)

                    if (specificationCount > 0) {
                        cy.get('app-spec-section .badge-secondary').should('contain.text', specificationCount)
                    }
                    specificationCount = specificationCount + 1
                    cy.log('Add specification')
                        .log('Cancel add specification section popup')
                        .clickElement('add_spec_section')
                        .wait('@getSpecifications').its('status').should('eq', 200)
                        .get('.modal-title').should('contain.text', 'Specification Section')
                        .clickElement('close-spec')

                        .log('Add specification')
                        .clickElement('add_spec_section')
                        .wait('@getSpecifications').its('status').should('eq', 200)
                        .get('.modal-title').should('contain.text', 'Specification Section')
                        .get('.ui-tree-toggler').click()
                        .get('.ui-tree-container').contains('review - material').click()
                        .clickElement('add-spec')
                        .get('.ui-toast-detail').should('contain.text', 'Observation updated.')
                        .get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
                        .get('app-spec-section .badge-secondary').should('contain.text', specificationCount)

                    cy.log('Deleting specifications')
                        .log('clicking cancel button of delete spec pop up')
                        .clickElement('delete_spec_section_0')
                        .get('#confirmPopup').should('exist')
                        .get('#confirmPopup .modal-title').should('contain.text', 'Delete Spec')
                        .get('.msg-break').should('contain.text', observationData.DEL_SPEC_TXT)
                        .get('#confirmPopup .btn-outline-secondary').should('exist').click()

                    cy.log('clicking OK button of delete spec pop up')
                        .clickElement('delete_spec_section_0')
                        .get('#confirmPopup').should('exist')
                        .findByRole('button', { name: 'OK' }).should('exist').click()

                    closeObservation()
                    deleteObservation()
                })
            })
        })
    })
    it('Should verify count of associated drawing,add and delete distribution group while editing', () => {
        cy.server().route('GET', '**/cna/forms/observation/**?project_id=**').as('getObservationDetails')
        cy.server().route('GET', '**/cmb/V1/distribution-list').as('getDistributionlist')
        cy.server().route('PUT', '**/cmb/V1/distribution-list/**/group_users?admin_users=1').as('updatedDistributionlistUsers')
        cy.getRandomString().then((randomObservation) => {
            createObservation(randomObservation)
            cy.wait('@getObservationForms').its('status').should('eq', 200)

            cy.wait('@getObservationDetails').then((xhr) => {
                let associatedDrawingsCount = xhr.response.body.data.associated_drawings.length
                let distributionListCount = xhr.response.body.data.distribution_list.users.length
                cy.log('number of associatedDrawingsCount ->', associatedDrawingsCount)
                if (associatedDrawingsCount > 0) {
                    cy.get('app-associated-drawings-section .badge-secondary').should('contain.text', associatedDrawingsCount)

                } else if (associatedDrawingsCount == 0) {
                    cy.get('app-associated-drawings-section .text-muted').should('contain.text', ' No Associated drawings found. ')

                }
                if (distributionListCount > 0) {
                    cy.get('app-associated-drawings-section .badge-secondary').should('contain.text', distributionListCount)

                } else if (distributionListCount == 0) {
                    cy.get('app-distribution-list-section .text-muted').should('contain.text', ' Click on \'+ New\' to add members. ')

                }
                cy.log('add empty distribution group')
                    .clickElement('add_distribution_list')
                    .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                    .get('.modal-content').should('contain.text', observationData.ADD_D_LIST_TXT)
                cy.wait('@getDistributionlist').its('status').should('eq', 200)
                    .enterText('search', 'AutoTest_QA')
                    .wait(1000)
                    .get('#distPopup .ui-chkbox-icon').then((checkbox) => {
                        checkbox[0].click()
                    })
                    .clickElement('add')
                    .get('.ui-toast-summary').should('exist')
                    .get('.ui-toast-detail').should('contain.text', observationData.ADD_D_LIST_INFO_TXTX)
                cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                    let addedUserCount = xhr.response.body.result.distribution_list.length
                    if (addedUserCount > 0) {
                        distributionListCount = distributionListCount + addedUserCount
                        cy.get('.ui-toast-detail').should('contain.text', 'Observation updated.')
                        cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                    }

                })

                cy.log('adding non empty distribution group')
                    .clickElement('add_distribution_list')
                    .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                    .get('.modal-content').should('contain.text', observationData.ADD_D_LIST_TXT)
                    .enterText('search', 'cypress')
                    .wait(1000)
                    .get('#distPopup .ui-chkbox-icon').then((role) => {
                        role[0].click()
                    })
                cy.clickElement('add')
                    .get('.ui-toast-summary').should('exist')
                    .get('.ui-toast-detail').should('contain.text', observationData.ADD_D_LIST_INFO_TXTX)

                cy.wait('@updatedDistributionlistUsers').then((xhr) => {
                    let addedUserCount = xhr.response.body.result.distribution_list.length
                    if (addedUserCount > 0) {
                        distributionListCount = distributionListCount + addedUserCount
                        cy.get('.ui-toast-detail').should('contain.text', 'Observation updated.')
                        cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount)
                    }



                    cy.log('adding user')
                        .clickElement('add_distribution_list')
                        .get('#distPopup .modal-title').should('contain.text', 'Distribution List')
                        .get('.modal-content').should('contain.text', observationData.ADD_D_LIST_TXT)
                        .get('.mat-tab-header').should('contain.text', 'Users').click()
                        .get('.ui-chkbox-icon').then((role) => {
                            role[0].click()
                        })
                    cy.clickElement('add')
                        .get('.ui-toast-summary').should('exist')
                        .get('.ui-toast-detail').should('contain.text', observationData.ADD_D_LIST_INFO_TXTX)
                        .get('.ui-toast-detail').should('contain.text', 'Observation updated.')
                    cy.get('app-distribution-list-section .badge-secondary').should('contain.text', distributionListCount + 1)
                })

                cy.log('Deleting User')
                    .log('clicking cancel button of delete distribution list pop up')
                    .clickElement('remove_dist0')
                    .get('#confirmPopup').should('exist')
                    .get('#confirmPopup .modal-title').should('contain.text', 'Delete')
                    .get('.msg-break').should('contain.text', observationData.DEL_USER_TXT)
                    .get('#confirmPopup .btn-outline-secondary').should('exist').click()

                cy.log('clicking Yes button of delete distribution list pop up')
                    .clickElement('remove_dist0')
                    .get('#confirmPopup').should('exist')
                    .findByRole('button', { name: 'Yes' }).should('exist').click()



                closeObservation()
                deleteObservation()
            })

        })
    })
    it('Should able to save draft and create observation', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('clicking on create observation page')
        cy.findByDataCy('create_observation').click()
            .findByDataCy('save_draft_observation').click()
            .get('.ui-toast-summary').should('exist')
        cy.contains('Draft created.').should('exist')
        cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        cy.getRandomString().then((randomObservation) => {
            cy.log('Editing User defined ID')
            cy.findByText('User Defined ID').siblings('div')
                .click()
                .findByDataCy('edit_user_defined_id')
                .click({ force: true })
                .findByDataCy('user_defined_id')
                .clear()
                .type(randomObservation)
                .findByDataCy('save_user_defined_id')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Assign To')
            cy.findByText('Assign To').siblings('div')
                .click()
                .findByDataCy('edit_assignee')
                .click({ force: true })
                .findByDataCy('assignee')
                .click()
                .get('div.ui-multiselect-filter-container input')
                .clear()
                .type(observationData.EDIT_ASSIGN_TO)
                .get('li.ui-multiselect-item[style="display: block;"]')
                .then((users) => {
                    users[0].click()
                })
                .findByDataCy('save_assignee')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Title')
            cy.findByText('Title').siblings('div')
                .click()
                .findByDataCy('edit_title')
                .click({ force: true })
                .findByDataCy('title')
                .clear()
                .type(randomObservation)
                .findByDataCy('save_title')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing due date')
            cy.findByText('Title').siblings('div')
                .click()
                .findByDataCy('edit_due_date')
                .click({ force: true })
                .findByDataCy('due_date').click()
                .get('.ui-state-highlight').click()
                .findByDataCy('save_due_date').click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Observation type')
            cy.findByText('Observation Type').siblings('div')
                .click()
                .findByDataCy('edit_observation_type')
                .click({ force: true })
                .findByDataCy('observation_type')
                .click()
                .get('.ui-dropdown-filter').type(observationData.EDIT_OBSERVATION_TYPE)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_observation_type')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Trade')
            cy.findByText('Trade').siblings('div')
                .click()
                .findByDataCy('edit_trade')
                .click({ force: true })
                .findByDataCy('trade')
                .click()
                .get('.ui-dropdown-filter').type(observationData.EDIT_TRADE)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_trade')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Observation manager')
            cy.findByText('Observation Manager').siblings('div')
                .click()
                .findByDataCy('edit_observation_manager')
                .click({ force: true })
                .findByDataCy('observation_manager')
                .click()
                .get('.ui-dropdown-filter').clear().type(observationData.EDIT_ASSIGN_TO)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_observation_manager')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Responsible Contractor')
            cy.findByText('Responsible Contractor').siblings('div')
                .click()
                .findByDataCy('edit_responsible_contractor')
                .click({ force: true })
                .get('input[placeholder="Company"]').clear()
                .type('katerra')
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_responsible_contractor')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')

            cy.log('Editing Reason')
            cy.findByText('Reason').siblings('div')
                .click()
                .findByDataCy('edit_reason')
                .click({ force: true })
                .findByDataCy('reason').click()
                .get('.ui-dropdown-filter').type(observationData.EDIT_REASON)
                .get('[role="option"] span').then((role) => {
                    role[0].click()
                })
                .findByDataCy('save_reason')
                .click()
                .get('.ui-toast-summary').should('exist')
            cy.contains('Observation updated.').should('exist')
            cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
            cy.findByDataCy('create_observation').click()


        })
        closeObservation()
        deleteObservation()

    })
    it('Should verify filters fields of observation', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('verifying all buttons in observation landing page')
            .findByDataCy('observation_filter_button').should('exist').click()
            .get('.sidebar-header > .d-inline-block').should('contain.text', 'Filters')
            .findByDataCy('clear-all').should('exist')
            .findByDataCy('created_by').should('exist')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('observation_manager').should('exist')
            .findByDataCy('state').should('exist')
            .findByDataCy('observation_type').should('exist')
            .findByDataCy('priority').should('exist')
            .findByDataCy('responsible_contractor').should('exist')
            .findByDataCy('reason').should('exist')
            .findByDataCy('trade').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('title').should('exist')
            .findByDataCy('description').should('exist')
            .findByDataCy('reset').should('exist')
            .findByDataCy('apply_filters').should('exist')
    })
    it('Should verify clear all and reset functionality of observation filters', () => {
        cy.wait('@getObservationForms').its('status').should('eq', 200)
        cy.log('verifying all buttons in observation landing page')
            .findByDataCy('observation_filter_button').should('exist').click()
        fillALLFilters()
        cy.clickElement('clear-all')
        fillALLFilters()
        cy.clickElement('reset')


    })

})
const createObservation = (observationName) => {
    cy.log('clicking on create observation page')
    cy.findByDataCy('create_observation').click()
        .get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
        .findByDataCy('user_defined_id').type(observationName)
        .findByDataCy('assignee').click()
        .get('div.ui-multiselect-filter-container input')
        .clear()
        .type(observationData.ASSIGN_TO)
        .get('li.ui-multiselect-item[style="display: block;"]')
        .then((users) => {
            users[0].click()
        })
    cy.findByDataCy('assignee').click()
        .findByDataCy('title').type(observationName)
        .findByDataCy('due_date').click()
        .get('.ui-state-highlight').click()

        .findByDataCy('observation_type').click()
        .get('.ui-dropdown-filter').type(observationData.OBSERVATION_TYPE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })

    cy.findByDataCy('trade').click()
        .get('.ui-dropdown-filter').type(observationData.TRADE)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })

    cy.findByDataCy('priority').click()
        .get('.ui-dropdown-filter').type(observationData.PRIORITY)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })

    cy.findByDataCy('observation_manager').click()
        .get('.ui-dropdown-filter').type(observationData.ASSIGN_TO)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })
    cy.findByDataCy('responsible_contractor').type('katerra')
        .get('[role="option"] span')
        .then((role) => {
            role[0].click()
        })

    cy.findByDataCy('reason').click()
        .get('.ui-dropdown-filter').type(observationData.REASON)
        .get('[role="option"] span').then((role) => {
            role[0].click()
        })

    cy.get('div.input-icons i.fa-plus').click()
    cy.wait('@getProjectLocations').then((xhr) => {
        const locationsCount = xhr.response.body.locations.length
        cy.get('#locationPopup').should('exist')
        if (locationsCount == 0) {
            cy.log('verifying location ')
            cy.get('.modal-body div').should('contain.text', 'No location data available.')
            cy.findByRole('button', { name: 'Confirm' }).should('be.disabled')

        }
        cy.findByRole('button', { name: 'Cancel' }).should('exist').click()
    })

    cy.findByDataCy('Create_observation').click()
    cy.wait('@createObservation').its('status').should('eq', 201)
    cy.get('.ui-toast-summary').should('exist')
    cy.contains('Observation Created.').should('exist')
    newObservation = observationName
}
const closeObservation = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
    cy.log('closing creating observation')
    cy.findByDataCy('close_observation').click()
    cy.get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Close Observation')
    cy.get('.modal-body label').should('exist').and('contain.text', 'Are you sure you want to close this Observation?')
    cy.get('.comment-modal-footer .btn-outline-secondary').should('exist')

    cy.findByRole('button', { name: 'Confirm' }).should('exist').click()
    cy.wait('@updateObservationState').its('status').should('eq', 200)
    cy.get('.ui-toast-summary').should('exist')
    cy.contains('Observation closed.').should('exist')

}
const reOpenObservation = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('reopening closed observation')
        .findByDataCy('reopen_observation').should('exist').click()
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Reopen Observation')
        .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to Reopen Observation?')
    cy.findByRole('button', { name: 'Cancel' }).should('exist').click()

        .findByDataCy('reopen_observation').should('exist').click()
        .get('.modal-content').should('exist')
    cy.findByRole('button', { name: 'OK' }).should('exist').click()
        .get('.ui-toast-summary').should('exist')
    cy.contains('Observation Reopened.').should('exist')
        .wait('@updateObservationState').its('status').should('eq', 200)
}
const deleteObservation = () => {
    cy.get('.ui-toast-summary', { timeout: 60000 }).should('not.be.visible')
        .log('deleting closed observation')
        .findByDataCy('delete_observation').should('exist').click()
        .get('.modal-title', { timeout: 60000 }).should('be.visible').and('contain.text', 'Delete Observation')
        .get('.msg-break').should('exist').and('contain.text', 'Are you sure you want to delete this Observation? If you choose to proceed, the link with Drawings (if any) will also be deleted.')
    cy.findByRole('button', { name: 'Cancel' }).should('exist').click()

        .findByDataCy('delete_observation').should('exist').click()


        .get('.modal-content').should('exist')
    cy.findByRole('button', { name: 'OK' }).should('exist').click()
        .wait('@deleteObservation').its('status').should('eq', 200)
        .get('.ui-toast-summary').should('exist')
    cy.contains('Observation Deleted.').should('exist')


}
const fillALLFilters = () => {
    cy.clickElement('created_by')
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.clickElement('created_by')

    cy.get('p-multiselect[data-cy="assignee"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="assignee"]').click()

    cy.get('p-multiselect[data-cy="observation_manager"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="observation_manager"]').click()

    cy.get('p-multiselect[data-cy="state"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="state"]').click()

    cy.get('p-multiselect[data-cy="observation_type"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="observation_type"]').click()

    cy.get('p-multiselect[data-cy="priority"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="priority"]').click()

    cy.get('p-multiselect[data-cy="responsible_contractor"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="responsible_contractor"]').click()

    cy.get('p-multiselect[data-cy="reason"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="reason"]').click()

    cy.get('p-multiselect[data-cy="trade"]').click()
        .get('li.ui-multiselect-item')
        .then((users) => {
            users[0].click()
        })
    cy.get('p-multiselect[data-cy="trade"]').click()

    cy.get('p-calendar[data-cy="due_date"]').click()
        .get('.ui-state-highlight').click()
        .get('.ui-state-highlight').click()
    cy.contains('Due Date').click()

    cy.get('input[data-cy="title"]').type(newObservation)
    cy.enterText('description', observationData.DESCRIPTION)


}