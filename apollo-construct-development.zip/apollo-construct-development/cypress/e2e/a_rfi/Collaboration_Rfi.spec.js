import '../../support/setup-tests'
import { getUser } from '../../support/users'

const rfiConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Collaboration RFI', () => {

    let newUserDefinedID = ''

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/tenant/members?sortKey=name&sort=1&pageSize=500&type=project&typeId=**&includeUsers=true').as('getTenantMembers')
        cy.server().route('GET', '/construct/config-prod.json').as('getConstructConfig')
        cy.server().route('GET', '/cmb/V1/user/**').as('getUserDetails')
        cy.server().route('GET', '/cmb/projects/team-members/**').as('getProjectMembers')
        cy.server().route('GET', '/file_management/weather/forecast?**').as('getWeatherForecast')
        cy.server().route('GET', '/cmb/list_view/rfi').as('getRfiList')
        cy.server().route('GET', '/cna/V2/project/**/history/RFI/**').as('getRfiProjectHistory')
        cy.server().route('GET', '/cmb/config_dropdown/**').as('getRfiConfig')
        cy.server().route('GET', '/cna/forms/project/**/filter_dropdown/rfi').as('getProjectForms')
        cy.server().route('POST', '/cna/forms/rfi').as('createRfi')
        cy.server().route('POST', '/cna/forms/rfi/_draft').as('createRfiDraft')
        cy.server().route('GET', '/cna/forms/rfi?project_id=**').as('getRfiCounts')
        cy.server().route('GET', '/tenant/members/application/permissions?typeId=**').as('getTenantApplication')
        cy.server().route('GET', '/cna/forms/rfi_task?rfi_id=**&project_id=**').as('getRfiTask')
        cy.server().route('DELETE', '/cna/forms/rfi/**?project_id=**').as('deleteRfi')
        cy.server().route('DELETE', '/cna/forms/rfi/**/_draft?project_id=**').as('deleteDraftRfi')
        cy.server().route('PATCH', '/cna/forms/rfi/**').as('updateRfi')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(rfiConstants.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Request for Information')

    })

    it('Should valiate RFI landing page fields and counts', () => {

        cy.log('Validating All Top row fields')
            .wait('@getRfiList').its('status').should('eq', 200)
            .findByDataCy('all-rfi').should('exist')
            .findByDataCy('my-rfi').should('exist')
            .get('.search-cont > .form-control').should('exist')
            .findByDataCy('create_rfi_button').should('exist')
            .findByDataCy('more').should('exist')
            .findByDataCy('filter-button').should('exist')

        cy.log('Clicking on My-rfi button and validating assigned user')
            .clickElement('my-rfi')
            .url()
            .should('include', '/construct/rfi/mylist/')
            .wait('@getRfiList').its('status').should('eq', 200)
            .wait('@getWeatherForecast').its('status').should('eq', 200)
            .get(':nth-child(6) > .no-decoration > .table-column')
            .should('contain.text', `${loggedInUser.name}`)

        cy.log('Clicking on Export button and validating types of reports')
            .clickElement('my-rfi')
            .findByDataCy('downloadTemplate').should('exist')
            .findByDataCy('download_pdf').should('exist')

        cy.log('Validating Rfi counts')
            .clickElement('all-rfi')
            .wait('@getRfiCounts').then((xhr) => {
                cy.wait('@getWeatherForecast').its('status').should('eq', 200)
                const rfiCounts = xhr.response.body.data.count
                cy.log('number of RFIs ->', rfiCounts)
                if (rfiCounts > 50) {
                    cy.findByText(`1-50 of ${rfiCounts}`).should('exist')
                    cy.findByDataCy('nextpage').should('exist')
                    cy.findByDataCy('lastPage').should('exist')
                }
                else {
                    cy.findByText(`1-${rfiCounts} of ${rfiCounts}`).should('exist')
                }
            })


    });

    it('Should verify filters fields and functionality', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        cy.clickElement('filter-button')
        cy.get('.sidebar-header > .d-inline-block').should('contain.text', 'Filters')
        cy.findByDataCy('clear-all').should('exist')
        cy.findByDataCy('created_by').should('exist')
        cy.findByDataCy('assignee').should('exist')
        cy.findByDataCy('responsible_contractor').should('exist')
        cy.findByDataCy('state').should('exist')
        cy.findByDataCy('rfi_type').should('exist')
        cy.findByDataCy('resolution').should('exist')
        cy.findByDataCy('priority').should('exist')
        cy.findByDataCy('due_date').should('exist')
        cy.findByDataCy('subject').should('exist')
        cy.findByDataCy('question').should('exist')
        cy.findByDataCy('apply_filters').should('exist')
        cy.clickElement('reset')
        cy.wait('@getRfiCounts').its('status').should('eq', 200)

    });

    it('Should verify RFI column names and sorts', () => {

        cy.log('Verifying columns of construct-RFIs')
            .wait('@getRfiList').its('status').should('eq', 200)
        cy.findByText('ID').should('exist')
        cy.findByText('Subject').should('exist')
        cy.findByText('Due Date').should('exist')
        cy.findByText('Responsible Contractor').should('exist')
        //Sort pending due to data-cy //
    });

    it('Should Search for empty RFI and validate message', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        cy.get('.search-cont > .form-control')
            .type(rfiConstants.EMPTY_RFI_SEARCH)
            .get('.empty-msg')
            .should('contain.text', 'No results found.')
            .get('.search-cont > .form-control')
            .clear()

    });

    it('Should validate all fields in Create RFI page', () => {

        cy.log('Checking all fileds existence in create RFI page')
            .wait('@getRfiList').its('status').should('eq', 200)
            .clickElement('create_rfi_button')
            .wait('@getRfiConfig').its('status').should('eq', 200)
            .get('.rfiHeader').should('contain.text', 'Create RFI')
            .findByDataCy('User Defined ID').should('exist')
            .findByDataCy('RFI Type').should('exist')
            .findByDataCy('Subject').should('exist')
            .findByDataCy('Assign To').should('exist')
            .findByDataCy('Due Date').should('exist')
            .findByDataCy('Priority').should('exist')
            .findByDataCy('Responsible Contractor').should('exist')
            .findByDataCy('Location').should('exist')
            .findByDataCy('Schedule Impact').should('exist')
            .findByDataCy('Cost Impact').should('exist')
            .findByDataCy('Question').should('exist')
            .findByDataCy('createRFIdraft').should('exist')
            .findByDataCy('createRFI').should('exist')
            .get('.card-header').contains('Uploaded Files').should('exist')
            .findByDataCy('add_uploaded_files_section').should('exist')
            .get('.card-header').contains('Spec Section').should('exist')
            .findByDataCy('add_spec_section').should('exist')
            .get('.card-header').contains('Distribution List').should('exist')
            .findByDataCy('add_distribution_list').should('exist')
            .get('.card-header').contains('Linked Features').should('exist')


    });

    it('Should validate RFI details form fields', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.log('Verifyig Top edit header fields')
            .findByDataCy('sGeneralInfo').should('exist')
            .findByDataCy('sAddress').should('exist')
            .findByDataCy('sCInfo').should('exist')
            .findByDataCy('sPoc').should('exist')
            .findByDataCy('linkedFeature').should('exist')
            .findByDataCy('rfiHistory').should('exist')

        cy.log('Verifyig Question tab fields')
            .clickElement('sAddress')
            .get('.card-header').contains('Question').should('exist')
            .get('.comment-section-item').trigger('mouseover')
            .findByDataCy('edit_question').should('exist')
            .findByDataCy('reply-comment').should('exist')

        cy.log('Verifyig Upload files fields')
            .get('.card-header').contains('Uploaded Files').should('exist')
            .findByDataCy('add_uploaded_files_section').should('exist')
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').contains('Upload File').should('exist')
            .get('.mat-tab-labels').contains(' Selected Files (0)').should('exist')
            .get('.mat-tab-labels').contains('Local').should('exist')
            .get('.mat-tab-labels').contains('Documents').should('exist')
            .get('.mat-tab-labels').contains('Photos').should('exist')
            .get('.mat-tab-labels').contains('Drawings').should('exist')
            .findByDataCy('upload').should('exist')
            .findByDataCy('close_attachments_popup').should('exist')
            .clickElement('close_attachments_popup')

        cy.log('Verifyig Upload files fields')
            .get('.card-header').contains('Spec Section').should('exist')
            .clickElement('add_spec_section')
            .get('.modal-title').should('contain.text', 'Specification Section')
            .findByDataCy('close-spec').should('exist')
            .findByDataCy('add-spec').should('exist')
            .findByDataCy('close').should('exist')
            .clickElement('close')

        cy.log('Verifyig Associated drawings fields')
            .clickElement('sCInfo')
            .get('.card-header').contains('Associated Drawings').should('exist')

        cy.log('Verifyig add distribution list fields')
            .clickElement('sPoc')
            .get('.card-header').contains('Distribution List').should('exist')
            .clickElement('add_distribution_list')
            .get('.modal-title').contains('Distribution List').should('exist')
            .findByDataCy('search').should('exist')
            .findByDataCy('cancel').should('exist')
            .findByDataCy('add').should('exist')
            .findByDataCy('close_dist_modal').should('exist')
            .clickElement('cancel')

        cy.log('Verifyig RFI Task fields')
            .clickElement('sCInfo')
            .get('.card-header').contains('RFI Tasks').should('exist')
            .findByDataCy('new_rfi_task').should('exist')

        cy.log('Verifyig History tab columns')
            .clickElement('rfiHistory')
            .get('#section7').should('contain.text', 'RFI History')
            .get('#section7').contains('Date').should('exist')
            .get('#section7').contains('Action By').should('exist')
            .get('#section7').contains('Action').should('exist')

        deleteRfi()
    });

    it('Should Create new RFI and validate History', () => {

        cy.log('Creating new RFI')
            .url()
            .should('include', 'construct/rfi/list/')
            .wait('@getRfiList').its('status').should('eq', 200)
            .clickElement('create_rfi_button')
            .url()
            .should('include', '/construct/rfi/create/')
            .wait('@getRfiConfig').its('status').should('eq', 200)

            .get('.header-md')
            .should('contain.text', 'Create RFI')

        cy.log('clicking on create RFI button and checking Warning Alert')
            .clickElement('createRFI')
            .get('.ui-toast-detail')
            .should('contain.text', 'Please fill all mandatory fields.')

        cy.log('Entering all values to create RFI')
            .getRandomString().then(userDefinedID => {
                cy.findByDataCy('User Defined ID').type(userDefinedID)
                newUserDefinedID = userDefinedID
            })

        cy.clickElement('RFI Type')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .enterText('Subject', rfiConstants.SUBJECT)
            .clickElement('Assign To')
        cy.get('.ui-multiselect-filter-container > .ui-inputtext')
            .type(rfiConstants.RFI_DISTRIBUTION_USER)
        cy.findByText(rfiConstants.RFI_DISTRIBUTION_USER).click()
            .get('.ui-calendar > .ui-inputtext').click()
            .get('.ui-datepicker-today > .ui-state-default')
            .click()
            .clickElement('Priority')
        cy.get('[role="option"] span').then(role => {
            role[1].click()
        })
            .enterText('Responsible Contractor', rfiConstants.RESPONSIBLE_CONTRACTOR)
            .clickElement('Schedule Impact')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .clickElement('Cost Impact')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .get('.ql-editor')
            .type('which location..?')
            .clickElement('createRFI')
            .wait('@createRfi')
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI created.')

        cy.log('Validating RFI History for creation of RFI')
            .wait('@getRfiProjectHistory').then((xhr) => {
                const rfiCreatedDateAndTime = xhr.response.body.success[0].updated_at
                cy.log(rfiCreatedDateAndTime)
                    .clickElement('rfiHistory')
                cy.findByText(rfiCreatedDateAndTime).should('exist')
                    .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
                    .get('.history-section-body').should('contain.text', 'RFI created')
            })

    })

    it('Should Search created RFI and Export to CSV,PDF file', () => {

        cy.server().route('POST', '/cna/reports/**/RFI/csv').as('exportCSVfile')
        cy.server().route('POST', '/cna/reports/RFIsList').as('exportPDFfile')
        cy.server().route('GET', '/file_management/weather/forecast?**').as('getWeatherForecast')

        cy.wait('@getRfiList').its('status').should('eq', 200)
        cy.wait('@getRfiCounts').its('status').should('eq', 200)
            .get('.search-cont > .form-control')
            .type(newUserDefinedID)
            .get('.text-black > .table-column')

        cy.log('Exporting to CSV,PDF and validating success message')
            .clickElement('more')
            .clickElement('downloadTemplate')
            .wait('@exportCSVfile').its('status').should('eq', 200)

            .clickElement('more')
            .clickElement('download_pdf')
            .wait('@exportPDFfile').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'PDF created successfully')
            .get('.search-cont > .form-control').clear()

    });

    it('Should Close,Reopen and Delete RFI', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        cy.get('.search-cont > .form-control')
            .type(newUserDefinedID)
            .get('.text-black > .table-column')
            .should('contain.text', newUserDefinedID)
            .click()

        cy.wait('@getRfiConfig').its('status').should('eq', 200)

        cy.log('Closing RFI created through draft')
            .clickElement('closeRFI')
            .get('.ui-dropdown-trigger-icon')
            .click()
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .clickElement('closeConfirm')
            .get('.badge-pill')
            .should('contain.text', 'Closed')

        cy.log('Reopening RFI')
            .clickElement('reopenRFI')
            .get('.modal-title')
            .should('contain.text', 'Reopen RFI')
            .get('.modal-footer > .btn-primary')
            .click()
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Reopened.')
            .get('.badge-pill')
            .should('contain.text', 'Open')

        cy.log('Again Closing RFI to delete')
            .clickElement('closeRFI')
            .get('.modal-title')
            .should('contain.text', 'Close RFI')
            .get('.ui-dropdown-trigger-icon')
            .click()
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .clickElement('closeConfirm')
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI closed.')

        cy.log('Validating RFI History for closing,Reopening')
        cy.wait('@getRfiProjectHistory').its('status').should('eq', 200)
            .clickElement('rfiHistory')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', 'RFI closed')
            .get('.history-section-body').should('contain.text', 'RFI reopened')

        cy.log('Deleting created project')
            .clickElement('deleteRFI')
            .get('.modal-title')
            .should('contain.text', 'Delete RFI')
            .get('.modal-footer > .btn-primary')
            .click()
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Deleted.')
            .wait('@deleteRfi').its('status').should('eq', 200)

    });

    it('Should Create empty RFI draft,discard it and validate History', () => {

        cy.log('Creating empty RFI')
            .url()
            .should('include', 'construct/rfi/list/')
            .wait('@getRfiList').its('status').should('eq', 200)
            .findByDataCy('create_rfi_button').click({ force: true })
            .url()
            .should('include', '/construct/rfi/create/')
            .wait('@getRfiConfig').its('status').should('eq', 200)

        cy.log('Clicking on save draft')
            cy.findByText('Save As Draft').click()
            //.clickElement('createRFIdraft')
            .wait('@createRfiDraft')
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft created.')
            .get('.badge-pill')
            .should('contain.text', 'DRAFT')

        cy.log('Validating RFI History for drafting of RFI')
            .wait('@getRfiProjectHistory').then((xhr) => {
                const rfiCreatedDateAndTime = xhr.response.body.success[0].updated_at
                cy.log(rfiCreatedDateAndTime)
                    .clickElement('rfiHistory')
                cy.findByText(rfiCreatedDateAndTime).should('exist')
                    .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
                    .get('.history-section-body').should('contain.text', 'Draft created')
            })

        cy.log('Discarding empty RFI draft')
            .clickElement('discardRFIDraft')
            .wait('@deleteDraftRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft discarded.')
            .wait('@getRfiCounts').its('status').should('eq', 200)
    });

    it('Should Draft and Create RFI', () => {

        cy.log('Drafting RFI')
            .wait('@getRfiList').its('status').should('eq', 200)
            .url()
            .should('include', 'construct/rfi/list/')
            .findByDataCy('create_rfi_button')
            .click({ force: true })
            .url()
            .should('include', '/construct/rfi/create/')
            .wait('@getRfiConfig').its('status').should('eq', 200)

            .get('.header-md')
            .should('contain.text', 'Create RFI')
            .findByDataCy('User Defined ID')
            .type(rfiConstants.DREAFT_RFI)

            .clickElement('RFI Type')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .enterText('Subject', rfiConstants.SUBJECT)
            .clickElement('Assign To')
            .get(':nth-child(1) > .ui-multiselect-item')
            .get('.ui-calendar > .ui-inputtext')
            .click()
            .get('.ui-datepicker-today > .ui-state-default')
            .click()
            .clickElement('Priority')
        cy.get('[role="option"] span').then(role => {
            role[1].click()
        })
            .enterText('Responsible Contractor', rfiConstants.RESPONSIBLE_CONTRACTOR)
            .clickElement('Schedule Impact')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .clickElement('Cost Impact')
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .get('.ql-editor')
            .type(rfiConstants.RFI_QUESTION)
            cy.findByText('Save As Draft').click()
            //.clickElement('createRFIdraft')
            .wait('@createRfiDraft')
            .get('.ui-toast-detail')
            .should('contain.text', 'Draft created.')
            .get('.badge-pill')
            .should('contain.text', 'DRAFT')

            .findByDataCy('discardRFIDraft')
            .should('exist')
            .wait('@getTenantApplication').its('status').should('eq', 200)
            .clickElement('createRFI')
            .wait('@createRfi')
            .wait('@getRfiProjectHistory')
            .get('.badge-pill')
            .should('contain.text', 'Open')

        cy.log('Validating RFI History for creation of RFI')
            .wait('@getRfiProjectHistory').then((xhr) => {
                const rfiCreatedDateAndTime = xhr.response.body.success[0].updated_at
                cy.log(rfiCreatedDateAndTime)
                    .clickElement('rfiHistory')
                cy.findByText(rfiCreatedDateAndTime).should('exist')
                    .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
                    .get('.history-section-body').should('contain.text', 'RFI created')
            })

    });

    it('Should Edit RFi details section', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.log('Editing RFI details-Assign To')
            .get('.card-body > .row > :nth-child(1)').trigger('mouseover')
            .findByDataCy('edit_assignee').click({ force: true })
            .get('.ui-multiselect-trigger-icon').click()
            .get(':nth-child(1) > .ui-multiselect-item').click()
            .findByDataCy('cancel_assignee').should('exist')
            .clickElement('save_assignee')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Editing RFI details-Subject')
            .get('.card-body > .row > :nth-child(3)').trigger('mouseover')
            .findByDataCy('edit_subject').click({ force: true })
            .findByDataCy('Subject').clear()
            .enterText('Subject', rfiConstants.EDI_RFI_DETAILS)
            .findByDataCy('cancel_subject').should('exist')
            .clickElement('save_subject')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Editing RFI details-cost impact')
            .get('.card-body > .row > :nth-child(4)').trigger('mouseover')
            .findByDataCy('edit_cost_impact').click({ force: true })
            .get('.ui-dropdown-trigger-icon').click()
            .get('[role="option"] span').then(role => {
                role[1].click()
            })
            .clickElement('save_cost_impact')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Editin RFI location')
            .get('.card-body > .row > :nth-child(9)').trigger('mouseover')
            .findByDataCy('edit_location').click({ force: true })
            .get('.input-icons > .fa').click({ force: true })
            .get('.ui-tree-toggler').click({ force: true })
            .get('.treeHeight').contains('Ground floor').click()
            .get('.modal-footer').contains('Confirm').click()
            .clickElement('save_location')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Editing RFI details-Responsible contractor')
            .get('.card-body > .row > :nth-child(9)').trigger('mouseover')
            .findByDataCy('edit_responsible_contractor').click({ force: true })
            .enterText('Responsible Contractor', rfiConstants.EDI_RESPONSIBLE_CONTRACTOR)
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .findByDataCy('cancel_responsible_contractor').should('exist')
            .clickElement('save_responsible_contractor')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Editing RFI details-RFI type')
            .get('.card-body > .row > :nth-child(10)').trigger('mouseover')
            .findByDataCy('edit_rfi_type').click({ force: true })
            .get('.ui-dropdown-trigger-icon').click()
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .clickElement('save_rfi_type')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        deleteRfi()

    });

    it('Should Edit RFI-Question, Attach file, add comment and validate History', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.server().route('POST', '/cna/comments/rfi/**').as('updateRfiComment')
        cy.server().route('DELETE', '/cna/comments/rfi/**/**').as('deleteRfiComment')

        cy.log('Editing Question')
            .clickElement('sAddress')
            .get('.comment-section-item').trigger('mouseover')
            .findByDataCy('edit_question').click({ force: true })
            .get('.ql-editor').clear()
            .get('.ql-editor').type(rfiConstants.EDIT_QUESTION)
            .findByDataCy('cancel_question').should('exist')
            .findByDataCy('reply-comment').should('exist')
            .clickElement('save_question')

        cy.log('Adding comment to Question')
            .clickElement('reply-comment')
            .get('.ql-editor').type(rfiConstants.REPLY_COMMENT)

        cy.log('Attaching file to comment')
            .clickElement('comment_attach_file')
            .get('.mat-tab-labels').contains('Documents').click()
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains('Cypress.pdf').click()
            .clickElement('upload')

            .findByDataCy('cancel_comment').should('exist')
            .clickElement('add_comment')
            .wait('@updateRfiComment').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Comment added successfully.')

        cy.log('Deleting comment')
            .clickElement('more_0')
            .clickElement('delete_comment_0')
            .get('.modal-header').should('contain.text', 'Delete Comment')
            .get('.modal-footer').contains('OK').click()
            .wait('@deleteRfiComment').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Comment deleted successfully.')

        cy.log('Validating RFI History for creation of RFI')
        cy.wait('@getRfiProjectHistory').its('status').should('eq', 200)
            .clickElement('rfiHistory')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', 'Question updated to ' + rfiConstants.EDIT_QUESTION)
            .get('.history-section-body').should('contain.text', 'Comment added: ' + rfiConstants.REPLY_COMMENT)
            .get('.history-section-body').should('contain.text', 'Cypress.pdf added to comment ' + rfiConstants.REPLY_COMMENT)
            .get('.history-section-body').should('contain.text', 'Comment deleted: ' + rfiConstants.REPLY_COMMENT)

        deleteRfi()
    });

    it('Should Edit RFI-upload file and spec section', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.server().route('POST', '/cna/attachments/rfi/**').as('uploadFile')
        cy.server().route('DELETE', '/cna/attachments/**/**').as('deleteFile')

        cy.get('[data-cy=sAddress] > span').click()
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').should('contain.text', 'Upload File')

        const yourFixturePath = 'code.png';
        cy.log('Uploading file from local')
            .get('.mat-tab-labels').contains('Local').click()
            .get("[data-cy='browse_files']").attachFile(yourFixturePath, { force: true });

        cy.log('Uploading file from Documents')
            .get('.mat-tab-labels').contains(' Documents ').click()
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains(rfiConstants.UPLOAD_DOC).click()

        cy.log('Uploading photos')
            .get('.mat-tab-labels').contains('Photos').click()
            .clickElement('select_photos_0')

        cy.log('Uploading Drawings')
            .get('.mat-tab-labels').contains('Drawings').should('exist')

        cy.clickElement('upload')
        cy.wait('@uploadFile').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Attachment(s) saved successfully')

        cy.log('Deleting uploaded files')
            .clickElement('delete_uploaded_files_section_0')
            .get('.modal-title').should('contain.text', 'Delete File')
            .get('.modal-content').contains('OK').click()
            .wait('@deleteFile').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'File deleted successfully')

        cy.clickElement('delete_uploaded_files_section_0')
            .get('.modal-content').contains('OK').click()


        cy.log('Adding specification')
            .clickElement('add_spec_section')
            .get('.modal-title').should('contain.text', 'Specification Section')
            .get('.ui-tree-toggler').click()
            .get('.ui-tree-container').contains('review - material').click()
            .clickElement('add-spec')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Deleting specifications')
            .clickElement('delete_spec_section_0')
            .get('.modal-title').should('contain.text', 'Delete Spec')
            .get('.modal-content').contains('OK').click()
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Validating RFI History for uploading files')
        cy.wait('@getRfiProjectHistory').its('status').should('eq', 200)
            .clickElement('rfiHistory')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', rfiConstants.UPLOAD_DOC + ' added')
            .get('.history-section-body').should('contain.text', rfiConstants.UPLOAD_SPEC + ' added')
            .get('.history-section-body').should('contain.text', rfiConstants.UPLOAD_SPEC + ' removed')

        deleteRfi()
    });

    it('Should Edit RFI-Assocaiated drawing and Distribution list', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.clickElement('sPoc')
        cy.log('Validating Associated Drawings')
            .get('#section4').should('contain.text', 'Associated Drawings')

        cy.log('Validating Associated Drawings')
            .get('#section3').should('contain.text', 'Distribution List')
            .clickElement('add_distribution_list')

        cy.log('Adding Distribution')
            .get('.modal-title').should('contain.text', 'Distribution List')
            .get('.modal-content').should('contain.text', 'Only members who are part of project')
            .get('.modal-content').should('contain.text', 'Distribution Groups')
            .enterText('search', 'cy')
            .get(':nth-child(2) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()

        cy.log('Adding user')
            .get('.mat-tab-header').should('contain.text', 'Users').click()
            .enterText('search_users', rfiConstants.RFI_DISTRIBUTION_USER1)
            .get(':nth-child(1) > td > .mr-2 > .ui-chkbox > .ui-chkbox-box').click()
            .findByDataCy('cancel').should('exist')
            .clickElement('add')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Deleting user')
            .clickElement('remove_dist0')
            .get('.modal-header').should('contain.text', 'Delete')
            .get('.modal-footer').contains('Yes').click()
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        deleteRfi()

    });

    it('Should Create and delete RFI-task', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.server().route('GET', '/cmb/templates/rfi_task').as('getRfiTaskTemplate')
        cy.server().route('GET', '/cna/V2/project/**/history/RFI_TASK/**').as('getRfiTaskHistory')
        cy.server().route('DELETE', '/cna/forms/rfi_task/**?project_id=**').as('deleteRfiTask')

        cy.log('Creating RFI-task and deleting')
            .clickElement('sPoc')
            .clickElement('new_rfi_task')
            .wait('@getRfiTaskTemplate').its('status').should('eq', 200)
            .get('.modal-header').should('contain.text', 'Create RFI Task')

            .enterText('subject', rfiConstants.RFI_TASK_SUBJECT)
            .clickElement('rfi_task_type')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .clickElement('assignee')
            .get(':nth-child(1) > .ui-multiselect-item').click()
            .clickElement('assignee')
            .clickElement('due_date')
            .get('.ui-datepicker-today > .ui-state-default').click()
            .clickElement('priority')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .findByDataCy('cancel').should('exist')
            .clickElement('create_task')

        cy.log('Deleting Rfi task')
            .clickElement('route_rfi_task0')
            .wait('@getRfiTaskHistory').its('status').should('eq', 200)
            .clickElement('deleterfi')
            .get('.modal-header').should('contain.text', 'Delete RFI Task')
            .get('.modal-content').should('contain.text', 'Are you sure you want to delete this RFI Task?')
            .get('.modal-footer').contains('OK').click()
            .wait('@deleteRfiTask').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task deleted successfully.')
            .wait('@getRfiProjectHistory').its('status').should('eq', 200)

        deleteRfi()
    });

    it('Should Add Linked features and delete', () => {

        cy.wait('@getRfiList').its('status').should('eq', 200)
        createRfi()

        cy.log('Adding linked feature')
            .get('.rfi-title').should('contain.text', 'Linked Features')
            .get('.rfi-card-header').contains('New').click()
            .get('.modal-header').should('contain.text', 'Link Features')

        cy.log('Adding Cost issue as link feature')
            .get('.pi-chevron-down').click()
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .get('.headerProperty').contains('Cost Issue ID').should('exist')
            .get('.headerProperty').contains('Cost Issue Title').should('exist')
            .get('.headerProperty').contains('Budget Amount').should('exist')

            .get('.ui-chkbox-box').click()
            .findByDataCy('cancel').should('exist')
            .clickElement('link')
            .wait('@updateRfi').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI updated.')

        cy.log('Deleting linked feature')
        //data -cy //
        cy.log('Validating RFI History for creation of RFI')
        cy.wait('@getRfiProjectHistory').its('status').should('eq', 200)
            .clickElement('rfiHistory')
            .get('.history-section-body').should('contain.text', `${loggedInUser.name}`)
            .get('.history-section-body').should('contain.text', 'CI-001 - Cost issue linked')

        deleteRfi()
    });

})

const createRfi = function () {

    cy.server().route('GET', '/cmb/list_view/rfi').as('getRfiList')
    cy.server().route('GET', '/cmb/config_dropdown/**').as('getRfiConfig')
    cy.server().route('POST', '/cna/forms/rfi').as('createRfi')
    cy.server().route('GET', '/cmb/templates/rfi_task').as('getRfiTaskTemplate')
    cy.url().should('include', 'construct/rfi/list/')

    cy.log('Creating new RFI')
        .findByDataCy('create_rfi_button').click({ force: true })
        .url()
        .should('include', '/construct/rfi/create/')
        .wait('@getRfiConfig').its('status').should('eq', 200)
    cy.getRandomString().then(rfiSubject => {
        cy.findByDataCy('Subject').type(rfiSubject)
        cy.clickElement('Assign To')
        cy.get('.ui-multiselect-filter-container > .ui-inputtext')
            .type(rfiConstants.RFI_DISTRIBUTION_USER)
        cy.findByText(rfiConstants.RFI_DISTRIBUTION_USER).click()
        cy.clickElement('Due Date')
            .get('.ui-datepicker-today > .ui-state-default').click()
            .get('.ql-editor')
            .type(rfiConstants.RFI_QUESTION)
            .clickElement('createRFI')
            .wait('@createRfi').its('status').should('eq', 201)
            .wait('@getRfiProjectHistory').its('status').should('eq', 200)
    })

}

const deleteRfi = function () {

    cy.log('Closing RFI created through draft')
        .clickElement('closeRFI')
        .get('.ui-dropdown-trigger-icon')
        .click()
        .get('[role="option"] span').then(role => {
            role[0].click()
        })
        .clickElement('closeConfirm')

    cy.log('Deleting created project')
        .clickElement('deleteRFI')
        .get('.modal-title')
        .should('contain.text', 'Delete RFI')
        .get('.modal-footer > .btn-primary')
        .click()
        .wait('@deleteRfi').its('status').should('eq', 200)
        .wait('@getRfiList').its('status').should('eq', 200)

}