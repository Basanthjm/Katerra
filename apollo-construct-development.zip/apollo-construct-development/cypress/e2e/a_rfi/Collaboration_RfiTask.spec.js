import '../../support/setup-tests'
import { getUser } from '../../support/users'

const rfiTaskConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Collaboration RFI Task', () => {

    let newrfiTaskSubject

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cmb/list_view/rfi_task').as('getRfiTaskList')
        cy.server().route('GET', '/cna/forms/rfi_task?project_id=**').as('getRfiTaskForm')
        cy.server().route('GET', '/cna/V2/project/**/history/RFI/**').as('getRfiProjectHistory')
        cy.server().route('GET', '/cna/V2/project/**/history/RFI_TASK/**').as('getRfiTaskHistory')
        cy.server().route('DELETE', '/cna/forms/rfi/**?project_id=**').as('deleteRfi')
        cy.server().route('DELETE', '/cna/forms/rfi_task/**?project_id=**').as('deleteRfiTask')
        cy.server().route('PATCH', '/cna/forms/rfi_task/**/state').as('updateRfiTaskState')
        cy.server().route('PATCH', '/cna/forms/rfi_task/**').as('updateRfiTask')
        cy.server().route('GET', '/cmb/list_view/rfi').as('getRfiList')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(rfiTaskConstants.SEARCH_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Request for Information Task')

       })

    it('Should valiate RFI Task landing page fields', () => {

        cy.log('Verifying all fields when landed on RFI task page')
            .wait('@getRfiTaskList').its('status').should('eq', 200)
            .get('.search-cont > .form-control').should('exist')
            .findByDataCy('allRFItask').should('exist')
            .findByDataCy('myRFItask').should('exist')
            .findByDataCy('more').should('exist')
            .clickElement('more')
            .findByDataCy('downloadTemplate').should('exist')
            .findByDataCy('filter').should('exist')

    });

    it('Should verify RFI Task column names and sorts', () => {

        cy.log('Verifying columns of construct-RFI Task')
        cy.wait('@getRfiTaskList').its('status').should('eq', 200)
        cy.findByText('Task ID').should('exist')
        cy.findByText('RFI ID').should('exist')
        cy.findByText('Subject').should('exist')
        cy.findByText('Due Date').should('exist')

        cy.get('.component-grid').contains('last Updated').should('exist')
            .get('.component-grid').contains('created On').should('exist')
            .get('.component-grid').contains('Initiated By').should('exist')

    });

    it('Should Search for empty RFI Task and validate message', () => {

        cy.wait('@getRfiTaskList').its('status').should('eq', 200)
            .get('.search-cont > .form-control').should('exist')
            .type(rfiTaskConstants.EMPTY_RFI_SEARCH)
            .get('.empty-msg')
            .should('contain.text', 'No results found.')
            .get('.search-cont > .form-control')
            .clear()
    });

    it('Should verify filters fields and clear All functionality', () => {

        cy.wait('@getRfiTaskList').its('status').should('eq', 200)
            .clickElement('filter')
            .get('.sidebar-header').should('contain.text', 'Filters')
            .findByDataCy('clear-all').should('exist')
            .findByDataCy('created_by').should('exist')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('state').should('exist')
            .findByDataCy('rfi_task_type').should('exist')
            .findByDataCy('priority').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('subject').should('exist')
            .findByDataCy('description').should('exist')
            .clickElement('reset')
            .wait('@getRfiTaskForm').its('status').should('eq', 200)

        cy.log('Checking clear All functionality')
            .clickElement('filter')
            .clickElement('created_by')
            .get('.ui-widget-header > .ui-chkbox > .ui-chkbox-box').click()
            .clickElement('created_by')
            .clickElement('assignee')
            .get('.ui-widget-header > .ui-chkbox > .ui-chkbox-box').click()
            .clickElement('assignee')
            .clickElement('due_date')
            .get('.ui-datepicker-today > .ui-state-default').click()
            .get('.sidebar-header').click()
            .findByDataCy('subject').type('filter all')
            .findByDataCy('description').type('filter desc')
            .clickElement('clear-all')
            .findByDataCy('subject').should('contain.text', '')

    });

    it('Should verify all RFI Task page fields', () => {

        createRfi()

        cy.log('Verifying all create RFi Task fields')
            .clickElement('sPoc')
            .clickElement('new_rfi_task')
            .get('.modal-title').should('contain.text', 'Create RFI Task')
            .findByDataCy('subject').should('exist')
            .findByDataCy('rfi_task_type').should('exist')
            .findByDataCy('assignee').should('exist')
            .findByDataCy('due_date').should('exist')
            .findByDataCy('priority').should('exist')
            .findByDataCy('description').should('exist')
            .findByDataCy('cancel').should('exist')
            .findByDataCy('create_task').should('exist')

        cy.log('Deleting created RFI')
            .clickElement('cancel')

        deleteRFI()

    });

    it('Should validate RFI Task details fields', () => {

        CreateRfiAndRfiTask()

        cy.log('Verifyig Top edit header fields')
            .findByDataCy('sGeneralInfo').should('exist')
            .findByDataCy('sAddress').should('exist')
            .findByDataCy('uploadedFile').should('exist')
            .findByDataCy('rfihistory').should('exist')

        cy.log('Verifyig comments fields')
            .clickElement('sAddress')
            .get('.replies-container').should('contain.text', 'Comments')
            .findByDataCy('add-comment').should('exist')
            .clickElement('add-comment')
            .findByDataCy('comment_text').should('exist')
            .findByDataCy('add_comment').should('exist')
            .findByDataCy('cancel_comment').should('exist')

        cy.log('Verifyig Upload files fields')
            .get('.card-header').contains('Uploaded Files').should('exist')
            .findByDataCy('add_uploaded_files_section').should('exist')
            .clickElement('add_uploaded_files_section')
            .get('.modal-title').contains('Upload File').should('exist')
            .get('.mat-tab-labels').contains(' Selected Files (0)').should('exist')
            .get('.mat-tab-labels').contains('Local').should('exist')
            .get('.mat-tab-labels').contains('Documents').should('exist')
            .get('.mat-tab-labels').contains('Photos').should('exist')
            .get('.mat-tab-labels').contains('Drawings').should('exist')
            .findByDataCy('upload').should('exist')
            .findByDataCy('close_attachments_popup').should('exist')
            .clickElement('close_attachments_popup')

        cy.log('Verifyig History tab columns')
            .clickElement('rfihistory')
            .get('#rfiHistory').should('contain.text', 'RFI Task History')
            .get('#rfiHistory').contains('Date').should('exist')
            .get('#rfiHistory').contains('Action By').should('exist')
            .get('#rfiHistory').contains('Action').should('exist')

        deleteRfiTaskAndRfi()
    });

    it('Should create RFI Task and validate counts', () => {

        createRfi()
        cy.server().route('GET', '/cmb/templates/rfi_task').as('getRfiTaskTemplate')
        cy.log('Creating RFI Task')
            .clickElement('sPoc')
            .clickElement('new_rfi_task')
            .wait('@getRfiTaskTemplate').its('status').should('eq', 200)
            .get('.modal-header').should('contain.text', 'Create RFI Task')
        cy.getRandomString().then(rfiTaskSubject => {
            cy.findByDataCy('subject').type(rfiTaskSubject)
            newrfiTaskSubject = rfiTaskSubject
            cy.clickElement('rfi_task_type')
                .get('[role="option"] span').then(role => {
                    role[0].click()
                })
        })
        cy.clickElement('assignee')
            .get(':nth-child(1) > .ui-multiselect-item').click()
            .clickElement('assignee')
            .clickElement('due_date')
            .get('.ui-datepicker-today > .ui-state-default').click()
            .clickElement('priority')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .get('.ql-editor').type(rfiTaskConstants.RFI_TASK_DESCRIPTION)
            .findByDataCy('cancel').should('exist')
            .clickElement('create_task')
            .wait('@getRfiProjectHistory').its('status').should('eq', 200)

        cy.log('Navigating to RFI Task page to check counts')
            .clickElement('Collaboration')
            .clickElement('Request for Information Task')

        cy.wait('@getRfiTaskForm').then((xhr) => {
            const rfiTaskCount = xhr.response.body.data.count
            const rfiTaskCounts = rfiTaskCount + 1
            cy.log('number of RFIs ->', rfiTaskCounts)
            if (rfiTaskCounts > 50) {
                cy.findByText(`1-50 of ${rfiTaskCounts}`).should('exist')
            }
            else {
                cy.findByText(`1-${rfiTaskCounts} of ${rfiTaskCounts}`).should('exist')
            }
        })
    });

    it('Should verify My RFI Task counts and Assignee', () => {

        cy.server().route('GET', '/cna/forms/rfi_task?assignee=**&project_id=**').as('getMyRfiTaskListCount')

        cy.log('Clicking on My RFI Task button and verifying counts')
            .clickElement('myRFItask')
            .url()
            .should('include', '/construct/rfi/task/mylist/')
            .wait('@getMyRfiTaskListCount').then((xhr) => {
                const myRfiTaskCounts = xhr.response.body.data.count
                cy.log('number of RFIs ->', myRfiTaskCounts)
                if (myRfiTaskCounts > 50) {
                    cy.findByText(`1-50 of ${myRfiTaskCounts}`).should('exist')
                }
                else {
                    cy.findByText(`1-${myRfiTaskCounts} of ${myRfiTaskCounts}`).should('exist')
                }
            })

        cy.log('Verfiying Assignee in My RFI Task List')
            .get(':nth-child(1) > :nth-child(6) > a > .table-column')
            .should('contain.text', `${loggedInUser.name}`)

    });

    it('Should Search created RFI task and delete', () => {

        cy.get('.search-cont > .form-control').type(newrfiTaskSubject)
            .get('.featureList').should('contain.text', newrfiTaskSubject)

        cy.log('Deleting created RFI task')
        cy.get('.example-container').contains(newrfiTaskSubject).click()
        cy.wait('@getRfiTaskHistory').its('status').should('eq', 200)
            .clickElement('deleterfi')
        cy.get('.modal-header').should('contain.text', 'Delete RFI Task')
        cy.get('.modal-footer').contains('OK').click()
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task deleted successfully.')
        cy.wait('@getRfiProjectHistory').its('status').should('eq', 200)

        cy.log('Closing RFI')
            .clickElement('closeRFI')
            .get('.ui-dropdown-trigger-icon').click()
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .clickElement('closeConfirm')

        cy.log('Deleting created RFI')
            .clickElement('deleteRFI')
            .get('.modal-footer > .btn-primary')
            .click()
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Deleted.')
            .wait('@deleteRfi').its('status').should('eq', 200)
    });

    it('Should Edit RFI Task detais and validating History', () => {

        CreateRfiAndRfiTask()

        cy.log('Editing RFI Task-Details-Subject')
            .get(':nth-child(2) > .form-group').trigger('mouseover')
            .findByDataCy('edit_subject').click({ force: true })
            .findByDataCy('Subject').clear()
            .findByDataCy('Subject').type(rfiTaskConstants.RFI_TASK_DETAILS_SUBJECT)
            .findByDataCy('cancel_subject').should('exist')
            .clickElement('save_subject')
            .wait('@updateRfiTask').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task updated successfully')

        cy.log('Editing RFI Task-Details-Subject')
            .get(':nth-child(3) > .form-group').trigger('mouseover')
            .findByDataCy('edit_rfi_task_type').click({ force: true })
            .clickElement('RFI Task Type')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })
            .findByDataCy('cancel_rfi_task_type').should('exist')
            .clickElement('save_rfi_task_type')
            .wait('@updateRfiTask').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task updated successfully')

        cy.log('Editing RFI task due date')
            .get(':nth-child(5) > .form-group').trigger('mouseover')
            .findByDataCy('edit_due_date').click({ force: true })
            .clickElement('Due Date')
            .clickElement('save_due_date')
            .wait('@updateRfiTask').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task updated successfully')

        cy.log('Editing RFI task description')
            .get('.col-xl-12 > .form-group').trigger('mouseover')
            .findByDataCy('edit_description').click({ force: true })
            .get('.ql-editor').type(rfiTaskConstants.RFI_TASK_DETAILS_DESCRIPTION)
            .findByDataCy('cancel_description').should('exist')
            .clickElement('save_description')
            .wait('@updateRfiTask').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'RFI Task updated successfully')

        cy.log('Validating Edit history')
            .wait('@getRfiTaskHistory').its('status').should('eq', 200)
            .clickElement('rfihistory')
            .get('#rfiHistory').should('contain.text', 'Subject updated to ' + rfiTaskConstants.RFI_TASK_DETAILS_SUBJECT)
            .get('#rfiHistory').should('contain.text', 'Description updated to ' + rfiTaskConstants.RFI_TASK_DETAILS_DESCRIPTION)

        deleteRfiTaskAndRfi()

    });

    it('Should Add comments to RFI Task and validate History', () => {

        CreateRfiAndRfiTask()

        cy.server().route('GET', '/cna/attachments/comment/**').as('getRfiTaskComments')
        cy.server().route('DELETE', '/cna/comments/rfitask/**/**').as('deleteRfiTaskComments')

        cy.log('Adding comment to RFI TAsk')
            .clickElement('sAddress')
            .clickElement('add-comment')
            .get('.ql-editor').type(rfiTaskConstants.RFI_TASK_ADD_COMMENT)
            .findByDataCy('cancel_comment').should('exist')
            .clickElement('add_comment')
            .wait('@getRfiTaskComments').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Comment added successfully.')

        cy.log('Deleting Added comment')
            .clickElement('more_0')
            .clickElement('delete_comment_0')
            .get('.modal-header').should('contain.text', 'Delete Comment')
        cy.get('.modal-footer').contains('OK').click()
            .wait('@deleteRfiTaskComments').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Comment deleted successfully.')

        cy.log('Validating comments history')
            .wait('@getRfiTaskHistory').its('status').should('eq', 200)
            .clickElement('rfihistory')
            .get('#rfiHistory').should('contain.text', 'Comment added: ' + rfiTaskConstants.RFI_TASK_ADD_COMMENT)
            .get('#rfiHistory').should('contain.text', 'Comment deleted: ' + rfiTaskConstants.RFI_TASK_ADD_COMMENT)

        deleteRfiTaskAndRfi()

    });

    it('Should Edit RFI Task upload files and validate History', () => {

        CreateRfiAndRfiTask()

        cy.server().route('GET', '/cna/V1/project/**/documents').as('getRfiTaskDocuments')
        cy.server().route('DELETE', '/cna/attachments/**/**').as('deleteFile')

        cy.clickElement('uploadedFile')
        cy.clickElement('add_uploaded_files_section')

        const yourFixturePath = 'code.png';
        cy.log('Uploading file from local')
            .get('.mat-tab-labels').contains('Local').click()
            .get("[data-cy='browse_files']").attachFile(yourFixturePath, { force: true });

        cy.log('Uploading file from Documents')
            .get('.mat-tab-labels').contains('Documents').click()
            .wait('@getRfiTaskDocuments').its('status').should('eq', 200)
            .get('.ui-tree-toggler').click()
            .get('.pi-caret-right').click()
            .get('.ui-tree-container').contains('Cypress.pdf').click()

        cy.log('Uploading photos')
            .get('.mat-tab-labels').contains('Photos').click()
            .clickElement('select_photos_0')

        cy.clickElement('upload')

        cy.wait('@getRfiTaskHistory').its('status').should('eq', 200)
        cy.clickElement('uploadedFile')
        cy.log('Deleting uploaded files')
            .clickElement('delete_uploaded_files_section_0')
            .get('.modal-title').should('contain.text', 'Delete File')
            .get('.modal-content').contains('OK').click()
            .wait('@deleteFile').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'File deleted successfully')

            .clickElement('delete_uploaded_files_section_0')
            .get('.modal-content').contains('OK').click()
            .wait('@deleteFile').its('status').should('eq', 200)

        cy.log('Validating RFI History for uploading files')
        cy.wait('@getRfiTaskHistory').its('status').should('eq', 200)
            .clickElement('rfihistory')
            .get('#rfiHistory').should('contain.text', `${loggedInUser.name}`)
            .get('#rfiHistory').should('contain.text', 'Cypress.pdf added')
            .get('#rfiHistory').should('contain.text', 'Cypress.pdf removed')

        deleteRfiTaskAndRfi()

    });

});

const createRfi = function () {

    cy.server().route('GET', '/cmb/list_view/rfi').as('getRfiList')
    cy.server().route('GET', '/cmb/config_dropdown/**').as('getRfiConfig')
    cy.server().route('POST', '/cna/forms/rfi').as('createRfi')

    cy.clickElement('Collaboration')
    cy.clickElement('Request for Information')
    
    cy.url().should('include', 'construct/rfi/list/')
    cy.wait('@getRfiList').its('status').should('eq', 200)

    cy.log('Creating new RFI')
        .findByDataCy('create_rfi_button').click({ force: true })
        .url()
        .should('include', '/construct/rfi/create/')
        .wait('@getRfiConfig').its('status').should('eq', 200)
    cy.getRandomString().then(rfiSubject => {
        cy.findByDataCy('Subject').type(rfiSubject)
    })
    cy.clickElement('Assign To')
        cy.get('.ui-multiselect-filter-container > .ui-inputtext')
            .type(rfiTaskConstants.RFI_DISTRIBUTION_USER)
        cy.findByText(rfiTaskConstants.RFI_DISTRIBUTION_USER).click()
        .clickElement('Due Date')
        .get('.ui-datepicker-today > .ui-state-default').click()
        .get('.ql-editor')
        .type(rfiTaskConstants.RFI_QUESTION)
        .clickElement('createRFI')
        .wait('@createRfi').its('status').should('eq', 201)
        .wait('@getRfiProjectHistory').its('status').should('eq', 200)
}
const CreateRfiAndRfiTask = function () {

    let newrfiTaskSubject

    cy.server().route('GET', '/cmb/list_view/rfi').as('getRfiList')
    cy.server().route('GET', '/cmb/config_dropdown/**').as('getRfiConfig')
    cy.server().route('POST', '/cna/forms/rfi').as('createRfi')
    cy.server().route('GET', '/cmb/templates/rfi_task').as('getRfiTaskTemplate')

    cy.clickElement('Collaboration')
    cy.clickElement('Request for Information')
    cy.url().should('include', 'construct/rfi/list/')
    cy.wait('@getRfiList').its('status').should('eq', 200)

    cy.log('Creating new RFI')
        .findByDataCy('create_rfi_button').click({ force: true })
        .url()
        .should('include', '/construct/rfi/create/')
        .wait('@getRfiConfig').its('status').should('eq', 200)
    cy.getRandomString().then(rfiSubject => {
        cy.findByDataCy('Subject').type(rfiSubject)
        cy.clickElement('Assign To')
        cy.get('.ui-multiselect-filter-container > .ui-inputtext')
            .type(rfiTaskConstants.RFI_DISTRIBUTION_USER)
        cy.findByText(rfiTaskConstants.RFI_DISTRIBUTION_USER).click()
        cy.clickElement('Due Date')
            .get('.ui-datepicker-today > .ui-state-default').click()
            .get('.ql-editor')
            .type(rfiTaskConstants.RFI_QUESTION)
            .clickElement('createRFI')
            .wait('@createRfi').its('status').should('eq', 201)
            .wait('@getRfiProjectHistory').its('status').should('eq', 200)

        cy.log('Creating RFI Task')
            .clickElement('sPoc')
            .clickElement('new_rfi_task')
            .wait('@getRfiTaskTemplate').its('status').should('eq', 200)
            .get('.modal-header').should('contain.text', 'Create RFI Task')
        cy.getRandomString().then(rfiTaskSubject => {
            cy.findByDataCy('subject').type(rfiTaskSubject)
            newrfiTaskSubject = rfiTaskSubject
            cy.clickElement('due_date')
                .get('.ui-datepicker-today > .ui-state-default').click()
                .get('.ql-editor').type(rfiTaskConstants.RFI_TASK_DESCRIPTION)
                .clickElement('create_task')

            cy.log('Searching for created RFI Task')
            cy.clickElement('Collaboration')
            cy.clickElement('Request for Information Task')
                .wait('@getRfiTaskList').its('status').should('eq', 200)
                .wait(2000)
                .get('.search-cont > .form-control').type(newrfiTaskSubject)
                .get(':nth-child(1) > .text-black > .table-column').click()
                .wait('@getRfiTaskHistory').its('status').should('eq', 200)

        })
    })
}
const deleteRfiTaskAndRfi = function () {

    cy.log('Deleting RFI Task')
    cy.findByText('Delete RFI Task').click()
        .get('.modal-header').should('contain.text', 'Delete RFI Task')
        .get('.modal-footer').contains('OK').click()
        .wait('@deleteRfiTask').its('status').should('eq', 200)
        .wait('@getRfiProjectHistory').its('status').should('eq', 200)
    deleteRFI()
}
const deleteRFI = function () {

    cy.log('Closing RFI')
        .clickElement('closeRFI')
        .get('.ui-dropdown-trigger-icon')
        .click()
        .get('[role="option"] span').then(role => {
            role[0].click()
        })
        .clickElement('closeConfirm')
        .get('.badge-pill')
        .should('contain.text', 'Closed')

    cy.log('Deleting created project')
        .clickElement('deleteRFI')
        .get('.modal-title')
        .should('contain.text', 'Delete RFI')
        .get('.modal-footer > .btn-primary')
        .click()
        .wait('@deleteRfi').its('status').should('eq', 200)
}