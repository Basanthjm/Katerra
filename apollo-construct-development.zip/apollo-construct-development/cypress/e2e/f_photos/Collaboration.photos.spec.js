import '../../support/setup-tests'
import { getUser } from '../../support/users'

const photosConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Collaboration Photos', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/tenant/members?sortKey=name&sort=1&pageSize=500&type=project&typeId=**&includeUsers=true').as('getTenantMembers')
        cy.server().route('POST', '/cna/V1/project/**/albums').as('createAlbum')
        cy.server().route('GET', 'cna/V1/project/**/albums?sort_by=date_added&sort_order=DESC').as('getPhotosAlbums')
        cy.server().route('GET', '/cna/V1/project/**/album/**/photos?sort_by=date_added&sort_order=DESC').as('getAlbumPhotos')
        cy.server().route('POST', '/cna/V1/project/**/albums').as('createAlbum')
        cy.server().route('PATCH', '/cna/V1/project/**/albums/**').as('updateAlbum')
        cy.server().route('DELETE', '/cna/V1/project/**/albums').as('deleteAlbum')
        cy.server().route('DELETE', 'cna/V1/project/**/album/**/photos').as('deletePhotos')
        cy.server().route('POST', '/file_management/s3/upload_info').as('uploadFileToAlbum')
        cy.server().route('GET', '/cna/V1/project/**/deleted/photos').as('deletedPhotosList')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(photosConstants.SEARCH_UPLOAD_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Photos')

    })

    it('Should verify photos landing page', () => {

        cy.wait('@getPhotosAlbums').its('status').should('eq', 200)
        cy.log('Verifying photos header fields')
        //.get('.controls-header').should('contain.text', 'Photo Albums')
        //.clickElement('more')
        //.findByDataCy('deleted_photos').should('exist')
        //.findByDataCy('add_new').should('exist')
        cy.findByText('Add New').should('exist')
            .findByDataCy('search').should('exist')
            .findByDataCy('sort_by').should('exist')
            .clickElement('sort_by')
            .findByDataCy('sort_by_name').should('exist')
            .findByDataCy('sort_by_date').should('exist')

    });

    it('Should search for emplty album and validate message', () => {

        let i
        cy.wait('@getPhotosAlbums').then((xhr) => {
            const photosAlbumCounts = xhr.response.body.count
            if (photosAlbumCounts > 0) {
                cy.log('number of albums ->', photosAlbumCounts)
                for (i = photosAlbumCounts; i > 0; i--) {
                    if (i == 0) { break; }
                    deleteAlbum()
                }
            }

            cy.log('Creating 1st album')
            cy.findByText('Add New').click()
                .getRandomString().then(albumName => {
                    cy.findByDataCy('album_name').type(albumName)
                    cy.clickElement('create_album')
                    cy.wait('@createAlbum').its('status').should('eq', 201)
                    cy.wait('@getPhotosAlbums').its('status').should('eq', 200)
                })

            cy.findByDataCy('search')
                .type(photosConstants.EMPTY_RFI_SEARCH)
                .get('.empty-msg')
                .should('contain.text', 'No results found.')
                .findByDataCy('search')
                .clear()

            deleteAlbum()
        })

    });

    it('Should create an photo album,Search, Edit and delete it', () => {

        createPhotoAlbumAndSearch()
        editAlbumName()
        deleteAlbum()

    });

    it('Should create album,add photo and delete album', () => {

        createPhotoAlbumAndSearch()

        cy.log('verifying add photos pop-up and close pop-up')
            .clickElement('add_photos')
            .get('.modal-header').should('contain.text', 'Add New Photo(s)')
            .get('.drag-drop-body').should('contain.text', 'To upload, Drag and Drop your file(s) here or Browse Files.')
            .findByDataCy('close_popup').should('exist')
            .findByDataCy('upload_photos').should('exist')
            .clickElement('close_popup')

        cy.log('Adding photo')
            .clickElement('add_photos')
        const imageFile = 'code.png'
        cy.get('[type="file"]').attachFile(imageFile)
            .wait(2000)
            .clickElement('upload_photos')
            .wait('@uploadFileToAlbum').its('status').should('eq', 200)
            .wait('@getAlbumPhotos').its('status').should('eq', 200)

        editAlbumName()
        deleteAlbum()

    });

    it('Should create album,add photos,validate counts,delete photos and delete album', () => {

        createPhotoAlbumAndSearch()

        cy.log('Adding photos')
            .clickElement('add_photos')
        const imageFile = 'code.png'
        cy.get('[type="file"]').attachFile(imageFile)
            .wait(2000)
            .get('[type="file"]').attachFile(imageFile)
            .wait(2000)
            .get('[type="file"]').attachFile(imageFile)
            .wait(2000)
            .clickElement('upload_photos')
            .wait('@uploadFileToAlbum').its('status').should('eq', 200)

        cy.log('validating photos counts')
            .wait('@getAlbumPhotos').then((xhr) => {
                const photosCounts = xhr.response.body.count
                cy.log('number of photos ->', photosCounts)
                cy.get('.badge').should('contain.text', 3)
                //Hard coded count respose data - will fix //
            })

        cy.log('Deleting photo by single')
            .clickElement('more_0')
            .clickElement('delete_photo_0')
            .get('.modal-footer').contains('OK').click()
            .wait('@deletePhotos')

        cy.log('Deleting photo by selecting all')
        //.clickElement('select_all')
        cy.get(':nth-child(1) > .checkbox-container > .checkmark').click()
            .clickElement('select_photo')
        cy.get('.modal-header').should('contain.text', 'Delete Photo')
            .get('.modal-footer').contains('OK').click()
            .wait('@deletePhotos')
            .get('.ui-toast-detail')
            .should('contain.text', 'photo(s) deleted successfully')

        editAlbumName()
        deleteAlbum()
    });

    it('Should add photos to existing album and delete album', () => {

        let PhotosAlbumName
        cy.wait('@getPhotosAlbums').then((xhr) => {
            const photosAlbumCounts = xhr.response.body.count
            if (photosAlbumCounts > 0) {
                cy.log('number of albums ->', photosAlbumCounts)
                for (i = photosAlbumCounts; i > 0; i--) {
                    if (i == 0) { break; }
                    deleteAlbum()
                }

                cy.log('Adding album ')
                    .clickElement('add_new')
                    .findByDataCy('close_popup').should('exist')
                    .get('.modal-title').should('contain.text', 'New Photo Album')
                    .getRandomString().then(albumName => {
                        cy.findByDataCy('album_name').type(albumName)
                        cy.clickElement('create_album')
                        PhotosAlbumName = albumName
                        cy.wait('@createAlbum').its('status').should('eq', 201)
                            .get('.ui-toast-detail')
                            .should('contain.text', 'Album Created Successfully')

                        cy.log('Searching created album')
                            .findByDataCy('search')
                            .type(PhotosAlbumName)
                            .get('.content > [data-cy=nav_album_0]').click()
                            .wait('@getAlbumPhotos').its('status').should('eq', 200)

                        cy.log('Adding photos')
                            .clickElement('add_photos')
                        const imageFile = 'code.png'
                        cy.get('[type="file"]').attachFile(imageFile)
                            .wait(2000)
                            .get('[type="file"]').attachFile(imageFile)
                            .wait(2000)
                            .clickElement('upload_photos')
                            .wait('@uploadFileToAlbum').its('status').should('eq', 200)
                            .wait('@getAlbumPhotos').its('status').should('eq', 200)

                        cy.findByDataCy('back').click()
                            .wait('@getAlbumPhotos').its('status').should('eq', 200)

                        cy.log('Adding photos to existing album')
                            .clickElement('add_new')
                            .clickElement('add_new_photo')

                        cy.log('verifying add photos pop-up')
                            .get('.modal-header').should('contain.text', 'Add New Photo(s)')
                            .get('.modal-body').should('contain.text', 'List of Albums:')

                        cy.log('Adding photo')
                        cy.get('select').select(PhotosAlbumName)
                        cy.get('[type="file"]').attachFile(imageFile)
                            .wait(2000)
                            .clickElement('upload')
                            .wait('@uploadFileToAlbum').its('status').should('eq', 200)
                            .wait('@getPhotosAlbums').its('status').should('eq', 200)
                        deleteAlbum()
                        cy.findByDataCy('close_popup').click({ force: true })

                    })

            }
        })
    });

    it('Should create album,add photos and move photos to other album', () => {

        cy.server().route('POST', '/cna/V1/project/**/album/**/photos').as('updatephotosToAlbum')
        cy.wait('@getPhotosAlbums').then((xhr) => {
            const photosAlbumCounts = xhr.response.body.count
            if (photosAlbumCounts > 0) {
                cy.log('number of albums ->', photosAlbumCounts)
                for (i = photosAlbumCounts; i > 0; i--) {
                    if (i == 0) { break; }
                    deleteAlbum()
                }
                cy.log('Creating 1st album')
                    .clickElement('add_new')
                    .findByDataCy('album_name').type('Move photos album')
                cy.clickElement('create_album')
                cy.wait('@createAlbum').its('status').should('eq', 201)
                cy.wait('@getPhotosAlbums').its('status').should('eq', 200)

                createAlbum()
                cy.get('.content > [data-cy=nav_album_0]').click()
                cy.log('Adding photo to move')
                    .clickElement('add_photos')
                const imageFile1 = 'code.png'
                const imageFile2 = 'Delete.png'

                cy.get('[type="file"]').attachFile(imageFile1)
                    .wait(2000)
                    .get('[type="file"]').attachFile(imageFile2)
                    .wait(2000)
                    .clickElement('upload_photos')
                    .wait('@uploadFileToAlbum').its('status').should('eq', 200)
                    .wait('@updatephotosToAlbum')
                    .wait('@getAlbumPhotos')
                    .wait('@getAlbumPhotos')

                cy.log('Moving added photo to other album')
                    .get(':nth-child(1) > .checkbox-container > .checkmark').click()
                    .clickElement('move_photo')
                    .get('.modal-title').should('contain.text', 'Move Photo(s)')
                    .get('.modal-body').should('contain.text', 'ALBUM NAME')
                    .get('select').select('Move photos album')
                    .findByDataCy('cancel').should('exist')
                    .clickElement('move')
                    .get('#confirmPopup > .modal-content > .modal-body')
                    .should('contain.text', 'Are you sure you want to Move the selected photos to Move photos album?')
                    .get('#confirmPopup > .modal-content > .modal-footer').contains('OK').click()
                    .wait('@getAlbumPhotos')

                cy.log('Searching for moved to photo in moved album')
                    .clickElement('back')
                    .wait('@getPhotosAlbums').its('status').should('eq', 200)
                    .get('.content > [data-cy=nav_album_1]').click()
                    .wait('@getAlbumPhotos')
                    .findByDataCy('search_photos').type('delete.png')
                    .get('.card-head').should('contain.text', 'Delete.png')

                cy.log('Deleting albums')
                    .clickElement('back')
                    .wait('@getPhotosAlbums').its('status').should('eq', 200)
                    .get('.select-all-checkmark > .checkbox-container > .checkmark').click()
                    .findByDataCy('delete').click()
                    .get('.modal-footer').contains('Ok').click()
                    .wait('@deleteAlbum').its('status').should('eq', 200)
                    .wait('@getPhotosAlbums').its('status').should('eq', 200)
                    .findByDataCy('album_more_0').should('not.exist')
            }
        })
    });

    it('Should create album,add photos and view in Timeline,validate counts', () => {

        cy.server().route('GET', '/cna/V1/project/**/timeline-photos/count').as('getTimeLineCounts')
        cy.server().route('GET', '/cna/V1/project/**/photos/timeline_view?limit=15&sort_by=taken_on&sort_order=DESC').as('getTimeLinePhotos')

        createPhotoAlbumAndSearch()
        cy.log('Adding photo to move')
            .clickElement('add_photos')
        const imageFile1 = 'code.png'
        const imageFile2 = 'Delete.png'

        cy.get('[type="file"]').attachFile(imageFile1)
            .wait(2000)
            .get('[type="file"]').attachFile(imageFile2)
            .wait(2000)
            .clickElement('upload_photos')
            .wait('@uploadFileToAlbum').its('status').should('eq', 200)
            .wait('@getAlbumPhotos')

        cy.get('.ap-bread-item > span').click()
            .wait('@getPhotosAlbums')
            .get('.d-inline-flex > :nth-child(2)').click()
            .wait('@getTimeLinePhotos').its('status').should('eq', 200)
            .get('.section-header').should('contain.text', '2 Photos')
            .get('.pt-10 > :nth-child(1)').click()
            .wait('@getPhotosAlbums')
        deleteAlbum()

    });

    it('Should create multiple albums,select all and delete', () => {

        cy.wait('@getPhotosAlbums').then((xhr) => {
            const photosAlbumCounts = xhr.response.body.count
            if (photosAlbumCounts > 0) {
                cy.log('number of albums ->', photosAlbumCounts)
                for (i = photosAlbumCounts; i > 0; i--) {
                    if (i == 0) { break; }
                    deleteAlbum()
                }

                cy.log('Creating 1st album')
                    .clickElement('add_new')
                    .getRandomString().then(albumName => {
                        cy.findByDataCy('album_name').type(albumName)
                        cy.clickElement('create_album')
                        cy.wait('@createAlbum').its('status').should('eq', 201)
                        cy.wait('@getPhotosAlbums').its('status').should('eq', 200)
                    })

                createAlbum()
                createAlbum()
                createAlbum()

                cy.log('Deleting all albums by selecting all options')
                    .get('.select-all-checkmark > .checkbox-container > .checkmark').click()
                    .findByDataCy('delete').click()
                    .get('.modal-header').should('contain.text', 'Delete Album')
                    .get('.modal-body').should('contain.text', 'Are you sure you want to delete the selected albums?')
                    .get('.modal-footer').contains('Ok').click()
                    .wait('@deleteAlbum').its('status').should('eq', 200)
                    .wait('@getPhotosAlbums').its('status').should('eq', 200)
                    .findByDataCy('album_more_0').should('not.exist')
                cy.get('.ap-header-icon').click()
                cy.wait('@getProjects').its('status').should('eq', 200)
            }
        })
    });

})

const createPhotoAlbumAndSearch = function () {

    let i
    let PhotosAlbumName
    cy.wait('@getPhotosAlbums').then((xhr) => {
        const photosAlbumCounts = xhr.response.body.count
        if (photosAlbumCounts > 0) {
            cy.log('number of albums ->', photosAlbumCounts)
            for (i = photosAlbumCounts; i > 0; i--) {
                if (i == 0) { break; }
                deleteAlbum()
            }
        }
        cy.log('Adding album ')
        cy.findByText('Add New').click()
            .findByDataCy('close_popup').should('exist')
            .get('.modal-title').should('contain.text', 'New Photo Album')
            .getRandomString().then(albumName => {
                cy.findByDataCy('album_name').type(albumName)
                cy.clickElement('create_album')
                PhotosAlbumName = albumName
                cy.wait('@createAlbum').its('status').should('eq', 201)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Album Created Successfully')

                cy.log('Searching created album')
                    .findByDataCy('search')
                    .type(PhotosAlbumName)
                    .get('.content > [data-cy=nav_album_0]').click()
                    .wait('@getAlbumPhotos').its('status').should('eq', 200)
            })

    })
}

const createAlbum = function () {

    let i
    cy.wait('@getPhotosAlbums').then((xhr) => {
        const photosAlbumCounts = xhr.response.body.count
        if (photosAlbumCounts > 0) {
            cy.log('number of albums ->', photosAlbumCounts)
            for (i = photosAlbumCounts; i > 0; i--) {
                if (i == 0) { break; }
                deleteAlbum()
            }
        }
        cy.log('Adding album ')
        cy.findByText('Add New').click()
            .findByDataCy('add_new_album').click({ force: true })
            .findByDataCy('close_popup').should('exist')
            .get('.modal-title').should('contain.text', 'New Photo Album')
            .getRandomString().then(albumName => {
                cy.findByDataCy('album_name').type(albumName)
                cy.clickElement('create_album')
                cy.wait('@createAlbum').its('status').should('eq', 201)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Album Created Successfully')
                cy.wait('@getPhotosAlbums').its('status').should('eq', 200)
            })
    })

}

const editAlbumName = function () {

    let PhotosEditedAlbumName

    cy.log('Editing album name')
        .get('.d-inline-flex > .top-header > [data-cy=edit_AlbumName] > span').trigger('mouseover')
        .get('.d-inline-flex > .top-header > [data-cy=edit_AlbumName] > span').click({ force: true })
        .get('.d-inline-flex > .top-header > .inner-top-header-input > [data-cy=album_name]').clear()
        .getRandomString().then(EditAlbumName => {
            cy.get('.d-inline-flex > .top-header > .inner-top-header-input > [data-cy=album_name]').type(EditAlbumName)
            PhotosEditedAlbumName = EditAlbumName
            cy.findByDataCy('cancel_update').should('exist')
            cy.get('.d-inline-flex > .top-header > .inner-top-header-input > [data-cy=update_album_name] > img').click()
            cy.wait('@updateAlbum').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Album Name Updated.')

            cy.get('.ap-bread-item > span').click()
            cy.log('Searching for edited album')
                .findByDataCy('search')
                .type(PhotosEditedAlbumName)

        })

}

const deleteAlbum = function () {

    cy.log('Deleting album')
        .findByDataCy('album_more_0').click({ force: true })
        .findByDataCy('del_album_0').click({ force: true })
        .get('.modal-header').should('contain.text', 'Delete Album')
        .get('.modal-footer').contains('Ok').click({ force: true })
        .wait('@deleteAlbum').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'deleted successfully')
    cy.wait('@getPhotosAlbums').its('status').should('eq', 200)
}