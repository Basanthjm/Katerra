describe('Collaboration dashboard page', () => {

    it('Should verify the Construct Dashboard page', () => {
        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members/permissions?type=**').as('getUserPermissions')
        cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&active=true&includeAll=true').as('getProjects')
        

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').then((xhr) => {

            //Verify project count
            const listOfProjects = xhr.response.body.success
            const numberOfProjects = xhr.response.body.total_projects
            let searchText = ''
            //Search with the first project on the page or with one on the next page
            if (numberOfProjects > 50) {
                searchText = listOfProjects[50].name
            }
            else {
                searchText = listOfProjects[0].name
            }

            cy.log('number of projects ->', numberOfProjects)
           
             //wait till the loader goes off
            cy.get('.loading > .fa').should('not.be.visible', { timeout: 6000 })
            cy.findByText(`Projects(${numberOfProjects})`).should('exist')
            //Verify pagination
            if (numberOfProjects > 50) {
                cy.findByText(`1-50 of ${numberOfProjects}`).should('exist')
            }
            else {
                cy.findByText(`1-${numberOfProjects} of ${numberOfProjects}`).should('exist')
            }
            //Verify search box is displayed
            cy.findByPlaceholderText(/ Search/i).should('exist')
            //Verify table headers are displayed
            cy.findByRole('table')
                .get('tr').eq(0).should('contain', 'Project Name')
                .get('tr').eq(0).should('contain', 'Project Type')
                .get('tr').eq(0).should('contain', 'Stage')
                .get('tr').eq(0).should('contain', 'Description')
            //Verify table contents for all projects that are listed in the first page
            //It verifies that the data for each project related to name, type and description are properly shown on the UI
            cy.findByRole('table')
            let i = 0;
            cy.get('tbody tr').each(($row) => {
                cy.get($row).contains('td', listOfProjects[i].name)
                if (listOfProjects[i].project_type) {
                    cy.get($row).contains('td', listOfProjects[i].project_type)
                }

                if (listOfProjects[i].description) {
                    cy.get($row).contains('td', listOfProjects[i].description)
                }

                i += 1
            })

            //Verify Search with a project name from the list of projects returned

            cy.get('.form-control').click().type(searchText)

            cy.findByRole('table')
                .get('tr').eq(1).should('contain', searchText)
                //Verify Search count
                .get('.ng-star-inserted > label').should('contain', '1-1 of 1')
                //Verify the next page button
                .get('.fa-angle-right').parent().should('have.attr', 'class', 'plr-5 arrowEnabled arrowDisabled')
                //Clear search
                .get('.clear-search > img').click()
            //Verify count and next page btns are proper

            if (numberOfProjects > 50) {
                cy.get('.ng-star-inserted > label').should('contain', `1-50 of ${numberOfProjects}`)
                cy.get('.fa-angle-right').parent().should('have.attr', 'class', 'plr-5 arrowEnabled')
            } else {
                cy.get('.ng-star-inserted > label').should('contain', `1-${numberOfProjects} of ${numberOfProjects}`)
                cy.get('.fa-angle-right').parent().should('have.attr', 'class', 'plr-5 arrowEnabled arrowDisabled')
            }

        })
         cy.get('.ap-header-icon').click()
         cy.wait('@getProjects').its('status').should('eq', 200)
      
    })
})