import '../../support/setup-tests'
import { getUser } from '../../support/users'

const specConstants = require('../../support/constants')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

let newDivisionName

describe('Collaboration Specifications', () => {

    beforeEach(() => {

        cy.server().route('GET', '/cmb/projects').as('getProjectsList')
        cy.server().route('GET', '/tenant/members?type=project&typeId=**').as('getTenantMembers')
        cy.server().route('GET', '/cna/V2/project/**/specifications/current').as('currentSpecs')
        cy.server().route('GET', '/cna/V2/project/**/specifications/manage').as('manageSpecs')
        cy.server().route('POST', 'cna/V2/project/**/specifications/upload/MANAGE').as('upoadManageSpecs')
        cy.server().route('GET', '/cna/V2/project/**/specifications/manage/status').as('specStatus')
        cy.server().route('POST', '/cna/V2/project/**/specifications/division').as('specDivision')
        cy.server().route('PATCH', '/cna/V2/project/**/specifications/division/**').as('updateDivision')
        cy.server().route('DELETE', '/cna/V2/project/**/specifications/division/**').as('deleteDivision')
        cy.server().route('GET', 'cna/V2/project/**/specifications/manage/issue_details').as('specDetails')
        cy.server().route('POST', '/cna/V2/project/**/specifications/upload/CURRENT').as('addSpecs')
        cy.server().route('GET', '/cna/V2/project/**/specifications/review_data').as('reviewSpecData')
        cy.server().route('POST', '/cna/V2/project/**/specifications/**/cancel_review').as('cancelReview')
        cy.server().route('POST', '/cna/V2/project/**/specifications/**/initiate_review').as('intiateReview')

        cy.visitPage('/construct/dashboard')
        cy.wait('@getProjectsList').its('status').should('eq', 200)
        cy.get('.ap-down-arrow').click()
        cy.get('.ap-project-search > .ap-text-sm').type(specConstants.SEARCH_UPLOAD_PROJECT)
        cy.get('.ap-project-item').click()
        cy.wait('@getTenantMembers').its('status').should('eq', 200)

        cy.clickElement('Collaboration')
        cy.clickElement('Specifications')
    })

    it('Should verfiy specifications landing page fields', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.wait('@specStatus').its('status').should('eq', 200)
            .findByDataCy('currentSpecs').should('exist')
            .findByDataCy('ManageSpecs').should('exist')
            .findByDataCy('searchBox').should('exist')
            .findByDataCy('more_icon').should('exist')
            .clickElement('more_icon')
            .findByDataCy('Deleted_Specifications').should('exist')
            .findByDataCy('Add_Division').should('exist')
            .findByDataCy('add_specs').should('exist')
            .clickElement('add_specs')
            .findByDataCy('Process_Spec_Book').should('exist')
            .findByDataCy('Add_Single_Section').should('exist')
    });

    it('Should search for Non-existing divsion and validate message', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
        })
        cy.findByDataCy('searchBox')
            .type(specConstants.EMPTY_RFI_SEARCH)
            .get('.empty-msg')
            .should('contain.text', 'No results found.')
            .findByDataCy('searchBox')
            .clear()
        deleteDivision()

    });

    it('Should add new division,Edit name,verify columns names and delete it', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
        })

        cy.log('Editing division name')
            .findByDataCy('more_0').click({ force: true })
            .findByDataCy('edit_0').click({ force: true })
            .clickElement('save_0')
            .get('.ui-toast-detail')
            .should('contain.text', 'Division Name should be unique')

        cy.findByDataCy('division_name_0').clear()
            .getRandomString().then(editDivisionName => {
                cy.findByDataCy('division_name_0').type(editDivisionName)
            })
        cy.findByDataCy('cancel_0').should('exist')
        cy.clickElement('save_0')
            .wait('@updateDivision').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Division name updated.')

        cy.clickElement('toggleButton_0')
        cy.get('.no-pointer').should('contain.text', 'Spec Section')
        cy.get('.no-pointer').should('contain.text', 'Spec Section Name')
        cy.get('.no-pointer').should('contain.text', 'Revision')
        cy.get('.no-pointer').should('contain.text', 'Issue Name')
        cy.get('.no-pointer').should('contain.text', 'Issue Date')
        cy.get('.no-pointer').should('contain.text', 'Added on')
        cy.get('.no-pointer').should('contain.text', 'Added By')
        cy.get('.panelDiv').should('contain.text', 'No specification for the given division.')
        deleteDivision()

    });

    it('Should add divisions,search and validate', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
        })
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
            cy.findByDataCy('searchBox').type(newDivisionName)
            cy.findByDataCy('checkEditableFields_0').should('contain.text', newDivisionName)
            cy.findByDataCy('searchBox').clear()
        })
        deleteDivision()
        cy.reload()
            .wait('@currentSpecs').its('status').should('eq', 200)
        deleteDivision()
    });

    it('Should verify Deleted Specification Files page fileds and column names', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.clickElement('more_icon')
            .clickElement('Deleted_Specifications')
            .get('.d-inline').should('contain.text', 'Deleted Specification Files')
            .findByDataCy('search').should('exist')
            .findByDataCy('sort_division').should('exist')
            .findByDataCy('sort_spec_sec').should('exist')
            .get('.th-lg').should('contain.text', 'Spec Section Name')
            .findByDataCy('sort_deleted_on').should('exist')
    });

    it('Should add new specification with single section-Existing division-New specification issue', () => {

        const specFile = 'Cypress.pdf'
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
        })

        cy.log('Adding new specification file')
            .clickElement('add_specs')
            .clickElement('Add_Single_Section')
            .get('.modal-header').should('contain.text', 'New Specification File')

        cy.log('Uploading file')
            .wait('@specDetails').its('status').should('eq', 200)
            .get('[type="file"]').attachFile(specFile)
            .wait(3000)

        cy.log('Adding existing division')
            .findByDataCy('existing_division').should('exist')
            .findByDataCy('New_Division').should('exist')
            .clickElement('division_name_dd')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })

        cy.log('Verifying spec radio buttons')
            .findByDataCy('new').should('exist')
            .findByDataCy('existing').should('exist')

        cy.getRandomString().then(issueName => {
            cy.enterText('issue_name', issueName)
        })
        cy.clickElement('issueDate')
            .get('.ui-datepicker-today > .ui-state-default').click()
        cy.getRandomString().then(specTittle => {
            cy.enterText('spec_title', specTittle)
        })
        cy.getRandomString().then(specSection => {
            cy.enterText('spec_no', specSection)
        })
        cy.enterText('revision', 'specriv')
            .findByDataCy('cancel').should('exist')
            .clickElement('add_spec')
            .wait('@addSpecs').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Spec File added')
            .reload()
            .wait('@currentSpecs').its('status').should('eq', 200)

        deleteDivision()
    });

    it('Should add new specification with single section-Existing division-Existing Specification Issue ', () => {

        const specFile = 'Cypress.pdf'
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.getRandomString().then(divisionName => {
            addNewDivision(divisionName)
        })

        cy.log('Adding new specification file')
            .clickElement('add_specs')
            .clickElement('Add_Single_Section')
            .get('.modal-header').should('contain.text', 'New Specification File')

        cy.log('Uploading file')
            .wait('@specDetails').its('status').should('eq', 200)
            .get('[type="file"]').attachFile(specFile)
            .wait(3000)

        cy.log('Adding existing division')
            .clickElement('division_name_dd')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })

        cy.log('Adding existing specification issue')
            .clickElement('existing')
            .clickElement('specificationIssueOption')
            .get('[role="option"] span').then(role => {
                role[0].click()
            })

        cy.getRandomString().then(specSectionName => {
            cy.enterText('spec_title', specSectionName)
        })
        cy.getRandomString().then(specSection => {
            cy.enterText('spec_no', specSection)
        })

        cy.clickElement('add_spec')
            .wait('@addSpecs').its('status').should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Spec File added')
            .reload()
            .wait('@currentSpecs').its('status').should('eq', 200)

        deleteDivision()
    });

    it('Should add new specification with single section-New division-New specification Issue', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        addNewSpec()
        deleteDivision()
    });

    it('Should search spec in deleted specs file with single section-New division-Existing specification Issue', () => {

        let searchSpecDivName
        let searchSpecSectionNo
        let searchSpecSectionName
        cy.server().route('GET', 'cna/V2/project/**/current?deleted=true').as('getDeletedSpecs')
        const specFile = 'Cypress.pdf'
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        cy.log('Adding new specification file')
            .clickElement('add_specs')
            .clickElement('Add_Single_Section')
            .get('.modal-header').should('contain.text', 'New Specification File')

        cy.log('Uploading file')
            .wait('@specDetails').its('status').should('eq', 200)
            .get('[type="file"]').attachFile(specFile)
            .wait(3000)

        cy.clickElement('New_Division')
        cy.getRandomString().then(specDivName => {
            cy.enterText('division_name', specDivName)
            searchSpecDivName = specDivName

            cy.log('Adding existing specification issue')
                .clickElement('existing')
                .clickElement('specificationIssueOption')
                .get('[role="option"] span').then(role => {
                    role[0].click()
                })

            cy.getRandomString().then(specSectionName => {
                cy.enterText('spec_title', specSectionName)
                searchSpecSectionName = specSectionName

                cy.getRandomString().then(specSectionNo => {
                    cy.enterText('spec_no', specSectionNo)
                    searchSpecSectionNo = specSectionNo

                    cy.clickElement('add_spec')
                        .wait('@addSpecs').its('status').should('eq', 201)
                        .get('.ui-toast-detail')
                        .should('contain.text', 'Spec File added')
                        .reload()
                        .wait('@currentSpecs')
                    //.its('status').should('eq', 200)

                    deleteDivision()
                    cy.log('Searching spec in deleted spec file section and deleted by')
                        .clickElement('more_icon')
                        .clickElement('Deleted_Specifications')
                        .wait('@getDeletedSpecs').its('status').should('eq', 200)
                        .findByDataCy('search').type(searchSpecDivName)
                        .get(':nth-child(1) > .table-column').should('contain.text', searchSpecDivName)
                        .get(':nth-child(2) > .table-column').should('contain.text', searchSpecSectionNo)
                        .get(':nth-child(3) > .table-column').should('contain.text', searchSpecSectionName)
                        .get(':nth-child(7) > .table-column').should('contain.text', loggedInUser.name)
                })
            })
        })
    });

    it('Should Add new spec,Edit,delete spec and division', () => {
        cy.server().route('PATCH', '/cna/V2/project/**/specifications/division/**/**').as('updateSpec')
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        addNewSpec()

        cy.log('Editing specification')
            .clickElement('toggleButton_0')
            .get('#ui-panel-0').trigger('mouseover')
            .findByDataCy('edit_0_0').click({ force: true })
            .clickElement('title_0_0').clear()
        cy.getRandomString().then(specSecName => {
            cy.enterText('title_0_0', specSecName)
        })
        cy.enterText('revision_0_0', 'Cy_00')
            .findByDataCy('close_0_0').should('exist')
            .clickElement('save _0_0')
            .wait('@updateSpec').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Section Updated')

        cy.log('Deleting spec')
        cy.wait('@currentSpecs')
        deleteSpec()
        cy.reload()
            .wait('@currentSpecs')
        deleteDivision()

    });

    it('Should process spec Book with new specification issue and cancel it', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        procesSpecBookNewSpecIsuue()
        cy.log('Canceling spec book')
            .wait('@reviewSpecData').its('status').should('eq', 200)
            .clickElement('cancel')
            .get('.ui-dialog-content')
            .should('contain.text', 'Canceling will end the review and the Specifications will not be uploaded.')
            .findByDataCy('keep_working').should('exist')
            .get('p-footer > [data-cy=cancel]').click()
            .wait('@cancelReview').its('status').should('eq', 200)
            .wait('@currentSpecs').its('status').should('eq', 200)
    });

    it('Should process spec book with new specification issue and cancel upload', () => {

        cy.wait('@currentSpecs').its('status').should('eq', 200)
        procesSpecBookNewSpecIsuue()
        cy.log('Saving process book')
            .clickElement('saveAndexit')
            .wait('@manageSpecs').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Saved')
            .wait(5000)

        cy.clickElement('Cancel_Upload')
            .get('.ui-dialog-content').should('contain.text', 'Are you sure you want to cancel the upload?')
            .clickElement('cancelUploadProcess')
            .wait('@cancelReview').its('status').should('eq', 200)
            .wait('@currentSpecs').its('status').should('eq', 200)
    });

    it('Should process spec book with new specification issue and finish review', () => {
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        procesSpecBookNewSpecIsuue()
        cy.clickElement('finishReview')
            .wait('@intiateReview').its('status').should('eq', 201)
            .get('.ui-dialog-content')
            .should('contain.text', 'Splitting has begun. You will get an email when the Spec Sections are ready.')
            .clickElement('ok')
            .wait('@manageSpecs').its('status').should('eq', 200)

    });

    it('Should process spec book with existing specification issue', () => {
        cy.wait('@currentSpecs').its('status').should('eq', 200)
        procesSpecBookExistingSpecIsuue()
        cy.clickElement('finishReview')
            .wait('@intiateReview').its('status').should('eq', 201)
            .get('.ui-dialog-content')
            .should('contain.text', 'Splitting has begun. You will get an email when the Spec Sections are ready.')
            .clickElement('ok')
            .wait('@manageSpecs').its('status').should('eq', 200)
       });
})

const addNewDivision = function (divisionName) {

    cy.log('Adding new division')
        .clickElement('Add_Division')
        .get('.modal-header').should('contain.text', 'Add New Division')
    cy.findByDataCy('division_name').type(divisionName)
    newDivisionName = divisionName
    cy.clickElement('add_division')
        .wait('@specDivision').its('status').should('eq', 201)
        .get('.ui-toast-detail')
        .should('contain.text', 'Division added')
}

const addNewSpec = function () {

    const specFile = 'Cypress.pdf'
    cy.log('Adding new specification file')
        .clickElement('add_specs')
        .clickElement('Add_Single_Section')
        .get('.modal-header').should('contain.text', 'New Specification File')

    cy.log('Uploading file')
        .wait('@specDetails').its('status').should('eq', 200)
        .get('[type="file"]').attachFile(specFile)
        .wait(3000)

    cy.clickElement('New_Division')
    cy.getRandomString().then(specDivName => {
        cy.enterText('division_name', specDivName)
    })
    cy.getRandomString().then(issueName => {
        cy.enterText('issue_name', issueName)
    })
    cy.clickElement('issueDate')
        .get('.ui-datepicker-today > .ui-state-default').click()
        .getRandomString().then(specSectionName => {
            cy.enterText('spec_title', specSectionName)
        })
    cy.getRandomString().then(specSection => {
        cy.enterText('spec_no', specSection)
    })
    cy.clickElement('add_spec')
        .wait('@addSpecs').its('status').should('eq', 201)
        .get('.ui-toast-detail')
        .should('contain.text', 'Spec File added')
        .reload()
        .wait('@currentSpecs')
    //.its('status').should('eq', 200)

}

const deleteDivision = function () {

    cy.clickElement('more_0')
        .clickElement('delete_0')
        .get('.modal-header').should('contain.text', 'Delete Division')
        .get('.modal-body').should('contain.text', 'Deleting this Division will delete all Spec Sections within it. Are you sure you want to delete?')
        .findByDataCy('cancel').should('exist')
        .clickElement('delete')
        .wait('@deleteDivision').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Division Deleted')
        .wait('@currentSpecs')
}

const deleteSpec = function () {

    cy.findByDataCy('delete_0_0').click({ force: true })
        .get('.ui-dialog-titlebar').should('contain.text', 'Delete Section')
        .get('.ui-dialog-content').should('contain.text', 'Are you sure you want to delete this spec section?')
        .findByDataCy('cancel').should('exist')
        .clickElement('confirm')
        .wait('@deleteDivision').its('status').should('eq', 200)
        .get('.ui-toast-detail')
        .should('contain.text', 'Section Deleted')
        .wait('@currentSpecs')
}

const procesSpecBookNewSpecIsuue = function () {

    const specFile = 'Cypress.pdf'
    cy.log('Uploading spec in spec book')
        .clickElement('add_specs')
        .clickElement('Process_Spec_Book')
        .get('.text-center').should('contain.text', 'Upload Specifications')
        .verifyElementDisabled('saveDrawingSetFile')

    cy.log('Uploading specification')
        .get('[type="file"]').attachFile(specFile)
        .wait(3000)
        .verifyElementEnabled('saveDrawingSetFile')
    cy.clickElement('saveDrawingSetFile')

    cy.log('Adding specification details and issue details')
        .get(':nth-child(1) > .headerFontSize')
        .should('contain.text', 'Add Specification Details')
        .verifyElementDisabled('next')
    cy.getRandomString().then(specFileName => {
        cy.enterText('specSectionTitle', specFileName)
    })

    cy.enterText('revisionNo', specConstants.REVISION_NUMBER)
        .enterText('specDescription', specConstants.SPEC_DESC)
        .findByDataCy('new_spec').should('exist')
        .findByDataCy('existing_spec').should('exist')
        .getRandomString().then(specIssueName => {
            cy.enterText('specIssueName', specIssueName)
        })
    cy.clickElement('issue_date')
        .get('.ui-datepicker-today > .ui-state-default').click()
        .verifyElementEnabled('next')
        .clickElement('next')
        .wait('@upoadManageSpecs').its('status').should('eq', 201)

    cy.log('confirming spec book process')
        .get('.ui-dialog-titlebar').should('contain.text', 'Confirmation')
        .get('.ui-dialog-content')
        .should('contain.text', 'Spec Book processing has begun. You will get an email when the file is ready for review.')
        .clickElement('reviewStarted')
        .wait('@manageSpecs').its('status').should('eq', 200)
        .wait('@specStatus').its('status').should('eq', 200)
        .wait(25000)
        .get('.d-block > span').should('contain.text', 'has been processed')
        .clickElement('review_specification')
}

const procesSpecBookExistingSpecIsuue = function () {

    const specFile = 'Cypress.pdf'
    cy.log('Uploading spec in spec book')
        .clickElement('add_specs')
        .clickElement('Process_Spec_Book')
        .get('.text-center').should('contain.text', 'Upload Specifications')
        .verifyElementDisabled('saveDrawingSetFile')

    cy.log('Uploading specification')
        .get('[type="file"]').attachFile(specFile)
        .wait(3000)
        .verifyElementEnabled('saveDrawingSetFile')
    cy.clickElement('saveDrawingSetFile')

    cy.log('Adding specification details and issue details')
        .get(':nth-child(1) > .headerFontSize')
        .should('contain.text', 'Add Specification Details')
        .verifyElementDisabled('next')
    cy.getRandomString().then(specFileName => {
        cy.enterText('specSectionTitle', specFileName)
    })

    cy.enterText('revisionNo', specConstants.REVISION_NUMBER)
        .enterText('specDescription', specConstants.SPEC_DESC)
        .findByDataCy('new_spec').should('exist')
        .findByDataCy('existing_spec').should('exist')
        .clickElement('existing_spec')
        .get(':nth-child(1) > .mat-list-item-content').click()
        .verifyElementEnabled('next')
        .clickElement('next')
        .wait('@upoadManageSpecs').its('status').should('eq', 201)

    cy.log('confirming spec book process')
        .get('.ui-dialog-titlebar').should('contain.text', 'Confirmation')
        .get('.ui-dialog-content')
        .should('contain.text', 'Spec Book processing has begun. You will get an email when the file is ready for review.')
        .clickElement('reviewStarted')
        .wait('@manageSpecs').its('status').should('eq', 200)
        .wait('@specStatus').its('status').should('eq', 200)
        .wait(25000)
        .get('.d-block > span').should('contain.text', 'has been processed')
        .clickElement('review_specification')
} 