const adminUser = {
  email: 'katerracypressautomation@gmail.com',
  password: 'Cypresstest@01',
  name: 'Katerra cypress Automation'
};
  
  const nonAdminUser = {
    email: 'katerracypressautomation@gmail.com',
    password: 'Cypresstest@01',
    name: 'katerracypressautomation@gmail.com'
  };
  
  export function getUser(userName) {
    if (userName == 'adminUser') {
      return adminUser;
    } else return nonAdminUser;
  }
  