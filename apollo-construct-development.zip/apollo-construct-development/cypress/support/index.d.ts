/// <reference types='Cypress' />
/// <reference types='../support' />

declare namespace Cypress {
    interface Chainable<Subject> {
        /**
         * Create several Todo items via UI
         * @example
         * cy.createDefaultTodos()
         */
        // createDefaultToDos(): Chainable<any>

        /**
         * Creates one Todo using UI
         * @example
         * cy.createTodo('new item')
         */
        //createTodo(title: string): Chainable<any>

        doLogin(): Chainable<any>;

        doLogOut(): Chainable<any>;

        getAppDropDown(appTitle: string): Chainable<any>;

        clickElement(element: string): Chainable<any>;

        enterText(element: string, value: string): Chainable<any>;

        findByDataCy(element: string): Chainable<any>;

    }
}
