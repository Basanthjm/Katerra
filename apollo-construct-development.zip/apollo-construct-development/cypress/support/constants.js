//Data for construct-RFI

export const SEARCH_PROJECT ='Construct UI Automation'
//export const SEARCH_PROJECT = 'apollo_cypress_DoNotUse'
export const SEARCH_UPLOAD_PROJECT = 'UI Automation-Upload files' //'apollo_cypress_01_DoNotUse'//

export const EMPTY_RFI_SEARCH = 'cypress_000000'
export const SUBJECT = 'CREATE NEW RFI'
export const RESPONSIBLE_CONTRACTOR = 'Katerra'
export const EDIT_RFI = 'EDIT RFI'
export const DREAFT_RFI = 'Apollo RFI'
export const EDI_RFI_DETAILS = 'Editing RFI details'
export const EDI_RESPONSIBLE_CONTRACTOR = 'Katerra'
export const RFI_QUESTION = 'Which location..?'
export const EDIT_QUESTION = 'Editing question'
export const REPLY_COMMENT = 'Replying to question'
export const UPLOAD_FOLDER = 'cypress docs'
export const UPLOAD_DOC = 'Cypress.pdf'
export const UPLOAD_SPEC = 'Katerra - review - material'

//Data for creating new RFI task
export const RFI_TASK_SUBJECT = 'creating new rfi task'
export const RFI_TASK_DESCRIPTION = 'Testing Rfi task'
export const RFI_DISTRIBUTION_USER = 'Katerra cypress Automation'
export const RFI_DISTRIBUTION_USER1 = 'Katerra'



//Data for editing RFI task
export const RFI_TASK_ADD_COMMENT = 'Adding comment for reference'
export const RFI_TASK_EDIT_SUBJECT = 'Roof materail review'

//Data for editing RFI task details
export const RFI_TASK_DETAILS_SUBJECT = 'Editing subject'
export const RFI_TASK_DETAILS_DESCRIPTION = 'Editing description'

//Data for construct-Observation
export const OBSERVATION_TYPE = 'cypress_testing'
//export const ASSIGN_TO = 'Katerra QA'
export const ASSIGN_TO = 'katerra cypress automation'
export const TRADE = 'Concrete'
export const PRIORITY = 'High'
export const REASON = 'Construct Quality'
export const DESCRIPTION = 'Create new observation'
export const OBSERVATION_NAME = 'cypress_Dont_DEL'
export const EDIT_ASSIGN_TO = 'katerra cypress automation'
export const EDIT_OBSERVATION_TYPE = 'Concrete'
export const EDIT_TRADE = 'Electrical'
export const EDIT_REASON = 'Construct Equipment'
export const DEL_UPLOAD_FILE_TXT = 'Are you sure you want to delete File?'
export const DEL_SPEC_TXT = 'Are you sure you want to delete Spec?'
export const ADD_D_LIST_TXT = ' Only members who are part of project will be added to Distribution List '
export const ADD_D_LIST_INFO_TXTX = 'Only Members who are a part of the Project will be added to the Distribution List.'
export const DEL_USER_TXT = 'Are you sure you want to remove this user from the Distribution List?'

//Data for collaboration-Inspection
export const TYPE = 'Health and Safety'
export const TEMPLATENAME = 'cypress-testing'

//Data for collaboration-Safety
export const SAFETY_TITTLE = 'Safety observation'
export const SAFETY_DESCRIPTION = 'Safety precutions are updated'
export const CORRECTIVE_ACTIONS_DESC = 'Corrective actions are verified'
export const SAFETY_DISTRIBUTION_GROUP = 'Katerra QA'
export const CORRECTIVE_ACTION_NAME = 'Safetymaterial'
export const CORRECTIVE_ACTION_NAME_EDIT = 'Safetybudget'

//Data for collaboration-Submittals
export const PACKAGE_NAME = 'cypress_DontDEL_Package'
export const EDIT_PACKAGE_DESC = 'editing desc'
export const ADD_SUBMITTALS_TEXT = 'Please note: If you wish to remove the submittal from the package after it is added, you can do so from the details page of the submittal. '
export const NO_SUBMITTALS_TEXT = 'No Submittals to add. '
export const SUBMITTAL_NAME = 'cypress_DontDEL_Submittal'
export const SUBMITTAL_TYPE = 'Product Data'
export const COST_IMPACT = 'No'
export const SUBMITTTAL_DESC = 'Create new submittal'
export const WORKFLOW_TASK_01 = 'Task01'
export const EDIT_TYPE = 'Design Approval'
export const WORKFLOW_TASK_02 = 'Task02'
export const TASK_DURATION = '10'
export const RESPOND_TASK_TEXT = 'Respond to Task '
export const CLOSE_SUBMITTAL_TEXT = 'Close Submittal'

//Data for collaboration-Specifications
export const REVISION_NUMBER = 'REV0012'
export const SPEC_DESC = 'process spec book through new specification issue'

//Data for collaboration-Meeting minutes
export const MEETING_ATTENDEE = 'Katerra QA4'
export const MEETING_LOCATION = 'ZOOM'
export const MEETING_OVERVIEW = 'Automation QA stand up'
export const MEETING_AGENDA = 'Work status'
export const NEW_MEETING_AGENDA = 'Collaboration Report status'
export const MEETING_AGENDA_TITTLE = 'Automation Report'
export const MEETING_AGENDA_DESC = 'Automation QA stand up'
export const EDIT_MEETING_AGENDA = 'Cypress Work status'
export const EDIT_AGENDA_TITTLE = 'FE Automation'
export const MEETING_OVERVIEW_1 = 'Collboration-Daily stand up'
export const MEETING_LOCATION_1 = 'MS Teams'

//Data for collaboration-Meeting minutes
export const project_01 = 'Construct UI Automation'
export const project_02 = 'UI Automation-Upload files'
export const TEMPLATE_TYPE = 'Health and Safety'

//Data for daily logs templates
export const SAVE_CHANGES_CNFRM_DIALOG_MSG = 'Upon saving, only the logs which will be filled henceforth can be copied. Users will not be able to copy from logs that have been created till date.\n\n The template changes will be applicable to all the associated projects. \n\n Are you sure you want to proceed?'
export const DELETE_CNFRM_MSG = 'Do you want to proceed?'
export const DEL_TEMP_CNFRM_MSG = 'Deleting this template will delete it from all its associated projects. Are you sure you want to proceed?'
export const UNSAVED_CHANGES_CNFRM_MSG = 'Unsaved changes will be lost. Are you sure you want to proceed?'

//Data for punch lists
export const PUNCHLIST_DESC = 'Hey! there its new punch list'
export const EDIT_DESC = 'Hey! there editing PL description'