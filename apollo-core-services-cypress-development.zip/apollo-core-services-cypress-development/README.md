# Apollo-Core Services Cypress

Project for e2e UI automation for Apollo

npm install

To run Cypress in UI mode
npm run cy-ui

To run Cypress in headless mode
npm run cy-run