
const user_Data = require('../support/constants ')
const acceptedUserName = user_Data.ACTIVE_USER_01
const pendingUserName = user_Data.PENDING_USER_01
const deactivatedUserName = user_Data.DEACTIVATED_USER_01
const primaryCompany = user_Data.PRIMARY_COMPANY_02
let projects = user_Data.PROJECTS
let projectName = projects[0]
let roles = user_Data.ROLES

let userName
describe('User directory', () => {
  beforeEach(() => {
    cy.server().route('GET', '/tenant/members?type=tenant&includeUsers=true').as('getUsers')
    cy.server().route('POST', '**/tenant/members**').as('postTenantMembers')
    cy.server().route('GET', '**/tenant/roles?**').as('getRoles')
    cy.server().route('GET', '/tenant/members/permissions?**').as('getTenantPermissions')
    cy.server().route('GET', '/tenant/projects?includeAll=true').as('getAllProjects')
    cy.server().route('GET', '/identity/tenants').as('getTenantsIdentity')
    cy.server().route('POST', '/tenant/projects').as('getCreatedProjects')
    cy.server().route('GET', '**/tenant/members?type=project&userId=**').as('getUserProjects')
    cy.server().route('DELETE', '**/tenant/projects/**').as('deleteTenantProjects')
    cy.server().route('DELETE', '**/tenant/members**').as('deleteTenantMembers')



      .log('Opening user page')
      .visitPage('/admin/users')
      .wait('@getTenantsIdentity').its('status').should('eq', 200)
      .url().should('include', '/admin/users')
  })

  it('Should verify users count', () => {
    cy.wait('@getUsers').then((xhr) => {
      const numberOfUsers = xhr.response.body.totalCount
      cy.findByText('User Directory (' + numberOfUsers + ')').should('exist')
    })
  })

  it('Should able to add user and check user count and status', () => {
    cy.getRandomString().then((user) => {
      cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + user).as('getSearchUser')


      cy.wait('@getUsers').then((xhr) => {
        const numberOfUsers = xhr.response.body.totalCount + 1
        addUser(user + '@gmail.com', 'tenant-admin', 'katerra')
        userName = user
        cy.findByText('User Directory (' + numberOfUsers + ')').should('exist')
        cy.log('search user')
        cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
        cy.findByPlaceholderText('Search by Name/Email')
          .clear()
          .type(user + '{enter}')
        cy.wait('@getSearchUser').then((xhr) => {
          const userState = xhr.response.body.members[0].state
          cy.log('userState' + userState)
          clickOnStateTab(userState)

        })
        cy.get('div.ag-center-cols-clipper [col-id="status"] div', { timeout: 80000 }).should('be.visible').should(
          'contain',
          'PENDING'
        )
      })
    })
  })

  it('Should verify sorting arrows of Email', () => {

    cy.server().route('GET', '**/tenant/members?sortKey=email&sort=-1&pageSize=500&type=tenant&includeUsers=true&status=ok').as('getDescendedEmails')
    cy.server().route('GET', '**/tenant/members?pageSize=500&type=tenant&includeUsers=true').as('getNonSortedEmails')
    cy.server().route('GET', '**/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&status=ok').as('getAscendedEmails')

    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    cy.contains('Email').siblings('span.ag-sort-ascending-icon').should('be.visible')
    cy.contains('Email').siblings('span.ag-sort-descending-icon').should('not.be.visible')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.contains('Email').click({ force: true })
    cy.wait('@getDescendedEmails').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    cy.contains('Email').siblings('span.ag-sort-ascending-icon').should('not.be.visible')
    cy.contains('Email').siblings('span.ag-sort-descending-icon').should('be.visible')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.contains('Email').click({ force: true })
    cy.wait('@getAscendedEmails').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    cy.contains('Email').siblings('span.ag-sort-ascending-icon').should('be.visible')
  })

  it('Should verify sorting data of Email', () => {

    cy.server().route('GET', '**/tenant/members?sortKey=email&sort=-1&pageSize=500&type=tenant&includeUsers=true&status=ok').as('getDescendedEmails')
    cy.server().route('GET', '**/tenant/members?pageSize=500&type=tenant&includeUsers=true').as('getNonSortedEmails')
    cy.server().route('GET', '**/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&status=ok').as('getAscendedEmails')

    cy.wait('@getAscendedEmails').then((xhr) => {
      const userCount = xhr.response.body.totalCount;
      const firstDisplayedEmail = xhr.response.body.members[0].user.email
      cy.log('userCount ' + userCount)
      cy.log('firstDisplayedEmail ' + firstDisplayedEmail)
      if (userCount > 4) {
        cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
        cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]').should('have.text', firstDisplayedEmail)
        cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

        cy.contains('Email').click({ force: true })
        cy.wait('@getDescendedEmails').then((xhr) => {
          const descendedEmail = xhr.response.body.members[0].user.email;
          cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
          cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]').should('have.text', descendedEmail)
          cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')


          cy.contains('Email').click()
          cy.wait('@getUsers').its('status').should('eq', 200)
          cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
          cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]').should('have.text', firstDisplayedEmail)



        })

      }

    })


  })

  it('Should verify displayed message if no assigned projects of accepted user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + acceptedUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 80000 }).should('not.be.visible')
    cy.log('search user')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear()
      .type(acceptedUserName + '{enter}')

    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')

    cy.log('clicking accepted user')
      .get('div.ag-center-cols-container [col-id="name"]', { timeout: 20000, })
      .should('be.visible')
      .click()

    cy.wait('@getUserProjects').then((xhr) => {
      const numbersOfProjects = xhr.response.body.totalCount
      //cy.findAllByRole('row').should('have.length', numbersOfProjects + 1)
      if (numbersOfProjects == 0) {
        cy.findByText('No projects assigned').should('exist')
      }
    })
  })

  it('Should able to assign new projects to accepted user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + acceptedUserName).as('getSearchUser')
    let numbersOfProjects = 0
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(acceptedUserName)
    cy.wait('@getUserProjects').then((xhr) => {
      numbersOfProjects = xhr.response.body.totalCount
      let DisplayedProject = xhr.response.body.members

      if (numbersOfProjects > 0) {

        addProject('cypress_', acceptedUserName)


      } else {
        cy.findByText('No projects assigned').should('exist')
        addProject(projects[0], acceptedUserName)
      }
    })
    cy.wait('@getUserProjects').its('status').should('eq', 200)
  })

  it('Should able to remove assigned projects of user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + acceptedUserName).as('getSearchUser')
    let numbersOfProjects = 0
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(acceptedUserName)

    cy.wait('@getUserProjects').then((xhr) => {
      numbersOfProjects = xhr.response.body.totalCount

      if (numbersOfProjects > 0) {
        removeProject()
      } else {
        cy.findByText('No projects assigned').should('exist')
        addProject(projectName, acceptedUserName)
        removeProject()
      }
    })

    cy.wait('@getUserProjects').its('status').should('eq', 200)

  })

  it('Should able to assign new projects to pending user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    let numbersOfProjects = 0
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(pendingUserName)
    cy.wait('@getUserProjects').then((xhr) => {
      numbersOfProjects = xhr.response.body.totalCount
      let DisplayedProject = xhr.response.body.members
      if (numbersOfProjects > 0) {
        for (let i = 0; i < projects.length; i++) {
          let match = false
          for (let j = 0; j < DisplayedProject.length; j++) {
            if (DisplayedProject[j].project.name == projects[i]) {
              match = true
              break
            }
          }
          if (!match) {
            addProject(projects[i], pendingUserName)
          }
        }
      } else {
        cy.findByText('No projects assigned').should('exist')
        addProject(projects[0], pendingUserName)
      }
    })

  })

  it('Should able to remove multipe assigned projects of user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + acceptedUserName).as('getSearchUser')
    let numbersOfProjects = 0
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(acceptedUserName)
    cy.wait('@getUserProjects').then((xhr) => {
      numbersOfProjects = xhr.response.body.totalCount
      let DisplayedProject = xhr.response.body.members
      if (numbersOfProjects > 0) {
        if (numbersOfProjects == 1) {
          for (let i = 0; i < projects.length; i++) {
            for (let j = 0; j < DisplayedProject.length; j++) {
              if (DisplayedProject[j].project.name != projects[i]) {
                addProject(projects[i], acceptedUserName)
                cy.wait('@getUserProjects').its('status').should('eq', 200)
                break
              }
            }
          }
        }
        removeProject(true)
      } else {
        cy.findByText('No projects assigned').should('exist')
        for (let i = 0; i < 2; i++) {
          cy.log('***numbersOfProjects*3**')
          addProject(projects[i], acceptedUserName)
          cy.wait('@getUserProjects').its('status').should('eq', 200)
        }

        removeProject(true)
      }
    })
  })
  it('Should able to remove multipe assigned projects of pending user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    let numbersOfProjects = 0
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(pendingUserName)
    cy.wait('@getUserProjects').then((xhr) => {
      numbersOfProjects = xhr.response.body.totalCount
      let DisplayedProject = xhr.response.body.members
      if (numbersOfProjects > 0) {
        if (numbersOfProjects == 1) {
          for (let i = 0; i < projects.length; i++) {
            for (let j = 0; j < DisplayedProject.length; j++) {
              if (DisplayedProject[j].project.name != projects[i]) {
                addProject(projects[i], acceptedUserName)
                cy.wait('@getUserProjects').its('status').should('eq', 200)
                break
              }
            }
          }
        }
        removeProject(true)
      } else {
        cy.findByText('No projects assigned').should('exist')
        for (let i = 0; i < 2; i++) {
          cy.log('***numbersOfProjects*3**')
          addProject(projects[i], acceptedUserName)
          cy.wait('@getUserProjects').its('status').should('eq', 200)
        }

        removeProject(true)
      }
    })
  })

  it('Should verify visibility of change roles, resend invitation ,deactivate button of pending user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.log('search user')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear()
      .type(pendingUserName + '{enter}', { delay: 10 })
    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.get('div.ag-center-cols-container [col-id="name"]', {
      timeout: 30000,
    }).should('be.visible')
    cy.get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked').then(
      (groups) => {
        groups[0].click()
      }
    )
    cy.findAllByText('Change Roles')
      .should('be.visible')
      .get('[styleclass="ui-button-danger"]')
      .should('be.visible')
      .findByDataCy('resendBtn')
      .should('be.visible')
  })

  it('Verifying edit accepted user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)

    openUserDetails(pendingUserName)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    cy.log('clicking on edit button of user')
      .get('button[label="Edit"]')
      .click()
      .log('clicking on cancel button of edit user')
      .get('[label="Cancel"]')
      .click()
      .log('clicking on edit button')
      .get('button[label="Edit"]')
      .click()
      .log('editing user details')

    cy.wait('@getRoles').its('status').should('eq', 200)

    editUser('Construct admin', 'cypress', 'cypress')
    cy.log('clicking on save button of edit user').get('[label="Save"]').click()
  })

  it('Verifying resend invitation for pending user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + userName).as('getSearchUser')
    cy.log('search user')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear({ force: true })
      .type(userName + '{enter}')

    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.get('div.ag-center-cols-container [col-id="email"]', { timeout: 60000 })
      .should('have.text', userName + '@gmail.com')

      .get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked')
      .then((groups) => {
        groups[0].click()
        cy.log('clicking on resend Invitation')
          .get('.ui-button-text-only span')
          .click()
          .wait('@postTenantMembers')
          .its('status')
          .should('eq', 200)
      })

  })

  it('Should able to change roles of user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    let role
    cy.log('search user')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 80000 }).should('not.be.visible')
    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear({ force: true })
      .type(pendingUserName + '{enter}', { delay: 10 })

    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.log('search user').then(() => {
      cy.get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked', { timeout: 80000 }).should('be.visible').then(
        (groups) => {
          groups[0].click()
        }
      )

      cy.get('div.ag-center-cols-container [col-id="roles"]')
        .invoke('text')
        .then((assignedRole) => {
          for (let i = 0; i < roles.length; i++) {
            if (roles[i] != assignedRole) {
              role = roles[i]
              cy.findAllByText('Change Roles').should('be.visible').click()
              cy.contains(role).siblings('div.ui-radiobutton').click()
              cy.findByRole('button', { name: 'Apply' }).should('exist').click()
              cy.get('div.ag-center-cols-container [col-id="roles"]').should(
                'have.text',
                role
              )
              break
            }
          }
        })
    })
  })

  it('Should able to de-activate pending user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + userName).as('getSearchUser')
    cy.log('search user')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 80000 }).should('not.be.visible')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear({ force: true })
      .type(userName + '{enter}')
    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
      .get('div.ag-center-cols-container [col-id="email"]', { timeout: 80000 }).should('be.visible')
      .should('have.text', userName + '@gmail.com')
      .get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked')
      .then((groups) => {
        groups[0].click()
        cy.log('clicking on delete button')
          .findByText('Deactivate User')
          .click()
          .get('.ui-confirmdialog-acceptbutton')
          .click()
          .wait('@deleteTenantMembers')
          .its('status')
          .should('eq', 200)
      })

  })

  it('Should verify visibility of change roles, resend invitation ,deactivate button of deleted user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + deactivatedUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.log('search user')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear({ force: true })
      .clear()
      .type(deactivatedUserName + '{enter}', { delay: 10 })

    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.get('div.ag-center-cols-container [col-id="name"]', {
      timeout: 30000,
    }).should('be.visible')
    cy.get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked').then(
      (groups) => {
        groups[0].click()
      }
    )
    cy.findByDataCy('resendBtn')
      .should('be.visible')

  })

  it('Should verify visibility of change roles and deactivate button of accepted user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + acceptedUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.log('search user')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
    cy.findByPlaceholderText('Search by Name/Email')
      .clear({ force: true })
      .clear()
      .type(acceptedUserName + '{enter}', { delay: 10 })

    cy.wait('@getSearchUser').then((xhr) => {
      const userState = xhr.response.body.members[0].state
      cy.log('userState' + userState)
      clickOnStateTab(userState)

    })
    cy.get('div.ag-center-cols-container [col-id="name"]', {
      timeout: 30000,
    }).should('be.visible')
    cy.get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked').then(
      (groups) => {
        groups[0].click()
      }
    )
    cy.findAllByText('Change Roles')
      .should('be.visible')
      .get('[styleclass="ui-button-danger"]')
      .should('be.visible')
  })

  it('Should verify no result found message when add same company in primary and additional company', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    cy.server().route('GET', '/cmb/companies/suggestion/_list?q=' + primaryCompany + '&active=true').as('getSearchCompany')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    openUserDetails(pendingUserName)
    cy.log('clicking on edit button of user')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.findByDataCy('editUserInformation')
      .click()
      .wait(3000)
    cy.get('[placeholder="Search Company"] span>input')
      .clear()
      .type(primaryCompany, { delay: 10 })
    cy.wait('@getSearchCompany').its('status').should('eq', 200)
      .get('[placeholder="Search Company"] li.ui-autocomplete-list-item')
      .first()
      .click()
      .get('[multiple="true"][placeholder="Search Company"] input')
      .clear()
      .type(primaryCompany)
      .get('.ui-autocomplete-emptymessage').should('contain', 'No Results Found!')
  })

  it('Should able to add multiple projects to user', () => {
    cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + pendingUserName).as('getSearchUser')
    cy.wait('@getUsers').its('status').should('eq', 200)

    openUserDetails(pendingUserName)
    cy.wait('@getUserProjects').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
    cy.findByRole('button', { name: 'Add New' }).click()
    cy.get('.loading > .fa', { timeout: 60000 }).should('not.be.visible')
    cy.wait('@getRoles').its('status').should('eq', 200)

      .findByDataCy('assigProject')
      .click()
      .findByRole('textbox')
      .clear()
      .type('cypress')
      .get('li[style="display: block;"] .ui-clickable')
      .then((projects) => {
        projects[0].click()
        projects[1].click()
      })
      .findByDataCy('assigProject')
      .click()
      .get('[placeholder="Select Role"]')
      .click()
      .get('input.ui-dropdown-filter')
      .clear()
      .type('project admin')

      .get('[role="option"] span')
      .then((role) => {
        role[0].click()
      })

    cy.findByText('Save').parent('button').should('not.be.disabled').click()
  })

})
const enterUserDetails = function (mailID, role, company) {
  cy.log('enter details of user')
  cy.wait('@getRoles').its('status').should('eq', 200)
  cy.wait(1000)

  cy.get('span.ui-button-icon-left', { timeout: 85000 }).should('be.visible').click()

  cy.get('[role="option"]').then((role) => {
    role[0].click()
  })
  cy.findAllByPlaceholderText('Search Primary Company')
    .last()
    .clear({ force: true })
    .type(company)
  cy.get('[role="option"] span').then((role) => {
    role[0].click()
  })

  cy.findAllByPlaceholderText('Email Addresses')
    .last()
    .clear()
    .type(mailID + '{enter}')
}
const addUser = function (mailID, role, company) {
  cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible').then(() => {
    cy.get('button.addButton', { timeout: 85000 }).should('be.enabled').click()
    //cy.findByDataCy('addNewUser', { timeout: 85000 }).should('be.enabled').click()
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    enterUserDetails(mailID, role, company)
  })
  cy.get('[label="Send Invite"]')
    .should('not.be.disabled')
    .click()
    .wait('@postTenantMembers')
    .its('status')
    .should('eq', 200)
}
const editUser = function (role, primaryCompany, additionalCompany) {
  cy.wait(1000)
  cy.get('button.ui-autocomplete-dropdown')
    .click()

    .get('[role="option"]')
    .then((role) => {
      role[0].click()
    })

  cy.get('[placeholder="Search Company"] span>input')
    .clear()
    .type(primaryCompany)
    .get('[placeholder="Search Company"] li.ui-autocomplete-list-item', { timeout: 85000 }).should('be.visible')
    .first()
    .click()
    .get('[placeholder="Search Company"] span.ui-autocomplete-multiple', {
      delay: 10,
    })
    .then((additionalCompanies) => {
      if (additionalCompanies.length > 0) {
        for (let i = 0; i < additionalCompanies.length; i++) {
          additionalCompanies[i].click()
        }
      }
    })
    .get('[multiple="true"][placeholder="Search Company"] input')
    .clear()
    .type(additionalCompany)
    .get('[role="option"] span')
    .then((role) => {
      role[0].click()
    })
}
const createProject = function (projectName) {
  cy.visitPage('/directory')

  cy.wait('@getTenantPermissions').its('status').should('eq', 200)
  cy.wait('@getAllProjects').its('status').should('eq', 200)
  //cy.wait('@getUsers').its('status').should('eq', 200)

  cy.clickElement('addNewProject')
    .log('checking save button visibilty')
    .findByDataCy('addProjBtn').should('be.disabled')
    .log('Creating a new project')
    .enterText('projectName', projectName)
  cy.enterText('location', 'Bengaluru, Karnataka, India')
    .get('[role="option"] span')
    .then(role => {
      role[0].click()
    })
  cy.enterText('description', user_Data.ADD_DESCRIPTION)
    .findByDataCy('addProjBtn').click()
    .wait('@getCreatedProjects').its('status').should('be', 200)
    .get('.ui-toast-detail')
    .should('contain.text', 'Project successfully added')

    .log('Opening user page')
    .visitPage('/admin/users')
  cy.wait('@getTenantsIdentity')
    .its('status')
    .should('eq', 200)
    .url()
    .should('include', '/admin/users')
  // cy.wait('@getUsers').its('status').should('eq', 200)
}
const openUserDetails = function (username) {
  cy.log('search user')
  cy.get('.ag-center-cols-container .ag-row-first [col-id="email"]', { timeout: 85000 }).should('be.visible')
  cy.findByPlaceholderText('Search by Name/Email')
    .should('be.visible')
    .clear()
    .type(username + '{enter}', { delay: 10 })
  cy.wait('@getSearchUser').then((xhr) => {
    const userState = xhr.response.body.members[0].state
    cy.log('userState' + userState)
    clickOnStateTab(userState)

  })

  cy.log('clicking accepted user')
    .get('div.ag-center-cols-container [col-id="name"]', {
      timeout: 60000,
    })
    .should('be.visible')
    .click()
}
const removeProject = function (isRemoveMultipleProjects) {
  cy.get('.loading > .fa').should('not.be.visible', { timeout: 2000 })
  cy.get('div.ag-center-cols-viewport').then((element) => {
    cy.get(
      element.find(' span.ag-selection-checkbox  .ag-icon-checkbox-unchecked')
    ).then((elements) => {
      elements[0].click()
      if (isRemoveMultipleProjects) {
        elements[1].click()
      }
    })
    cy.findByText('Remove Project(s)')
      .click()
      .log('verifying remove user group dialog box visible')
      .get('div.ui-confirmdialog')
      .should('be.visible')
      .log('clicking on yes button on remove project dialog')
      .get('.ui-confirmdialog-acceptbutton')
      .click()

      .wait('@deleteTenantProjects')
      .its('status')
      .should('be', 200)
  })
}
const addProject = function (projectName, userName) {
  cy.findByRole('button', { name: 'Add New' }).click()
  cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
  cy.wait('@getRoles').its('status').should('eq', 200)
  cy.findByText('Save')
    .parent('button')
    .should('be.disabled')

    .findByDataCy('assigProject')
    .click()
    .findByRole('textbox')
    .clear()
    .type(projectName)

  cy.get('ul[role="listbox"]')
    .then((element) => {
      if (element.find('.ui-multiselect-empty-message').length > 0) {
        cy.get('.ui-dialog-titlebar-close').click()
        createProject(projectName)
        openUserDetails(userName)
        cy.findByRole('button', { name: 'Add New' }).click()
        cy.get('.loading > .fa').should('not.be.visible', { timeout: 2000 })
        cy.wait('@getRoles').its('status').should('eq', 200)
        cy.findByText('Save')
          .parent('button')
          .should('be.disabled')

          .findByDataCy('assigProject')
          .click()
          .findByRole('textbox')
          .clear()
          .type(projectName)
      }
      cy.get('li[style="display: block;"] .ui-clickable')
        .then((projects) => {
          projects[0].click()

        })
      cy.findByDataCy('assigProject')
        .click()
    })
    .get('[placeholder="Select Role"]')
    .click()
    .get('input.ui-dropdown-filter')
    .clear()
    .type('project admin')

    .get('[role="option"] span')
    .then((role) => {
      role[0].click()
    })

  cy.findByText('Save').parent('button').should('not.be.disabled').click()
}
const clickOnStateTab = function (state) {

  if (state == 'inactive') {
    cy.clickElement('inactive')

  } else if (state == 'pending') {
    cy.clickElement('pending')

  }
}
