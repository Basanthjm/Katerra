const DG_Data = require('../support/constants ')
let groupName = DG_Data.D_GROUP_NAME
const groupDesc = DG_Data.D_GROUP_DESC
const user = DG_Data.ACTIVE_USER_01
const pendingUser = DG_Data.PENDING_USER_01
const deactivateUser = DG_Data.DEACTIVATED_USER_01
const primaryCompany = DG_Data.PRIMARY_COMPANY
describe('Distribution groups', () => {
  beforeEach(() => {
    cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
    cy.server()
      .route('GET', '/tenant/members/permissions?**')
      .as('getTenantPermissions')
    cy.server().route('GET', '/tenant/groups').as('getAllDistributionGroups')
    cy.server().route('GET', '/identity/users').as('getUsers')
    cy.server().route('POST', '/tenant/groups').as('postTenantGroups')

    cy.log('Open distribution group page')
  })

  it('Should verify distribution group count', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')

    cy.getRandomString().then((randomString) => {
      cy.wait('@getAllDistributionGroups').then((xhr) => {
        const dGroupCount = xhr.response.body.userGroups.length
        cy.get('.ap-bread-active').should(
          'have.text',
          'Distribution Groups (' + dGroupCount + ')'
        )
      })
    })
  })
  it('Should verify sorting arrows of Distribution group', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.get('.ag-sort-ascending-icon').should('be.visible')
    cy.get('.ag-sort-descending-icon').should('not.be.visible')
    cy.get('.ag-sort-ascending-icon').click()

    cy.get('.ag-sort-ascending-icon').should('not.be.visible')
    cy.get('.ag-sort-descending-icon').should('be.visible')
    cy.get('.ag-sort-descending-icon').click()

    cy.get('.ag-sort-ascending-icon').should('be.visible')
  })
  it('Should verify sorting data of Distribution group', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').then((xhr) => {
      const dGroupCount = xhr.response.body.userGroups.length
      if (dGroupCount > 4) {


        cy.get('.ag-center-cols-container .ag-row-first [col-id="group"]').invoke('text').then((AscendedGroup) => {
          cy.log('AscendedGroup ' + AscendedGroup)
          cy.get('.ag-sort-ascending-icon').click()
          cy.get('.ag-center-cols-container .ag-row-first [col-id="group"]').invoke('text').then((descendedGroup) => {
            cy.log('descendedGroup ' + descendedGroup)
            assert.notEqual(descendedGroup, AscendedGroup)
            cy.get('.ag-sort-descending-icon').click()
            cy.get('.ag-center-cols-container .ag-row-first [col-id="group"]').invoke('text').then((secondAscendedGroup) => {
              assert.notEqual(secondAscendedGroup, descendedGroup)

            })


          })


        })
      }
    })

  })

  it('Should verify grey background of pending while add new distribution group', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)
    cy.findByDataCy('addNewBtn')
      .click()
      .findByDataCy('multiUsers')
      .click()
      .get('div.ui-multiselect-filter-container input')
      .clear()
      .type(pendingUser)
    cy.get('li.ui-multiselect-item[style="display: block;"] div')
      .contains(pendingUser + '@gmail.com')
      .should('have.attr', 'class', 'greyBg ng-star-inserted')
  })

  it('Should verify no result found when searching deactivated user while add', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)
    cy.findByDataCy('addNewBtn')
      .click()
      .findByDataCy('multiUsers')
      .click()
      .get('div.ui-multiselect-filter-container input')
      .clear()
      .type(deactivateUser)
      .get('.ui-multiselect-empty-message')
      .should('have.text', 'No results found')
  })

  it('Should verify add new distribution group', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')

    cy.getRandomString().then((randomString) => {
      cy.wait('@getAllDistributionGroups').then((xhr) => {
        const groupsList = xhr.response.body.userGroups
        let isExists = false
        for (let i = 0; i < groupsList.length; i++) {
          if (groupName == groupsList[i].name) {
            isExists = true
          }
        }
        if (isExists) {
          groupName = randomString + '_Group'
        }

        addDistributionGroup(groupName, groupDesc, user)
      })
    })
  })

  it('Should search specific distribution group', () => {
    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.log('enter distribution group name for searching')
    cy.findByDataCy('searchGroupField')
      .type(groupName + '{enter}')
      .get('.ag-center-cols-container')
      .then((element) => {
        if (element.find('[col-id="group"]').length > 0) {
          cy.log('validating searched group name')
            .get('.ag-center-cols-container [col-id="group"]')
            .should('have.text', groupName)
        } else {
          addDistributionGroup(groupName, groupDesc, user)
          cy.log('Validating added Distribution group name')
          cy.findByDataCy('searchGroupField')
            .clear()
            .type(groupName + '{enter}')
            .get('.ag-center-cols-container [col-id="group"]')
            .should('have.text', groupName)
        }
      })
  })

  it('Should verify grey background of pending while edit distribution group', () => {
    cy.server().route('PUT', '/tenant/groups/**').as('putTenantGroups')
    cy.server().route('GET', '/identity/users/**').as('getIdentityUsers')

    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.log('search distribution group for editing')

    cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
    cy.get('div.ag-center-cols-container').then((element) => {
      if (element.find('[role="row"]').length > 0) {
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      } else {
        addDistributionGroup(groupName, groupDesc, user)
        cy.findByDataCy('searchGroupField')
          .clear()
          .type(groupName + '{enter}')
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      }
    })
    cy.get('span.ui-multiselect-trigger-icon')
      .click()
    cy.get('div.ui-multiselect-filter-container input')
      .clear({ force: true })
      .type(pendingUser)
    cy.get('li.ui-multiselect-item[style="display: block;"] div')
      .contains(pendingUser + '@gmail.com')
      .should('have.attr', 'class', 'greyBg ng-star-inserted')
  })

  it('Should verify no result found when searching deactivated user while edit', () => {
    cy.server().route('PUT', '/tenant/groups/**').as('putTenantGroups')
    cy.server().route('GET', '/identity/users/**').as('getIdentityUsers')

    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.log('search distribution group for editing')

    cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
    cy.get('div.ag-center-cols-container').then((element) => {
      if (element.find('[role="row"]').length > 0) {
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      } else {
        addDistributionGroup(groupName, groupDesc, user)
        cy.findByDataCy('searchGroupField')
          .clear()
          .type(groupName + '{enter}')
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      }
    })
    cy.get('span.ui-multiselect-trigger-icon')
      .click()
      .get('div.ui-multiselect-filter-container input')
      .clear()
      .type(deactivateUser)
      .get('.ui-multiselect-empty-message')
      .should('have.text', 'No results found')
  })

  it('should able to edit distribution group', () => {
    cy.server().route('PUT', '/tenant/groups/**').as('putTenantGroups')
    cy.server().route('GET', '/identity/users/**').as('getIdentityUsers')

    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.log('search distribution group for editing')

    cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
    cy.get('div.ag-center-cols-container').then((element) => {
      if (element.find('[role="row"]').length > 0) {
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      } else {
        addDistributionGroup(groupName, groupDesc, user)
        cy.findByDataCy('searchGroupField')
          .clear()
          .type(groupName + '{enter}')
        cy.get('div.ag-center-cols-container [role="row"]').first().click()
      }
    })
    editDistributionGroup(groupDesc + ' edit', pendingUser)
  })

  it('Should validate user list of distribution group', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')

    cy.wait('@getAllDistributionGroups').then((xhr) => {
      const groupsList = xhr.response.body.userGroups
      cy.log('user list in distribution group ' + groupsList[0].users.length)
      cy.findByDataCy('searchGroupField').type(groupsList[0].name + '{enter}')
      cy.get('app-display-user-list span')
        .first()
        .should('have.text', groupsList[0].users.length)
      cy.get('i.pi-ellipsis-h').first().click()
      cy.get('.ui-table-tbody tr').should(
        'have.length',
        groupsList[0].users.length
      )
    })
  })

  it('Should verify already distribution group name exist message', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').then((xhr) => {
      const groupName = xhr.response.body.userGroups[0].name
      cy.findByDataCy('addNewBtn').click()
      cy.findByDataCy('groupNameInputEdit').clear().type(groupName)
      cy.get('div.message-container').should(
        'have.text',
        'Distribution Group Name exists.'
      )
    })
  })

  it('Should verify no result found message while searching non existing D-group', () => {
    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)
    cy.getRandomString().then((randomString) => {
      cy.log('enter distribution group name for searching')
      cy.findByDataCy('searchGroupField').type(randomString + '{enter}')
      cy.get('div.no-row').should('have.text', 'No Results Found')
    })
  })

  it('Should display distribution group name exist message while editing', () => {
    cy.visitPage('/admin/distribution-group')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').then((xhr) => {
      const existGroupName = xhr.response.body.userGroups[0].name
      cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
      cy.get('div.ag-center-cols-container').then((element) => {
        if (element.find('[role="row"]').length > 0) {
          cy.get('div.ag-center-cols-container [role="row"]').first().click()
        } else {
          addDistributionGroup(groupName, groupDesc, user)
          cy.findByDataCy('searchGroupField')
            .clear()
            .type(groupName + '{enter}')
          cy.get('div.ag-center-cols-container [role="row"]').first().click()
        }
      })
      cy.wait(500)
      cy.findByDataCy('groupNameInputEdit')
        .clear({ force: true })
        .type(existGroupName)
      cy.get('div.message-container').should(
        'have.text',
        'Distribution Group Name exists.'
      )
    })
  })

  it('Should verify color change of pending in user list', () => {
    cy.visitPage('/admin/distribution-group')
    cy.server().route('PUT', '/tenant/groups/**').as('putTenantGroups')
    cy.server().route('GET', '/identity/users/**').as('getIdentityUsers')
    cy.server()
      .route('DELETE', '/tenant/groups/*')
      .as('deleteDistributionGroup')

    cy.log('Validating url updated with distribution group')
      .url()
      .should('include', '/admin/distribution-group')
    cy.getRandomString().then((groupName) => {
      cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

      addDistributionGroup(groupName, groupDesc, user)
      cy.findByDataCy('searchGroupField')
        .clear()
        .type(groupName + '{enter}')
      cy.get('div.ag-center-cols-container [role="row"]')
        .first()
        .click()
        .get('span.ui-multiselect-trigger-icon')
        .click()
        .get('div.ui-multiselect-filter-container input')
        .clear()
        .type(pendingUser)
        .get('li.ui-multiselect-item[style="display: block;"]')
        .then((pendingUser) => {
          pendingUser[0].click()
        })
        .get('a.ui-multiselect-close')
        .click()

      cy.findByDataCy('submitDialogBtn').click()
      cy.wait('@putTenantGroups').its('status').should('eq', 200)

      cy.findByDataCy('searchGroupField').clear().type(groupName)
      cy.get('i.pi-ellipsis-h').first().click()
      cy.get('.ui-table-tbody tr')
        .contains(pendingUser + '@gmail.com')
        .should('have.attr', 'class', 'halfOpacity')
        .get('.ui-overlaypanel-close-icon')
        .click()
      cy.log('clicking on delete button')
        .get("[alt='Delete']")
        .first()
        .click({ force: true })
        .log('verifying remove user group dialog box visible')
        .get('div.ui-confirmdialog')
        .should('be.visible')
        .log('clicking on yes button on remove user group dialog')
        .get('.ui-confirmdialog-acceptbutton')
        .click()
        .wait('@deleteDistributionGroup')
        .its('status')
        .should('eq', 200)
    })
  })

  it('Should able to delete distribution group and search delete user', () => {
    cy.server()
      .route('DELETE', '/tenant/groups/*')
      .as('deleteDistributionGroup')

    cy.visitPage('/admin/distribution-group')
    cy.wait('@getAllDistributionGroups').its('status').should('eq', 200)

    cy.log('search distribution group for deleting')

    cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
    cy.get('div.ag-center-cols-container').then((element) => {
      if (element.find('[role="row"]').length == 0) {
        addDistributionGroup(groupName, groupDesc, user)
        cy.findByDataCy('searchGroupField')
          .clear()
          .type(groupName + '{enter}')
      }
    })
    cy.log('clicking on delete button')
      .get("[alt='Delete']")
      .first()
      .click({ force: true })
      .log('verifying remove user group dialog box visible')
      .get('div.ui-confirmdialog')
      .should('be.visible')
      .log('clicking on yes button on remove user group dialog')
      .get('.ui-confirmdialog-acceptbutton')
      .click()
      .wait('@deleteDistributionGroup')
      .its('status')
      .should('eq', 200)
    cy.log('Search deleted user')
    cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
    cy.get('div.no-row').should('have.text', 'No Results Found')
  })

  it('Should validate count of user when deactivated pending user', () => {
    cy.visitPage('/admin/users')
    cy.server().route('GET', '/tenant/members?type=tenant&includeUsers=true').as('getUsers')
    cy.server().route('GET', '**/tenant/roles?**').as('getRoles')
    cy.server().route('POST', '**/tenant/members**').as('postTenantMembers')
    cy.server().route('DELETE', '**/tenant/members**').as('deleteTenantMembers')
    cy.server().route('DELETE', '/tenant/groups/*').as('deleteDistributionGroup')
    cy.server().route('GET', '**/cmb/companies?company_ids**').as('getCompanies')

    cy.log('Validating url updated with user directory page')
      .url()
      .should('include', '/admin/users')
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
    cy.wait('@getUsers').its('status').should('eq', 200)
    cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')

    cy.getRandomString().then((randomUser) => {
      let userName = randomUser + '@gmail.com'
      cy.log('click add new member')
      cy.findByDataCy('addNewUser', { timeout: 85000 }).should('be.enabled').click()
      cy.get('.loading > .fa', { timeout: 85000 }).should('not.be.visible')
        .log('enter details of user')
        .wait('@getRoles')
        .its('status').should('eq', 200)
        .wait(1000)
        .get('span.ui-button-icon-left')
        .click()
        .get('[role="option"]')
        .then((role) => {
          role[0].click()
        })
      cy.findAllByPlaceholderText('Search Primary Company')
        .last()
        .clear({ force: true })
        .type(primaryCompany)
        .get('[role="option"] span')
        .then((role) => {
          role[0].click()
        })
      cy.findAllByPlaceholderText('Email Addresses')
        .last()
        .clear()
        .type(userName + '{enter}')
        .findByDataCy('inviteBtn')
        .should('not.be.disabled')
        .click()
        .wait(2000)
      cy.wait('@postTenantMembers').its('status').should('eq', 200)
      cy.wait('@getUsers').its('status').should('eq', 200)
      cy.visitPage('/admin/distribution-group')
      cy.log('Validating url updated with distribution group')
        .url()
        .should('include', '/admin/distribution-group')

      cy.getRandomString().then((randomString) => {
        cy.wait('@getAllDistributionGroups').then((xhr) => {
          const groupsList = xhr.response.body.userGroups
          let isExists = false
          for (let i = 0; i < groupsList.length; i++) {
            if (groupName == groupsList[i].name) {
              isExists = true
            }
          }
          if (isExists) {
            groupName = randomString + '_Group'
          }

          addDistributionGroup(groupName, groupDesc, userName)

          cy.findByDataCy('searchGroupField').type(groupName + '{enter}')
          cy.get('app-display-user-list span')
            .first()
            .invoke('text')
            .then((usersCount) => {
              cy.visitPage('/admin/users')
              cy.log('Validating url updated with user directory page')
                .url()
                .should('include', '/admin/users')
              cy.wait('@getUsers').its('status').should('eq', 200)
              cy.server().route('GET', '/tenant/members?sortKey=email&sort=1&pageSize=500&type=tenant&includeUsers=true&search=' + randomUser).as('getSearchUser')
              cy.findByPlaceholderText('Search by Name/Email')
                .clear()
                .type(randomUser + '{enter}')

              cy.wait('@getSearchUser').then((xhr) => {
                const userState = xhr.response.body.members[0].state
                cy.log('userState' + userState)
                clickOnStateTab(userState)

              })
              cy.get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked', {
                timeout: 20000,
              })
                .should('be.visible')
                .get('.ag-center-cols-clipper .ag-icon-checkbox-unchecked')
                .then((users) => {
                  users[0].click()
                  cy.log('clicking on delete button')
                    .findByText('Deactivate User')
                    .click()
                    .get('.ui-confirmdialog-acceptbutton')
                    .click()
                    .wait('@deleteTenantMembers')
                    .its('status')
                    .should('eq', 200)

                  cy.visitPage('/admin/distribution-group')
                  cy.log('Validating url updated with distribution group')
                    .url()
                    .should('include', '/admin/distribution-group')
                  cy.findByDataCy('searchGroupField').type(
                    groupName + '{enter}'
                  )
                  cy.get('app-display-user-list span')
                    .first()
                    .should('have.text', usersCount - 1)
                  cy.log('clicking on delete button')
                    .get("[alt='Delete']")
                    .first()
                    .click({ force: true })
                    .log('verifying remove user group dialog box visible')
                    .get('div.ui-confirmdialog')
                    .should('be.visible')
                    .log('clicking on yes button on remove user group dialog')
                    .get('.ui-confirmdialog-acceptbutton')
                    .click()
                    .wait('@deleteDistributionGroup')
                    .its('status')
                    .should('eq', 200)
                })
            })
        })
      })
    })
  })

})
const enterDistributionGroupDetails = function (DgName, desc, user) {
  cy.log('enter details for distribution group')
    .findByDataCy('groupNameInputEdit')
    .clear()
    .type(DgName)
    .findByDataCy('multiUsers')
    .click()
    .get('div.ui-multiselect-filter-container input')
    .clear()
    .type(user)
    .get('li.ui-multiselect-item[style="display: block;"]')
    .then((users) => {
      users[0].click()
    })
    .get('a.ui-multiselect-close')
    .click()
    .findByDataCy('descInput')
    .clear()
    .type(desc)
    .findByDataCy('submitDialogBtn')
    .click()

  cy.wait('@postTenantGroups').its('status').should('eq', 200)
}

const addDistributionGroup = function (DgName, desc, user) {
  cy.findByDataCy('addNewBtn').click()
  enterDistributionGroupDetails(DgName, desc, user)
}

const editDistributionGroup = function (desc, user) {
  cy.log('clicking on edit button')
  cy.wait('@getIdentityUsers').its('status').should('eq', 200)

  cy.log('enter details for distribution group')
    .findByDataCy('descInput')
    .clear()
    .type(desc)
    .get('span.ui-multiselect-trigger-icon')
    .click()
    .get('div.ui-multiselect-filter-container input')
    .clear()
    .type(user)
    .get('li.ui-multiselect-item[style="display: block;"]')
    .then((users) => {
      users[0].click()
    })
    .get('a.ui-multiselect-close')
    .click()

  cy.findByDataCy('submitDialogBtn').click()
  cy.wait('@putTenantGroups').its('status').should('eq', 200)
}
const clickOnStateTab = function (state) {

  if (state == 'inactive') {
    cy.clickElement('inactive')

  } else if (state == 'pending') {
    cy.clickElement('pending')

  }
}
