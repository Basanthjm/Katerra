//load the project directory page with no projects

describe('Mocked Project Directory', () => {

    it('Should load a blank page with Add New Button', () => {
        cy.server()
        cy.route({
            method: 'GET',
            url: '/tenant/projects?**',
            status: 200,
            response: {
                paging: {},
                projects: []
            }
        }).as('getProjects')
        cy.visitPage('/directory')
            .wait('@getProjects').its('status').should('eq', 200)
            // .get('.newBtn')
            // .findByDataCy('')
            // .click({ force: true })
            .clickElement('addNewProject')
            .log("checking save button visibilty")
            .findByDataCy('addProjBtn')
            .should('be.disabled')
            cy.get('.ui-dialog-titlebar-icon > .ng-tns-c73-3')
            .click({ force: true }) 
    });

    it('Should load a projects page with my mock project list', () => {
        cy.server()
        cy.route({
            method: 'GET',
            url: '/tenant/projects?sortKey=name&sort=1&pageSize=15&*',
            status: 200,
            response: 'fixture:/mockedProjectDirectory.json'
        }).as('getAllProjects')
        cy.route({
            method: 'GET',
            url: '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&active=true&includeAll=true',
            status: 200,
            response: 'fixture:/mockedProjectDirectory.json'
        }).as('getFirst15Projects')

        cy.visitPage('/directory')
            .wait('@getFirst15Projects').its('status').should('eq', 200)
            // .get('.newBtn')
            // .click({ force: true })
            .clickElement('addNewProject')
            .log("checking save button visibilty")
            .findByDataCy('addProjBtn')
            .should('be.disabled')
            cy.get('.ui-dialog-titlebar-icon > .ng-tns-c73-3')
            .click({ force: true }) 

    });

});