const configConstants = require('../support/constants ')

describe('Configurations', () => {
    let newProjectName = ''

    before(() => {

        visitConfiguration()
    })

    beforeEach(() => {
        cy.server().route('GET', '/cmf/config-prod.json').as('loadConfigJson')
        cy.server().route('PATCH', '/cmb/V1/configurations/project').as('updateConfProjects')
    })

    it('should search for Non-Exist project configuration and validate Error message', () => {

        cy.enterText('Project Type-input', configConstants.SEARCH_NON_EXIST)
            .get('.section-center')
            .should('contain.text', ' No results found')
            .findByDataCy('Project Type-input').clear()

    });

    it('Should Add,Search,Edit and delete Project configuration', () => {

        cy.getRandomString().then(projectName => {

            cy.log('verifying configuration page')
                .get('.ap-bread-active').contains('Configurations')
                .clickElement('Project Type-add')

            cy.log('Adding new project configuration')
            cy.findByPlaceholderText('Field name')
                .type(projectName)
                .clickElement('Project Type-save')
                .wait('@updateConfProjects').its('status').should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value(s) added')
            newProjectName = projectName

            cy.log('Adding Existing project configuration and validating Error message')
                .clickElement('Project Type-add')
            cy.findByPlaceholderText('Field name')
                .type(newProjectName)
                .clickElement('Project Type-save')
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration values should be unique, please remove duplicate value(s)')
                .reload()

            cy.log('Searching configuration')
            cy.enterText('Project Type-input', projectName)
                .get('.d-inline-flex')
                .should('contain.text', projectName)

            cy.log('Editing configuration')
                .get('.d-inline-flex')
                .contains(projectName).trigger('mouseover')
                .findByDataCy(projectName + '-edit')
                .click({ force: true })
                .findByDataCy(projectName + '-input')
                .clear()
            cy.findByPlaceholderText('Field name')
                .type('Non' + projectName)
                .findByDataCy('Non' + projectName + '-save')
                .click({ force: true })
                .wait('@updateConfProjects').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value updated')

            cy.log('Deleting configuration')
            cy.findByDataCy('Project Type-input')
                .clear()
            cy.enterText('Project Type-input', 'Non' + projectName)
                .get('.d-inline-flex')
                .contains('Non' + projectName).trigger('mouseover')
                .findByDataCy('Non' + projectName + '-delete')
                .click({ force: true })
                .get('.ui-confirmdialog-acceptbutton')
                .click()
                .wait('@updateConfProjects').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value deleted')

        })
    })

    it('Should Add,Search,Edit and delete Project Stage configuration', () => {

        cy.getRandomString().then(projectName => {
            cy.getRandomKey().then(key => {
                cy.log('verifying configuration page')
                    .get('.ap-bread-active').contains('Configurations')
                    .clickElement('Project Stage-add')

                cy.log('Adding new project Stage configuration')
                cy.findByPlaceholderText('Field name')
                    .type(projectName)
                cy.findByPlaceholderText('Key')
                    .type(key)
                    .clickElement('Project Stage-save')
                    .wait('@updateConfProjects').its('status')
                    .should('eq', 200)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Configuration value(s) added')

                cy.log('Search project Stage configuration')
                cy.enterText('Project Stage-input', projectName)
                    .get('.d-inline-flex')
                    .should('contain.text', projectName)

                cy.log('Edit project stage configuration')
                    .get('.d-inline-flex')
                    .contains(projectName).trigger('mouseover')
                    .findByDataCy(projectName + '-edit')
                    .click({ force: true })
                cy.findByPlaceholderText('Field name')
                    .clear()
                cy.findByPlaceholderText('Field name')
                    .type('Non' + projectName)
                    .findByDataCy('Non' + projectName + '-save')
                    .click({ force: true })
                    .wait('@updateConfProjects').its('status')
                    .should('eq', 200)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Configuration value updated')

                cy.log('Delete project stage configuration')
                cy.findByDataCy('Project Stage-input')
                    .clear()
                cy.enterText('Project Stage-input', 'Non' + projectName)
                    .get('.d-inline-flex')
                    .contains('Non' + projectName).trigger('mouseover')
                    .findByDataCy('Non' + projectName + '-delete')
                    .click({ force: true })
                    .get('.ui-confirmdialog-acceptbutton')
                    .click()
                    .wait('@updateConfProjects').its('status')
                    .should('eq', 200)
                    .get('.ui-toast-detail')
                    .should('contain.text', 'Configuration value deleted')
            })
        })
    })

    it('Should Add,Search,Edit and delete Department configuration', () => {

        cy.server().route('PATCH', '/cmb/V1/configurations/project').as('updateDepConf')

        cy.getRandomString().then(projectName => {

            cy.log('verifying configuration page')
                .get('.ap-bread-active').contains('Configurations')
                .clickElement('Department-add')

            cy.log('Adding new project Stage configuration')
            cy.findByPlaceholderText('Field name')
                .type(projectName)
                .clickElement('Department-save')
                .wait('@updateDepConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value(s) added')

            cy.log('Search Department configuration')
            cy.enterText('Department-input', projectName)
                .get('.d-inline-flex')
                .should('contain.text', projectName)

            cy.log('Edit Department configuration')
                .get('.d-inline-flex')
                .contains(projectName).trigger('mouseover')
                .findByDataCy(projectName + '-edit')
                .click({ force: true })
            cy.findByPlaceholderText('Field name')
                .clear()
            cy.findByPlaceholderText('Field name')
                .type('Non' + projectName)
                .findByDataCy('Non' + projectName + '-save')
                .click({ force: true })
                .wait('@updateDepConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value updated')

            cy.log('Delete Department configuration')
            cy.findByDataCy('Department-input')
                .clear()
            cy.enterText('Department-input', 'Non' + projectName)
                .get('.d-inline-flex')
                .contains('Non' + projectName).trigger('mouseover')
                .findByDataCy('Non' + projectName + '-delete')
                .click({ force: true })
                .get('.ui-confirmdialog-acceptbutton')
                .click()
                .wait('@updateDepConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value deleted')
        })

    })

    it('Should Add,Search,Edit and delete Workflow Task Type configuration', () => {

        cy.server().route('PATCH', '/cmb/V1/configurations/workflow').as('updateWorkflowConf')

        cy.getRandomString().then(projectName => {

            cy.log('verifying configuration page')
                .get('.ap-bread-active').contains('Configurations')
                .clickElement('Workflow Task Type-add')

            cy.log('Adding new Workflow Task Type configuration')
            cy.findByPlaceholderText('Field name')
                .type(projectName)
                .clickElement('Workflow Task Type-save')
                .wait('@updateWorkflowConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value(s) added')

            cy.log('Search Workflow Task Type configuration')
            cy.enterText('Workflow Task Type-input', projectName)
                .get('.d-inline-flex')
                .should('contain.text', projectName)

            cy.log('Edit Workflow Task Type configuration')
                .get('.d-inline-flex')
                .contains(projectName).trigger('mouseover')
                .findByDataCy(projectName + '-edit')
                .click({ force: true })
            cy.findByPlaceholderText('Field name')
                .clear()
            cy.findByPlaceholderText('Field name')
                .type('Non' + projectName)
                .findByDataCy('Non' + projectName + '-save')
                .click({ force: true })
                .wait('@updateWorkflowConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value updated')

            cy.log('Delete Workflow Task Type configuration')
            cy.findByDataCy('Workflow Task Type-input')
                .clear()
            cy.enterText('Workflow Task Type-input', 'Non' + projectName)
                .get('.d-inline-flex')
                .contains('Non' + projectName).trigger('mouseover')
                .findByDataCy('Non' + projectName + '-delete')
                .click({ force: true })
                .get('.ui-confirmdialog-acceptbutton')
                .click()
                .wait('@updateWorkflowConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value deleted')
        })
    });

    it('Should Add,Search,Edit and delete Trade configuration', () => {

        cy.server().route('PATCH', '/cmb/V1/configurations/trades').as('updateTradeConf')

        cy.getRandomString().then(projectName => {

            cy.log('verifying configuration page')
                .get('.ap-bread-active').contains('Configurations')
                .clickElement('Trade-add')

            cy.log('Adding new Workflow Task Type configuration')
            cy.findByPlaceholderText('Field name')
                .type(projectName)
                .clickElement('Trade-save')
                .wait('@updateTradeConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value(s) added')

            cy.log('Search Workflow Trade configuration')
            cy.enterText('Trade-input', projectName)
                .get('.d-inline-flex')
                .should('contain.text', projectName)

            cy.log('Edit Workflow Task Type configuration')
                .get('.d-inline-flex')
                .contains(projectName).trigger('mouseover')
                .findByDataCy(projectName + '-edit')
                .click({ force: true })
            cy.findByPlaceholderText('Field name')
                .clear()
            cy.findByPlaceholderText('Field name')
                .type('Non' + projectName)
                .findByDataCy('Non' + projectName + '-save')
                .click({ force: true })
                .wait('@updateTradeConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value updated')


            cy.log('Delete Workflow Trade configuration')
            cy.findByDataCy('Trade-input')
                .clear()
            cy.enterText('Trade-input', 'Non' + projectName)
                .get('.d-inline-flex')
                .contains('Non' + projectName).trigger('mouseover')
                .findByDataCy('Non' + projectName + '-delete')
                .click({ force: true })
                .get('.ui-confirmdialog-acceptbutton')
                .click()
                .wait('@updateTradeConf').its('status')
                .should('eq', 200)
                .get('.ui-toast-detail')
                .should('contain.text', 'Configuration value deleted')
        })
    });

    it.skip('Should check Report Settings-commitment change orders tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/commitment_change_orders').as('updateCommitmentOrders')

        cy.findByText('Report Settings').click()
            .clickElement('COMMITMENT_CHANGE_ORDERS')
            .clickElement('COMMITMENT_CHANGE_ORDERS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('COMMITMENT_CHANGE_ORDERS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.COMMITMENT_CHANGE_ORDERS_DISCLAIMER_TEXT)
            .findByDataCy('COMMITMENT_CHANGE_ORDERS-saveBtn')
            .should('exist')
            .clickElement('COMMITMENT_CHANGE_ORDERS-cancelBtn')
            .wait('@updateCommitmentOrders').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Commitment Change Orders changes saved successfully')

    });

    it.skip('Should check Report Settings-Cost issues tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/cost_issues').as('updateCostIssue')

        cy.findByText('Report Settings').click()
            .clickElement('COST_ISSUES')
            .clickElement('COST_ISSUES-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('COST_ISSUES-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.COST_ISSUES_DISCLAIMER_TEXT)
            .findByDataCy('COST_ISSUES-saveBtn')
            .should('exist')
            .clickElement('COST_ISSUES-cancelBtn')
            .wait('@updateCostIssue').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Cost Issues changes saved successfully')

    });

    it.skip('Should check Report Settings-Daily log tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/daily_log').as('updateDailyLog')

        cy.findByText('Report Settings').click()
            .clickElement('DAILY_LOG')
            .clickElement('DAILY_LOG-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('DAILY_LOG-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.DAILY_LOG_DISCLAIMER_TEXT)
            .findByDataCy('DAILY_LOG-saveBtn')
            .should('exist')
            .clickElement('DAILY_LOG-cancelBtn')
            .wait('@updateDailyLog').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Daily Log changes saved successfully')
    });

    it.skip('Should check Report Settings-Inspections tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/inspections').as('updateInspections')

        cy.findByText('Report Settings').click()
            .clickElement('INSPECTIONS')
            .clickElement('INSPECTIONS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('INSPECTIONS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.INSPECTIONS_DISCLAIMER_TEXT)
            .findByDataCy('INSPECTIONS-saveBtn')
            .should('exist')
            .clickElement('INSPECTIONS-cancelBtn')
            .wait('@updateInspections').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Inspections changes saved successfully')

    });

    it.skip('Should check Report Settings-Meeting Agenda tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/meeting_agenda').as('updateMeetingAgenda')

        cy.findByText('Report Settings').click()
            .clickElement('MEETING_AGENDA')
            .clickElement('MEETING_AGENDA-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('MEETING_AGENDA-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.MEETING_AGENDA_DISCLAIMER_TEXT)
            .findByDataCy('MEETING_AGENDA-saveBtn')
            .should('exist')
            .clickElement('MEETING_AGENDA-cancelBtn')
            .wait('@updateMeetingAgenda').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Meeting Agenda changes saved successfully')

    });

    it.skip('Should check Report Settings-Meeting minutes tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/meeting_minutes').as('updateMeetingMinutes')

        cy.findByText('Report Settings').click()
            .clickElement('MEETING_MINUTES')
            .clickElement('MEETING_MINUTES-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('MEETING_MINUTES-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.MEETING_MINUTES_DISCLAIMER_TEXT)
            .findByDataCy('MEETING_MINUTES-saveBtn')
            .should('exist')
            .clickElement('MEETING_MINUTES-cancelBtn')
            .wait('@updateMeetingMinutes').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Meeting Minutes changes saved successfully')

    });

    it.skip('Should check Report Settings-Observations tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/observations').as('updateObservations')

        cy.findByText('Report Settings').click()
            .clickElement('OBSERVATIONS')
            .clickElement('OBSERVATIONS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('OBSERVATIONS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.OBSERVATIONS_DISCLAIMER_TEXT)
            .findByDataCy('OBSERVATIONS-saveBtn')
            .should('exist')
            .clickElement('OBSERVATIONS-cancelBtn')
            .wait('@updateObservations').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Observations changes saved successfully')

    });

    it.skip('Should check Report Settings-Potential chaage order tab.', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/potential_change_orders').as('updatePotentialOrder')

        cy.findByText('Report Settings').click()
            .clickElement('POTENTIAL_CHANGE_ORDERS')
            .clickElement('POTENTIAL_CHANGE_ORDERS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('POTENTIAL_CHANGE_ORDERS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.POTENTIAL_CHANGE_ORDERS_DISCLAIMER_TEXT)
            .findByDataCy('POTENTIAL_CHANGE_ORDERS-saveBtn')
            .should('exist')
            .clickElement('POTENTIAL_CHANGE_ORDERS-cancelBtn')
            .wait('@updatePotentialOrder').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Potential Change Orders changes saved successfully')

    });

    it.skip('Should check Report Settings-prime contract change order tab.', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/prime_contract_change_orders').as('updatePrimeContract')

        cy.findByText('Report Settings').click()
            .clickElement('PRIME_CONTRACT_CHANGE_ORDERS')
            .clickElement('PRIME_CONTRACT_CHANGE_ORDERS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('PRIME_CONTRACT_CHANGE_ORDERS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.PRIME_CONTRACT_CHANGE_ORDERS_DISCLAIMER_TEXT)
            .findByDataCy('PRIME_CONTRACT_CHANGE_ORDERS-saveBtn')
            .should('exist')
            .clickElement('PRIME_CONTRACT_CHANGE_ORDERS-cancelBtn')
            .wait('@updatePrimeContract').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Prime Contract Change Orders changes saved successfully')

    });

    it.skip('Should check Report Settings-Punch list tab', () => {

        cy.server().route('PATCH', 'cmb/report_disclaimer/punchlist').as('updatePunchList')

        cy.findByText('Report Settings').click()
            .clickElement('PUNCHLIST')
            .clickElement('PUNCHLIST-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('PUNCHLIST-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.PUNCHLIST_DISCLAIMER_TEXT)
            .findByDataCy('PUNCHLIST-saveBtn')
            .should('exist')
            .clickElement('PUNCHLIST-cancelBtn')
            .wait('@updatePunchList').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Punchlist changes saved successfully')
    });

    it.skip('Should check Report Settings-RFI tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/rfi').as('updateRFI')

        cy.findByText('Report Settings').click()
            .clickElement('RFI')
            .clickElement('RFI-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('RFI-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.RFI_DISCLAIMER_TEXT)
            .findByDataCy('RFI-saveBtn')
            .should('exist')
            .clickElement('RFI-cancelBtn')
            .wait('@updateRFI').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Rfi changes saved successfully')

    });

    it.skip('Should check Report Settings-Safty tab', () => {

        cy.server().route('PATCH', 'cmb/report_disclaimer/safety').as('updateSafety')

        cy.findByText('Report Settings').click()
            .clickElement('SAFETY')
            .clickElement('SAFETY-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('SAFETY-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.SAFETY_DISCLAIMER_TEXT)
            .findByDataCy('SAFETY-saveBtn')
            .should('exist')
            .clickElement('SAFETY-cancelBtn')
            .wait('@updateSafety').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Safety changes saved successfully')

    });

    it.skip('Should check Report Settings-Submittals tab', () => {

        cy.server().route('PATCH', '/cmb/report_disclaimer/submittals').as('updateSubmittals')

        cy.findByText('Report Settings').click()
            .clickElement('SUBMITTALS')
            .clickElement('SUBMITTALS-$ProjectCompany$')
            .get('.ui-toast-detail')
            .should('contain.text', 'Copied to clipboard')
            .clickElement('SUBMITTALS-disclaimerText')
            .get('.ql-editor')
            .clear()
            .type(configConstants.SUBMITTALS_DISCLAIMER_TEXT)
            .findByDataCy('SUBMITTALS-saveBtn')
            .should('exist')
            .clickElement('SUBMITTALS-cancelBtn')
            .wait('@updateSubmittals').its('status')
            .should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Submittals changes saved successfully')

    });

})

const visitConfiguration = function () {

    cy.log('Visiting configuration directory')
        .server().route('GET', '/cmb/V1/configurations').as('loadConf')
        .visitPage('/configurations')
        .wait('@loadConf').its('status').should('eq', 200)
        .url().should('include', '/configurations')

}
