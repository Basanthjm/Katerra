import '../support/setup-tests'
import { getUser } from '../support/users'

const homeConstants = require('../support/constants ')
const loggedInUser = Cypress.env('isAdminUser') ? getUser('adminUser') : getUser('nonAdminUser')

describe('Apollo Landing Page (Projects Page)', () => {

  beforeEach(() => {

    cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
    cy.server().route('GET', '/identity/users/**').as('userDetails')
    cy.server().route('GET', '/tenant/projects?**').as('getProjects')
    cy.server().route('GET', '/tenant/projects?includeAll=true&search=*').as('getSearchResult')
    cy.server().route('GET', '/tenant/projects/*').as('getProjectDetails')
    cy.server().route('GET', '/cmb/companies?company_ids=*').as('getCompanies')
    cy.server().route('GET', '/tenant/members/permissions?type=tenant&typeId=*').as('getTPermissions')

  })

  it('Should verify the apollo home page', () => {

    cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
    cy.server().route('GET', '/identity/users/**').as('userDetails')
    cy.server().route('GET', '/tenant/projects?pageSize=15&includeAll=true').as('getProjects')
    cy.server().route('GET', '/tenant/projects/*').as('getProjectDetails')
    cy.server().route('GET', '/cmb/companies?company_ids=*').as('getCompanies')
    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&active=true&includeAll=true').as('getFirst15Projects')

    cy.visitPage('/home')
      .wait('@loadConfigJson').its('status').should('eq', 200)
      .wait('@getTPermissions').its('status').should('eq', 200)
      .getCookies().should('have.length', 4)

    cy.wait('@userDetails').its('status').should('eq', 200)
    cy.wait('@getProjects').its('status').should('eq', 200)

    let currentTime = Cypress.moment().format('a')
    const todaysDate = Cypress.moment().format('dddd, D MMMM, YYYY')

    cy.log(`Verifying today's date is displayed`)
    cy.contains(todaysDate)

    cy.log(`Verifying greeting message with the logged in user name`)
    if (currentTime === 'am') {
      cy.contains(`Good Morning, ${loggedInUser.name}`)
    } else if (currentTime === 'pm') {
      currentTime = Cypress.moment().format('H')
      if (currentTime >= 12 && currentTime < 18) {
        cy.contains(`Good Afternoon, ${loggedInUser.name}`)
      } else {
        cy.contains(`Good Evening, ${loggedInUser.name}`)
      }
    }

    cy.log('Verifying Select project and search field')
      .get('.ap-project-name').should('contain.text', 'Select Project')
      .get('.ap-down-arrow').click()
      .get('.ap-project-search > .ap-text-sm').should('exist')

    cy.log(`Verifying Help and Email Us links`)
      .get('.ap-icon-help').should('be.visible')

    cy.log(`Verifying logged in user's email is displayed in Accounts`)
      .get('.ap-user-circle').click()
    cy.contains(loggedInUser.email.toLowerCase())
    cy.contains('EDIT PROFILE')
    cy.contains('Sign Out')

    cy.log(`Verify that the recently accessed projects show up`)
    //Collect a Project from the list of projects to check recently accessed project
    cy.wait('@getFirst15Projects').then((xhr) => {
      const listOfProjects = xhr.response.body.projects
      let firstProject = ''
      let firstProjectToLower = ''

      if (listOfProjects.length > 0) {
        firstProject = listOfProjects[0].name
        firstProjectToLower = firstProject.toLowerCase()
        cy.server().route('GET', '/tenant/projects?pageSize=15&includeAll=true&search=' + firstProjectToLower).as('getSearchResult')
      } else {
        cy.log('No project created yet')
      }

      cy.log('Clicking on first project in list')
        .get('.name', { timeout: 2000 })
        .contains(firstProject)
        .click()
        .wait('@getCompanies').its('status').should('eq', 200)
        .wait('@getProjectDetails').its('status').should('eq', 200)
      cy.visitPage('/home')
        .wait('@loadConfigJson').its('status').should('eq', 200)
        .wait('@getTPermissions').its('status').should('eq', 200)
        .getCookies().should('have.length', 4)
      cy.wait('@getProjects').its('status').should('eq', 200)
      cy.contains('Recently Accessed Projects').should('exist', { timeout: 10000 })
        .get('.text').should('contain.text', firstProject)
    })

  })

  it('Should verify the Settings menu', () => {

    visitApolloHome()

    cy.get('.ap-icon-settings').click()
      .get('.popover-body').should('contain', 'General Settings')
      .get('.popover-body').should('contain', 'Budgeting Settings')
      .get('.popover-body').should('contain', 'Scheduler Settings')
      .get('.popover-body').should('contain', 'Collaboration Settings')

    cy.log('Verifying core service settings')
      .get('a').should('contain', 'Project Directory')
      .and('have.attr', 'href')
      .get('a').should('contain', 'User Directory')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Company Directory')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Distribution Groups')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Roles')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Workflow Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Configuration')
      .and('have.attr', 'href')

    cy.log('Verifying Budget settings')
      .get('a').should('contain', 'Scope Master')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Billing Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Configurations')
      .and('have.attr', 'href')

    cy.log('Verifying Schedule Settings')
      .get('a').should('contain', 'Material Master')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Resource Master')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Activity Master')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Configurations')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Activity Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Tags')
      .and('have.attr', 'href')

    cy.log('Verifying Collaboration Settings')
      .get('a').should('contain', 'Inspection Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Daily Log Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Meeting Templates')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Configurations')
      .and('have.attr', 'href')
      .get('a').should('contain', 'Configurations')
      .and('have.attr', 'href')

  })

  it('Should verify the core service landing pages from Settings menu', () => {

    cy.server().route('GET', '/tenant/members?next=**').as('getTenantMembers')
    cy.server().route('GET', '/tenant/roles?**').as('getRoles')
    cy.server().route('GET', '/tenant/projects?**').as('getProjects')
    cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
    cy.server().route('GET', '/cmb/companies?sort=name&*').as('getCompanies')
    cy.server().route('GET', '/cmb/V1/configurations').as('getConfiguration')
    cy.server().route('GET', '/cmb/workflow').as('getWorkflowTemplates')
    cy.server().route('GET', '/tenant/groups').as('getDistributionGroups')
    cy.server().route('GET', '/tenant/roles?pageSize=1000').as('getRoles')
    cy.server().route('GET', '/tenant/permissions?type=tenant&categoryKeys=*').as('getTenantPermissions')

    visitApolloHome()

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Project Directory').click()
      .wait('@getProjects').its('status').should('eq', 200)
      .url().should('include', 'directory')

    cy.wait('@getProjects').its('status').should('eq', 200)
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('User Directory').click()
      .wait('@getCompanies').its('status').should('eq', 200)
      .url().should('include', '/admin/users')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Company Directory').click()
      .wait('@getCompanies').its('status').should('eq', 200)
      .url().should('include', '/company')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Distribution Groups').click()
      .wait('@getDistributionGroups').its('status').should('eq', 200)
      .url().should('include', '/admin/distribution-group')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Workflow Templates').click()
      .wait('@getWorkflowTemplates').its('status').should('eq', 200)
      .url().should('include', '/workflow')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Configuration').click()
      .wait('@getConfiguration').its('status').should('eq', 200)
      .url().should('include', '/configurations')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Roles').click()
      .wait('@getRoles').its('status').should('eq', 200)
      .wait('@getTenantPermissions').its('status').should('eq', 200)
      .url().should('include', '/admin/roles')

  })

  it('Should verify the Budget landing pages from Settings menu ', () => {

    cy.server().route('GET', '/cbs/scopemaster/tree').as('getScopeMaster')
    cy.server().route('GET', '/cmb/billing_period_template?limit=50&offset=0').as('getBilingTemplate')
    cy.server().route('GET', '/cmb/V1/configurations').as('getConfigurations')

    visitApolloHome()

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Scope Master').click()
      .wait('@getScopeMaster').its('status').should('eq', 200)
      .url().should('include', '/cb/scopemaster')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Billing Templates').click()
      .wait('@getBilingTemplate').its('status').should('eq', 200)
      .url().should('include', '/cb/budget-setting/billing-template/list')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Configurations').click()
      .wait('@getConfigurations').its('status').should('eq', 200)
      .url().should('include', '/configurations')

  });

  it('Should verify the Schedule landing pages from Settings menu ', () => {

    cy.server().route('GET', '/scheduler/material_master?page=1&limit=20').as('getMaterialMaster')
    cy.server().route('GET', '/scheduler/resource_master?page=1&limit=20').as('getResourceMaster')
    cy.server().route('GET', '/cmb/activity_master?limit=10&page=1').as('getActiveMaster')
    cy.server().route('GET', '/scheduler/activity_template/published').as('getActiveTemplate')
    cy.server().route('GET', '/cmb/projects').as('loadProjects')
    cy.server().route('GET', '/cmb/V1/configurations').as('getScheduleConfigs')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Material Master').click()
      .wait('@getMaterialMaster').its('status').should('eq', 200)
      .url().should('include', '/cs/material')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Resource Master').click()
      .wait('@getResourceMaster').its('status').should('eq', 200)
      .url().should('include', '/cs/resource-master')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Activity Master').click()
      .wait('@getActiveMaster').its('status').should('eq', 200)
      .url().should('include', '/cs/activity-master/list')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Activity Templates').click()
      .wait('@getActiveTemplate').its('status').should('eq', 200)
      .url().should('include', '/cs/activity-templates')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('[href="/cs/config"]').click()
      .wait('@getScheduleConfigs').its('status').should('eq', 200)
      .url().should('include', '/cs/config/list')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Tags').click()
      .wait('@loadProjects').its('status').should('eq', 200)
      .url().should('include', '/cs/tags/list')

  });

  it('Should verify the Collaboration landing pages from Settings menu', () => {

    cy.server().route('GET', '/cmb/V1/inspection-template').as('getInspectionTemplate')
    cy.server().route('GET', '/cmb/dailylog-template?limit=50&offset=0').as('getDailyLogTemplate')
    cy.server().route('GET', '/cmb/V1/mom-template').as('getMomTemplate')

    visitApolloHome()
    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Inspection Templates').click()
      .wait('@getInspectionTemplate').its('status').should('eq', 200)
      .url().should('include', '/construct/settings/inspection-template/list')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Daily Log Templates').click()
      .wait('@getDailyLogTemplate').its('status').should('eq', 200)
      .url().should('include', '/construct/settings/dailylog-template/list')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('.popover-body').contains('Meeting Templates').click()
      .wait('@getMomTemplate').its('status').should('eq', 200)
      .url().should('include', '/construct/settings/meeting-minutes/list')

    cy.get('.ap-icon-settings').click({ force: true })
      .get('[href="/construct/settings/configurations"]').click()
      .wait('@userDetails').its('status').should('eq', 200)
      .url().should('include', '/construct/settings/configurations')

  });

  it('Should able to edit profile of the user', () => {
    cy.server().route('GET', '/identity/users/**').as('userDetails')
    if (!Cypress.env('isAdminUser')) {
      cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
      cy.visitPage('/home')
        .wait('@loadConfigJson').its('status').should('eq', 200)
        .wait('@userDetails').its('status').should('eq', 200)
        .getCookies().should('have.length', 4)

      cy.log('testing' + Cypress.env('isAdminUser'))

      //running it twice so that password is set back to the original
      for (let i = 0; i < 2; i++) {

        cy.get('.ap-user-circle').click()

        cy.get('.user-email').contains(loggedInUser.email)
        cy.findByRole('button', { name: 'Edit Profile' }).should('exist').click()
        cy.findByRole('dialog').should('exist')
        cy.get('#address').clear({ force: true }).type(homeConstants.ADDRESS)
        cy.get('#phoneNumber').clear({ force: true }).type(homeConstants.PHONE_NUMBER)
        cy.get('#title').clear().type(homeConstants.TITTLE)
        cy.get('#oldPassword').clear().type(loggedInUser.password)
        cy.get('#password').clear().type(homeConstants.NEW_PASSWORD)
        cy.get('#confirmPassword').clear().type(homeConstants.NEW_PASSWORD)
        cy.findByRole('button', { name: 'Save Changes' }).should('exist').click()
      }

    } else {
      cy.log('Test case executes only for non admin user')
    }
  })

  it('Should able to add profile photo while edit profile', () => {
    const yourFixturePath = 'Profile_pic.png'; 
    cy.server().route('GET', '/identity/users/**').as('userDetails')
    cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
    cy.server().route('PUT', '**/identity/users/**').as('putIdentityUsers')
    cy.visitPage('/home')
      .wait('@loadConfigJson').its('status').should('eq', 200)
      .wait('@userDetails').its('status').should('eq', 200)
      .getCookies().should('have.length', 3)
    cy.get('.ap-user-circle').click()
    cy.findByText('EDIT PROFILE').should('exist').click()
    cy.get('[type="file"]').attachFile(yourFixturePath, { force: true });
    
  })

})

const visitApolloHome = function () {
  cy.visitPage('/home')
    .wait('@loadConfigJson').its('status').should('eq', 200)
    .wait('@getTPermissions').its('status').should('eq', 200)
    .getCookies()
}

