const companyConstants = require('../support/constants ')

describe('Company directory', () => {

    let newCompanyName = ''

    beforeEach(() => {
       
        cy.server().route('GET', '/cmb/companies/count').as('getCompanyCount')
        cy.server().route('GET', '/cmb/companies?**').as('getCompanies')
        cy.server().route('POST', '/cmb/companies').as('createCompany')
        cy.server().route('PATCH', '/cmb/companies/**').as('updateCompany')
        
})

    it('Should verify company directory landing page and sorting', () => {

        visitCompanyDirectory()
        cy.get('.ui-menuitem-text').should('contain.text', 'Company Directory')
        cy.wait('@getCompanyCount').then((xhr) => {
            let companiesCounts = xhr.response.body.data
            cy.findByText('Companies ' + '(' + companiesCounts + ')').should('exist')
        })
        cy.findByPlaceholderText('Search Name').should('exist')
        cy.findByDataCy('addNewCompany').should('exist')

        cy.clickElement('idSort')
        cy.get('[data-cy=idSort] > #subHeader > .pull-right > .arrow').should('exist')

        cy.findByText('Id').should('exist')
        cy.findByText('Company Name').should('exist')
        cy.findByText('ERP Name').should('exist')
        cy.findByText('Trade').should('exist')
        cy.findByText('Address').should('exist')
        cy.findByText('Points of Contact').should('exist')
        cy.findByText('Phone Number').should('exist')
        cy.findByText('Email').should('exist')

    });

    it('Should create new company', () => {

        cy.getRandomString().then(companyName => {
            visitCompanyDirectory()
            cy.wait('@getCompanyCount').then((xhr) => {
                let companiesCountBefore = xhr.responseBody.data
                let companiesCountAfter = companiesCountBefore + 1
                cy.log(companiesCountBefore)
                cy.wait('@getCompanies').its('status').should('eq', 200)
                cy.findByDataCy('addNewCompany').click({ force: true })
                cy.get('.dialog-Header').should('contain.text', 'Add new Company')
                    .get('.form-control').type(companyName)
                    .findByDataCy('vendorID').type(companyName)
                    .verifyElementEnabled('addCompany')
                    .findByDataCy('addCompanyBtn').click({ force: true })
                cy.wait('@createCompany').its('status').should('eq', 201)
                    .get("[class='ui-toast-detail']")
                    .should('contain.text', 'Company successfully added')
                newCompanyName = companyName
                cy.reload()
                cy.wait('@getCompanies').its('status').should('eq', 200)
                cy.log(companiesCountAfter)
                cy.findByText('Companies ' + '(' + companiesCountAfter + ')').should('exist')
            })

        })
    })

    it('Should check for duplicate company name error message', () => {

        cy.server().route('GET', '/cmb/companies/suggestion/_list?q=' + newCompanyName).as('getCompaniesSuggestion')
        visitCompanyDirectory()
        cy.wait('@getCompanies').its('status').should('eq', 200)

        cy.findByDataCy('addNewCompany').click()
        cy.get('.form-control').type(newCompanyName)
        cy.wait('@getCompaniesSuggestion').then((xhr) => {
            let company = xhr.response.body.data
            assert.equal(1, company.length)
            cy.get('.error-holder')
                .should('contain.text', 'Company name is already in use.')

        })
    })

    it('Should search created comapany', () => {

        cy.server().route('GET', '/cmb/companies/search/_list?q=Non_cypress&sort=name&limit=50&offset=0').as('getEmptySearch')
        visitCompanyDirectory()
        cy.wait('@getCompanies').its('status').should('eq', 200)

            .log('Searching Non-Exsiitng comapany name')
        cy.findByDataCy('searchBox').type(companyConstants.SEARCH_NON_EXIST, { force: true })
        cy.get('.ng-star-inserted > .d-block').should('contain.text', 'No Company Found')
            .wait('@getEmptySearch').its('status').should('eq', 200)

            .log('Searching Exsiitng comapany name')
        cy.findByDataCy('searchBox').clear().type(newCompanyName, { force: true })
            .get('[data-cy=company_name] > .content-div').should('contain.text', newCompanyName)
    })

    it('Should edit created company', () => {

        cy.server().route('GET', '/cmb/V1/configurations/trades').as('loadTrades')
        cy.server().route('GET', '/tenant/members?type=tenant&includeUsers=true').as('getTenantMember')
        cy.server().route('POST', '/file_management/s3/upload_info').as('fileUpload')
        cy.server().route('POST', '/cna/attachments/company/***').as('fileAttach')
        cy.server().route('GET', '/identity/users').as('getUser')
        cy.server().route('GET', '/cmb/companies/search/_list?q=' + newCompanyName + '&sort=name&*').as('getSearch')

        visitCompanyDirectory()
        cy.wait('@getCompanies').its('status').should('eq', 200)
        cy.findByDataCy('searchBox').type(newCompanyName, { force: true })
            .wait('@getSearch').its('status').should('eq', 200)
            .get('[data-cy=company_name] > .content-div').should('contain.text', newCompanyName)
            .click({ force: true })

            .clickElement('editDetails')
            .log('Editing General details')
        cy.fixture('code.jpg').then(fileContent => {
            cy.get("[data-cy='logoFile']").attachFile({
                fileContent: fileContent.toString(),
                fileName: 'code.jpg',
                mimeType: 'image/jpg'
            })
        })
        cy.findByDataCy('vendorId').clear().type(companyConstants.VENDORID)
            .clickElement('cancelDetails')
            .wait('@updateCompany').its('status').should('eq', 400)
            .get('.ui-toast-detail').should('contain.text', 'Company name or vendor_id already exists')
            .findByDataCy('vendorId').clear().type(newCompanyName)
            .clickElement('point_of_contact')
            .get('.ui-confirmdialog-message').should('contain.text', 'Unsaved changes will be lost')
            .clickElement('reject')
            .findByDataCy('companyName').should('have.value', newCompanyName)
            .findByDataCy('street').clear().type(companyConstants.STREET)
            .findByDataCy('city').clear().type(companyConstants.CITY)
            .findByDataCy('state').clear().type(companyConstants.STATE)
            .findByDataCy('country').clear().type(companyConstants.COUNTRY)
            .findByDataCy('zip').clear().type(companyConstants.ZIPCODE)
            .findByDataCy('email').clear().type(companyConstants.EMAIL)
            .findByDataCy('website').clear().type(companyConstants.WEBSITE)
            .findByDataCy('mobile').clear().type(companyConstants.TELEPHONE)
            .findByDataCy('fax').clear().type(companyConstants.FAX)
            .clickElement('cancelDetails')
            .wait('@updateCompany').its('status').should('eq', 200)
            .get("[class='ui-toast-detail']").should('contain.text', 'Company Details updated successfully.')


            .log('Editing Point of contact details')
            .clickElement('point_of_contact')
            .wait('@getUser').its('status').should('eq', 200)
            .wait('@loadTrades').its('status').should('eq', 200)
            .get('.btn-default').click()
            .get("[formcontrolname='contact_name']").type(companyConstants.NAME)
            .wait('@getTenantMember').its('status').should('eq', 200)
            .get('.option-row > :nth-child(1)', { timeout: 2000 }).click()
            .get('[src="assets/icons/CloseRed.svg"]').should('exist')
            .get('[src="assets/icons/TickBlue.svg"]').click()
            .wait('@updateCompany').its('status').should('eq', 200)
            .get("[class='ui-toast-detail']").should('contain.text', 'Points of contact updated.')
            .wait('@getTenantMember').its('status').should('eq', 200)

            .log('Editing Point of contact details with dublicate contact')
            .get('.btn-default').click()
            .get("[formcontrolname='contact_name']").type(companyConstants.NAME)
            .wait('@getTenantMember').its('status').should('eq', 200)
            .get('.option-row > :nth-child(1)', { timeout: 2000 }).click()
            .get("[class='ui-toast-detail']").should('contain.text', 'Email Already Exist.')
            .get('[src="assets/icons/CloseRed.svg"]').click()


        cy.log('Adding Attachment')
            .log('Attaching image file')
            .clickElement('attachments')
            .fixture('code.jpg').then(fileContent => {
                cy.get("[data-cy='logoFile']").attachFile({
                    fileContent: fileContent.toString(),
                    fileName: 'code.jpg',
                    mimeType: 'image/jpg'
                })
            })

            .log('Attaching pdf file')
            .fixture('Cypress.pdf').then(fileContent => {
                cy.get("[data-cy='logoFile']").attachFile({
                    fileContent: fileContent.toString(),
                    fileName: 'Cypress.pdf',
                    mimeType: 'pdf'
                })
            })

    cy.wait('@fileUpload').its('status').should('eq', 200)
            .wait('@fileAttach').its('status').should('eq', 201)
            .get("[class='ui-toast-detail']").should('contain.text', 'Attachment saved successfully.')

    })

    it('Should delete created company', () => {

        visitCompanyDirectory()
        cy.wait('@getCompanies').its('status').should('eq', 200)
        cy.server().route('GET', '/cmb/companies/search/_list?q=' + newCompanyName + '&sort=name&*').as('getSearch')
        cy.findByDataCy('searchBox').type(newCompanyName, { force: true })
            .get('.loading > .fa')
            .should('not.be.visible', { timeout: 4000 })
            .wait('@getSearch').its('status').should('eq', 200)
            .get('[data-cy=company_name] > .content-div')

            .log("Deleting created company")
            .findByDataCy('inactiveButton')
            .click({ force: true })
            .clickElement('confirm')
            .wait('@updateCompany').its('status').should('eq', 200)
            .get("[class='ui-toast-detail']")
            .should('contain.text', 'Status updated')


    })

    it('Should activate deleted company', () => {

        visitCompanyDirectory()
        cy.wait('@getCompanies').its('status').should('eq', 200)
        cy.log("Activating deleted company")
            .server().route('GET', '/cmb/companies/search/_list?q=' + newCompanyName + '&sort=name&*').as('getSearch')
            .findByDataCy('searchBox').type(newCompanyName, { force: true })
            .get('.loading > .fa')
            .should('not.be.visible', { timeout: 4000 })
            .wait('@getSearch').its('status').should('eq', 200)
            .get('[data-cy=company_name] > .content-div')
            .get("[src='assets/icons/UndeleteIcon.svg']")
            .click({ force: true })
            .clickElement('confirm')
            .wait('@updateCompany').its('status').should('eq', 200)
            .get("[class='ui-toast-detail']")
            .should('contain.text', 'Status updated')

    })

})

const visitCompanyDirectory = function () {

    cy.visitPage('/cmf/company/list')
    cy.url().should('include', '/cmf/company/list')
}