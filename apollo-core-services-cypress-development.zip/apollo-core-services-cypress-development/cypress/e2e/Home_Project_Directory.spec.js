const projectConstants = require('../support/constants ')

let newProjectName

describe('Project Directory', () => {

  beforeEach(() => {

    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&active=true&includeAll=true').as('getAllProjects')
    cy.server().route('GET', '/tenant/members/permissions?type=tenant&typeId=*').as('getTenantPermissions')
    cy.server().route('GET', '/tenant/projects?includeAll=true&disabled=true').as('getProjectsCount')
    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&active=true&includeAll=true&search=' + newProjectName).as('searchProject')
    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&active=true&includeAll=true&search=**').as('searchProject')
    cy.server().route('GET', '/tenant/projects/*').as('getProjectDetails')
    cy.server().route('POST', '/tenant/projects').as('createProject')
    cy.server().route('GET', '/tenant/members?sortKey=name&sort=1&pageSize=500&type=project&typeId=**&includeUsers=true').as('getProjectUsers')
    cy.server().route('GET', '/identity/users').as('getUsers')
    cy.server().route('POST', '/tenant/members').as('addUserToProject')
    cy.server().route('DELETE', 'tenant/projects/**').as('deleteProjectUser')
    cy.server().route('GET', '/tenant/projects/**/invites?pageSize=1000').as('getTenantProjects')
    cy.server().route('GET', '/tenant/projects?active=true&includeAll=true&parentId=**').as('getParentID')

  })

  it('Should verify project directory landing page and sorting', () => {

    visitProjectDirectory()
    cy.wait('@getProjectsCount').then((xhr) => {
      let projectsCounts = xhr.response.body.totalCount
      let projectNameBeforeSort = xhr.response.body.projects[0].name
      cy.log(projectNameBeforeSort)
      cy.contains(`Project Directory (${projectsCounts})`)

      cy.findByPlaceholderText('Search Name or Number').should('exist')
      cy.findByDataCy('addNewProject').should('exist')

      cy.get('[ref="eSortAsc"]').should('exist')
      cy.get('[ref="eSortAsc"]').first().click()
      cy.get('[ref="eSortDesc"]').should('exist')
      cy.get('.ag-row-first > .name').should('not.have.value', projectNameBeforeSort)

      cy.get('[ref="eSortDesc"]').first().click()
      cy.get('[ref="eSortNone"]').should('exist')

      cy.findByText('Project Name').should('exist')
      cy.findByText('Project Number').should('exist')
      cy.findByText('Project Type').should('exist')
      cy.findByText('Project Stage').should('exist')
      cy.findByText('Description').should('exist')

    })

  });

  it('Should create new project and validate projects count', () => {

    cy.server().route('POST', '/tenant/projects').as('createProject')
    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait('@getProjectsCount').then((xhr) => {
      let projectsCount = parseInt(xhr.response.body.totalCount) + 1
        cy.contains(`Project Directory (${projectsCount})`)
        visitProjectDirectory()
      })
    })
  })

  it('Should validate duplicate project name on creation', () => {

    visitProjectDirectory()
    cy.clickElement('addNewProject')
      .log('checking save button visibilty')
      .findByDataCy('addProjBtn').should('be.disabled')
      .log('Creating a new project')
      .enterText('projectName', newProjectName)
      .get('.error-holder')
      .should('contain.text', 'Project name is already in use.')

  });

  it('Should display proper message on searching non-existent project', () => {

    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&includeAll=true&search=**').as('searchProject')

    visitProjectDirectory()

    cy.findByPlaceholderText('Search Name or Number')
      .type(projectConstants.SEARCH_NON_EXIST, { force: true })
      .findByDataCy('noProject').should('contain.text', 'No Results Found')
      .wait('@searchProject').its('status').should('eq', 200)

  });

  it('Should search created project', () => {

    visitProjectDirectory()
    cy.log('Searching for created project')
      .findByPlaceholderText('Search Name or Number')
      .clear({ force: true })
      .type(newProjectName, { force: true })
      .wait('@searchProject').its('status').should('eq', 200)
      .get('.name', { timeout: 3000 })
      .should('contain', newProjectName)
  })

  it('Should delete created project', () => {

    visitProjectDirectory()
    deleteProject()

  })

  it('Should update project to active state', () => {

    cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&disabled=true&active=false&includeAll=true&search=**').as('searchInactiveProject')
    cy.server().route('PUT', '/tenant/projects/*').as('updateProject')

    visitProjectDirectory()
    cy.log('Re-activating deleted project')
      .findByPlaceholderText('Search Name or Number')
      .clear()
      .type(newProjectName, { force: true })
      .clickElement('inactive')
      .wait('@searchInactiveProject')
      .its('status')
      .should('eq', 200)
      .get('.name')
      .should('contain', newProjectName)

      .get('.name')
      .trigger('mouseover')
      .get('[alt="Activate"]')
      .click({ force: true })
      .log('verifying cancel button clickable activate project dialog')
      .get('.ui-confirmdialog-rejectbutton')
      .click()

      .get('.name')
      .trigger('mouseover')
      .get('[alt="Activate"]')
      .click({ force: true })
      .log('clicking activate button on activate project dialog')
      .get('button.ui-confirmdialog-acceptbutton')
      .click()
      .wait('@updateProject')
      .its('status')
      .should('eq', 200)
  })

  it('Should edit General Details of project', () => {

    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait(4000)
      cy.get('.ui-inputtext')
        .type(newProjectName, { force: true })
        .wait('@searchProject').its('status').should('eq', 200)
        .get('.name')
        .should('contain', newProjectName).click()
        .wait('@getProjectDetails').its('status').should('eq', 200)

      cy.log('Editing General details project')
        .clickElement('editGeneral')
        .get('.loading > .fa').should('not.be.visible', { timeout: 2000 })
        .findByDataCy('locationEdit').should('be.disabled')
        .findByDataCy('editUnits').should('be.disabled')
        .findByDataCy('projName')
        .should('have.value', newProjectName)
        .get('[field=\'name\'] > span > input').clear()
        .type(projectConstants.COMPANY)
        .get('[role="option"] span').then(role => {
          role[0].click()
        })
        .enterText('projNumber', projectConstants.PROJECT_NUMBER)
        .get('[data-cy=projStage] > .ui-dropdown')
        .click({ force: true })
        .get('[role="option"] span').then(role => {
          role[0].click()
        })
        .get('[data-cy=projType] > .ui-dropdown')
        .click({ force: true })
        .get('[role="option"] span').then(role => {
          role[0].click()
        })
      cy.clickElement('projStartDate')
        .get('.ui-datepicker-today > .ui-state-default').click()
        .get('.ap-topbar-content-wrapper').click()
        .clickElement('projEndDate')
        .get('.ui-datepicker-today > .ui-state-default').click()
        .get('.ql-editor').clear().type(projectConstants.EDIT_DESCRIPTION)
        .clickElement('saveGeneral')
        .wait('@getParentID').its('status').should('eq', 200)
      visitProjectDirectory()
      deleteProject()
    })

  });

  it('Should edit List of locations of project', () => {
    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait(4000)
      cy.get('.ui-inputtext')
        .type(newProjectName, { force: true })
        .wait('@searchProject').its('status').should('eq', 200)
        .get('.name')
        .should('contain', newProjectName).click()
        .wait('@getProjectDetails').its('status').should('eq', 200)

      cy.log("Clicking on Bulk edit button")
        .clickElement('locationEdit')

      cy.log("importing from project")
        .clickElement('importBtn')
        .get('.ui-menuitem-text')
        .contains('From Project')
        .click()
        .get('.ui-dropdown-trigger-icon')
        .click()
        .wait(3000)
        .get('.ui-dropdown-filter')
        .type('cy')
        .get('[role="option"] span').then(role => {
          role[4].click()
        })
        .clickElement('dialogImportBtn')

      cy.log('Edit list of locations of project')
        .log("Verify that Save button is disabled")
        //.contains('Save').should('be.disabled')
        .log("Adding and deleting location")
        .clickElement('addLocationBtn')
        .get('.ui-listbox-list').trigger('mouseover')
        .get('.icon-Interface-Ellipsis')
        .click({ force: true })
        .clickElement('reNameBtn')
        .findByDataCy('renameLocationInput').clear()
        .type(projectConstants.LOCATION)
        .clickElement('renameLocationBtn')

      cy.log('clicking on cancel and validating Cancel Changes pop-up')
        .clickElement('canelBtn')
        .get('.ui-confirmdialog-message')
        .should('contain.text', 'Your changes will not be saved')
        .clickElement('dialogCanceltBtn')

      cy.log('Deleting added location')
        .get('.ui-listbox-list').trigger('mouseover')
        .get('.icon-Interface-Ellipsis')
        .click({ force: true })
        .clickElement('deleteBtn')
        .clickElement('dialogdeleteBtn')
        .clickElement('canelBtn')
        .clickElement('cancelDialogBtn')
      visitProjectDirectory()
      deleteProject()
    })

  });

  it('Should edit Units of Measurement of project', () => {

    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait(4000)
      cy.get('.ui-inputtext')
        .type(newProjectName, { force: true })
        .wait('@searchProject').its('status').should('eq', 200)
        .get('.name')
        .should('contain', newProjectName).click()
        .wait('@getProjectDetails').its('status').should('eq', 200)

      cy.log("Edit Units of Measurement and sub project")
        .clickElement('editUnits')
        .log('Selecting temperature drop down')
        .findAllByText("Fahrenheit")
        .click()
        .get('[role="option"] span')
        .then(role => {
          role[1].click()
        })

        .log('Selecting wind speed drop down')
      cy.findAllByText("mph")
        .click()
        .get('[role="option"] span')
        .then(role => {
          role[1].click()
        })

        .log('Selecting currency drop down')
      cy.findAllByText("US Dollar (USD)")
        .click()
        .get('[role="option"] span')
        .then(role => {
          role[3].click()
        })

        .log('clicking on cancel')
        .get('.fr').click()

      visitProjectDirectory()
      deleteProject()

    })

  });

  it('Should edit Sub projects of project', () => {
    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait(4000)
      cy.get('.ui-inputtext')
        .type(newProjectName, { force: true })
        .wait('@searchProject').its('status').should('eq', 200)
        .get('.name')
        .should('contain', newProjectName).click()
        .wait('@getProjectDetails').its('status').should('eq', 200)

      cy.log('Editing sub projects')
      cy.getRandomString().then(projectName => {
        cy.clickElement('newSubProj')
        cy.get('.p-field > label')
          .should('contain', 'Subproject name')
        cy.findByDataCy('subProjectAddBtn')
          .should('be.disabled')
        cy.log('Adding duplicate sub project and validating error message')
          .enterText('subProjectInput', projectConstants.SUB_PROJECT)
          .clickElement('subProjectAddBtn')
          .get('.ui-toast-detail')
          .should('contain.text', 'The project name is already in use')

        cy.log('Addind new sub project')
          .clickElement('newSubProj')
          .findByDataCy('subProjectInput')
          .clear()
          .type(projectName)
          .clickElement('subProjectAddBtn')
          .wait('@createProject')
        visitProjectDirectory()
        deleteProject()

      })
    })

  });

  it('Should Add and delete Users to project', () => {

    visitProjectDirectory()
    cy.getRandomString().then(projectName => {
      createNewProject(projectName)
      cy.wait(4000)
      cy.get('.ui-inputtext')
        .type(newProjectName, { force: true })
        .wait('@searchProject').its('status').should('eq', 200)
        .get('.name')
        .should('contain', newProjectName).click()
        .wait('@getProjectDetails').its('status').should('eq', 200)

      cy.log('Adding Project Users')

      cy.findByText('Project Users')
        .click()
        //.clickElement('addNewUser')
        cy.get('.addButton').click()
        .findByDataCy('userSuggest')
        .type(projectConstants.PROJECT_USER)
        .get('.user-item')
        .click()
        .findByDataCy('userRole')
        .click()
        .get('[role="option"] span')
        .then(role => {
          role[0].click()
        })
        .findByDataCy('addUserProject')
        .click({ force: true })
        .reload()
        .wait('@getParentID').its('status').should('eq', 200)
        .clickElement('ProjectUsers')

      // cy.log('Deleting Project Users')
      //   .wait('@getProjectUsers').its('status').should('eq', 200)
      //   .get('[comp-id="32"] > span > div').trigger('mouseover')
      //   .findByDataCy('project_user_delete_0').click({ force: true }) 
      //   .wait('@deleteProjectUser')
      //   .wait('@getTenantProjects').its('status').should('eq', 200)

      visitProjectDirectory()
      deleteProject()
    })

  });

})

const visitProjectDirectory = function () {

  cy.log('Visiting project directory')
    .visitPage('/directory')
    .wait('@getTenantPermissions').its('status').should('eq', 200)
    .wait('@getAllProjects')
    .wait(1000)
}

const createNewProject = function (projectName) {

  cy.clickElement('addNewProject')
    .log('checking save button visibilty')
    .findByDataCy('addProjBtn').should('be.disabled')
    .log('Creating a new project')
    .enterText('projectName', projectName)
  newProjectName = projectName
  cy.enterText('location', 'Bengaluru, Karnataka, India')
    .get('[role="option"] span')
    .then(role => {
      role[0].click()
    })
  cy.enterText('description', projectConstants.ADD_DESCRIPTION)
    .findByDataCy('addProjBtn').click()
    .wait('@createProject').its('status').should('eq', 200)
    .get('.ui-toast-detail')
    .should('contain.text', 'Project successfully added')
    .reload()
    .wait('@getAllProjects')
    //.its('status').should('eq', 200)

}

const deleteProject = function () {

  cy.server().route('PUT', '/tenant/projects/*').as('deleteProject')
  cy.log('Deleting project')
    .findByPlaceholderText('Search Name or Number')
    .type(newProjectName, { force: true })
    .wait('@searchProject').its('status').should('eq', 200)
    .get('.name')
    .should('contain', newProjectName)
    .get('.name')
    .trigger('mouseover')
    .get('[ref="eCenterContainer"]>div:nth-child(1) app-action-cell-renderer [alt="Delete"]')
    .click({ force: true })
    .get('.ui-confirmdialog-acceptbutton > .ui-button-text')
    .click()
    .wait('@deleteProject').its('status').should('eq', 200)

}