const workflowConstants = require('../support/constants ')

describe('Workflow Templates', () => {

    let WorkFlowTempName = ''

    beforeEach(() => {
        cy.server().route('GET', '/cmb/workflow').as('getWorkflowTemplates')
        cy.server().route('GET', '/cmb/V1/user/**').as('getUser')
        cy.server().route('GET', '/cmb/projects').as('getProjects')
        cy.server().route('POST', '/cmb/workflow').as('createWorkflowTemplate')

    })

    it('Should verify workflow template landing page and sorting', () => {

        cy.visitPage('/workflow')
        cy.wait('@getWorkflowTemplates').then((xhr) => {
            const templateNameBeforeSort = xhr.response.body.result[0].workflow_name

            // cy.wait('@getProjects').its('status')
            //     .should('eq', 200)
            cy.get('.ap-bread-active')
                .should('contain.text', 'Workflow Templates')
            cy.findByDataCy('searchBox')
                .should('exist')

            cy.log('Clicking on sorts on valiating first row data')
                .findByDataCy('nameSort')
                .should('exist')
                .clickElement('nameSort')
                .get('[data-cy=nameSort] > .sort-header-arrow > .fa-long-arrow-up')
                .should('exist')
                .get('[data-cy=nameSort] > .sort-header-arrow > .fa-long-arrow-up')
                .click()
                .get(':nth-child(1) > :nth-child(1) > .template_nav')
                .should('not.have.value', templateNameBeforeSort)
                .get('[data-cy=nameSort] > .sort-header-arrow > .fa-long-arrow-down')
                .should('exist')

                .findByDataCy('date created')
                .should('exist')
                .clickElement('date created')
                .get('[data-cy="date created"] > .sort-header-arrow > .fa-long-arrow-up')
                .should('exist')
                .get('[data-cy="date created"] > .sort-header-arrow > .fa-long-arrow-up')
                .click()
                .get('[data-cy="date created"] > .sort-header-arrow > .fa-long-arrow-down')
                .should('exist')

                .findByDataCy('last visited').should('exist')

        })

    });

    it('Should verify workflow template counts', () => { 

        cy.visitPage('/workflow')
        cy.wait('@getWorkflowTemplates').then((xhr) => {
            const templates = xhr.response.body.result.length
            cy.log('Number of work flow templates ->',templates)
            if (templates > 50) {
                cy.findByText(`1-50 of ${templates}`).should('exist')
                cy.findByDataCy('nextpage').should('exist')
                cy.findByDataCy('lastPage').should('exist')
            }
            else {
                cy.findByText(`1-${templates} of ${templates}`).should('exist')
            }
        })
    });

    it('Should create new workflow template', () => {

        cy.getRandomString().then(templateName => {

            visitWorkFlowTemplate()
            cy.clickElement('addNewWorkFlow')
            cy.findByDataCy('newWorkflowTXT')
                .should('contain.text', 'New Workflow Template')
                .enterText('newWorkflowInput', templateName)
            WorkFlowTempName = templateName

        })

        cy.enterText('name-0', workflowConstants.TASK_NAME_A)
            .clickElement('category-0')
            .get('[role="option"] span')
            .then(role => {
                role[1].click()
            })
            .enterText('duration-0', workflowConstants.DURATION_A)

        cy.enterText('name-1', workflowConstants.TASK_NAME_B)
            .clickElement('category-1')
            .get('[role="option"] span')
            .then(role => {
                role[1].click()
            })
            .enterText('duration-1', workflowConstants.DURATION_B)

        cy.enterText('name-2', workflowConstants.TASK_NAME_C)
            .clickElement('category-2')
            .get('[role="option"] span')
            .then(role => {
                role[1].click()
            })
            .enterText('duration-2', workflowConstants.DURATION_C)

        cy.enterText('name-3', workflowConstants.TASK_NAME_D)
            .clickElement('category-3')
            .get('[role="option"] span')
            .then(role => {
                role[1].click()
            })
            .enterText('duration-3', workflowConstants.DURATION_D)

            .clickElement('saveTemplteBtn')

            .wait('@createWorkflowTemplate').its('status')
            .should('eq', 201)
            .get('.ui-toast-detail')
            .should('contain.text', 'Workflow template created.')

    })

    it('Should show proper message when searched for non-existent workflow template', () => {

        visitWorkFlowTemplate()
        cy.enterText('searchBox', workflowConstants.SEARCH_NON_EXIST)
            .get('.ng-star-inserted > .d-block')
            .should('contain.text', 'No Templates Found')
            .findByDataCy('searchBox').clear()

    });

    it('Should Search for created workflow template', () => {

        visitWorkFlowTemplate()
        cy.enterText('searchBox', WorkFlowTempName)
            .findByDataCy('vendor_id')
            .should('contain.text', WorkFlowTempName)
            .findByDataCy('searchBox').clear()

    });

    it('Should validate for duplicate workflow template', () => {

        visitWorkFlowTemplate()

        cy.clickElement('addNewWorkFlow')
            .enterText('newWorkflowInput', WorkFlowTempName)
            .clickElement('delete-0')
            .clickElement('delete-0')
            .clickElement('delete-0')
            .clickElement('delete-0')
            .get('.ui-toast-detail')
            .should('contain.text', 'There should be atleast one task in a template.')

        cy.enterText('name-0', workflowConstants.TASK_NAME_A)
            .clickElement('category-0')
            .get('[role="option"] span')
            .then(role => {
                role[1].click()
            })

            .enterText('duration-0', workflowConstants.DURATION_A)
            .clickElement('saveTemplteBtn')
            .wait('@createWorkflowTemplate').its('status').should('eq', 400)
            .get('.ui-toast-detail')
            .should('contain.text', 'Template name already exists')

    });

    it('Should edit and delete workflow template', () => {

        cy.server().route('PATCH', 'cmb/workflow/**').as('updateWorkflowTemplate')
        cy.server().route('DELETE', 'cmb/workflow/**').as('deleteWorkflowTemplate')

        visitWorkFlowTemplate()
        cy.getRandomString().then(templateName => {
        cy.enterText('searchBox', WorkFlowTempName)
            .findByDataCy('vendor_id')
            .contains(WorkFlowTempName)
            .click()
            .clickElement('nameEditdiv')
            .get('.editInput')
            .clear()
            .get('.editInput')
            .type(templateName)
        cy.findByAltText('TickBlue')
            .click()
            .wait('@updateWorkflowTemplate').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Workflow template Updated.')

            .clickElement('deleteTemplateBtn')
            //.clickElement('reject')
            .get('.ui-confirmdialog-rejectbutton > .ui-button-text')
            .click()
            .clickElement('deleteTemplateBtn')
            //.clickElement('confirm')
            .get('.ui-confirmdialog-acceptbutton > .ui-button-text')
            .click()
            .wait('@deleteWorkflowTemplate').its('status').should('eq', 200)
            .get('.ui-toast-detail')
            .should('contain.text', 'Workflow template Deleted.')
        })

    })

})

const visitWorkFlowTemplate = function () {

    cy.visitPage('/workflow')
    cy.wait('@getWorkflowTemplates').its('status').should('eq', 200)
    cy.url().should('include', '/workflow')
}
