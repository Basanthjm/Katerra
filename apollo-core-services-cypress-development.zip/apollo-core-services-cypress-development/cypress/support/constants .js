//Data for Company Directory Spec

//Data for search company
export const SEARCH_NON_EXIST = 'Non_cypress'

//Data for edit Company
export const VENDORID = 'cypress_118649'
export const STREET = 'Whitefield tech park'
export const CITY = 'Bangalore'
export const STATE = 'Karnataka'
export const COUNTRY = 'India'
export const ZIPCODE = '560066'
export const EMAIL = 'Email@Katerra.com'
export const WEBSITE = 'www.cypress.com'
export const TELEPHONE = '58-211-1222'
export const FAX = '12761270890'
export const PHONE = '080-237363'
export const NAME = 'katerra cypress automation'

//---------------------------------------------------------------------//

//Data for project Directory Spec

//Data for edit project
export const COMPANY = 'Katerra'
export const ADD_DESCRIPTION = 'Bengaluru, Karnataka, India'
export const PROJECT_NUMBER = '583124'
export const PROJECT_STARTDATE = '25/11/2020'
export const PROJECT_ENDDATE = '25/11/2021'
export const SUB_PROJECT = 'cypress_235288'
export const LOCATION = 'we work '
export const EDIT_DESCRIPTION = 'Checking edit functionality'
export const PROJECT_USER = 'Katerra QA4'

//---------------------------------------------------------------------//

//Data for Roles Spec

export const DEFAULT_TENANT_ROLE = 'Tenant Admin'
export const DEFAULT_PROJECT_ROLE = 'Project Admin'

export const TENANT_ROLE = 'Cy_Tenant'
export const PROJECT_ROLE = 'Cy_Project'

//---------------------------------------------------------------------//

//Data for Distribution group spec

export const D_GROUP_NAME = 'AutoTest_QA'
export const D_GROUP_DESC = 'Automation testing'
export const PRIMARY_COMPANY = 'katerra'

//---------------------------------------------------------------------//

//Data for user Directory Spec

export const ACTIVE_USER_01 = 'katerra cypress automation'
export const PENDING_USER_01 = 'cypress_131214'
export const DEACTIVATED_USER_01 = 'cypress_956337'
export const PROJECTS = ['cypress_961032', 'cypress_961018', 'cypress_961019']
export const ROLES = ['Tenant Admin', 'Cy_Tenant']
export const PRIMARY_COMPANY_02 = 'cypress_doNotDel'

//---------------------------------------------------------------------//

//Data for workflow template Spec

export const TASK_NAME_A = 'Roof inspection'
export const TASK_NAME_B = 'Material check'
export const TASK_NAME_C = 'Drawing review'
export const TASK_NAME_D = 'payment sechudule'

export const DURATION_A = '5'
export const DURATION_B = '3'
export const DURATION_C = '4'
export const DURATION_D = '1'

//---------------------------------------------------------------------//

// Data for Home.spec 

export const ADDRESS = 'Bengaluru'
export const PHONE_NUMBER = '9123456789'
export const COMPANY_NAME = 'cypress_testing'
export const TITTLE = 'cypress_title'
export const NEW_PASSWORD = 'Cypresstest@01'

//---------------------------------------------------------------------// 

// Data for configuration spec

export const COMMITMENT_CHANGE_ORDERS_DISCLAIMER_TEXT = 'The is updated Commitment Change Orders disclaimer.'
export const COST_ISSUES_DISCLAIMER_TEXT = 'The is updated Cost Issues disclaimer.'
export const DAILY_LOG_DISCLAIMER_TEXT = 'The is updated Cost Issues disclaimer.'
export const INSPECTIONS_DISCLAIMER_TEXT = 'The is updated Inspections disclaimer.'
export const MEETING_AGENDA_DISCLAIMER_TEXT = 'The minutes of this meeting will be considered accurate by all attendees if $ProjectCompany$ does not receive a request, within 48 hours of receiving this report, to edit any inconsistencies in what was discussed in this meeting.'
export const MEETING_MINUTES_DISCLAIMER_TEXT = 'The minutes of this meeting will be considered accurate by all attendees if $ProjectCompany$ does not receive a request, within 48 hours of receiving this report, to edit any inconsistencies in what was discussed in this meeting.'
export const OBSERVATIONS_DISCLAIMER_TEXT = 'The is updated Observations disclaimer.'
export const POTENTIAL_CHANGE_ORDERS_DISCLAIMER_TEXT = 'The is updated Potential Change Orders disclaimer.'
export const PRIME_CONTRACT_CHANGE_ORDERS_DISCLAIMER_TEXT = 'The is updated Prime Contract Change Orders disclaimer.'
export const PUNCHLIST_DISCLAIMER_TEXT = 'The is updated PunchList disclaimer.'
export const RFI_DISCLAIMER_TEXT = 'The is updated RFI disclaimer.'
export const SAFETY_DISCLAIMER_TEXT = 'The is updated Safety disclaimer.'
export const SUBMITTALS_DISCLAIMER_TEXT = 'The is updated Submittals disclaimer.'

//---------------------------------------------------------------------// 