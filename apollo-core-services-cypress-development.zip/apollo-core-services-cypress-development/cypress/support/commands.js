// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

import '@testing-library/cypress/add-commands';
import 'cypress-wait-until';
import 'cypress-file-upload';

import { getUser } from "./users";

//Global login which gets executed only once throughout the test run
before(() => {
  cy.server().route('GET', '/config-prod.json').as('loadConfigJson')
  cy.server().route('POST', '/identity/login').as('doLogin')

  cy.log('Logging in from Commands globally!')
  cy.doLogin()
})

//Global logout which gets executed only once throughout the test run
after(() => {
  cy.doLogOut()
})

Cypress.Commands.add('visitPage', (url) => {
  cy.visit(url, { failOnStatusCode: false });
})

Cypress.Commands.add('doLogin', (email, password) => {
  let adminUser;
  if (Cypress.env('isAdminUser')) {
    adminUser = getUser('adminUser');
  } else {
    adminUser = getUser('nonAdminUser');
  }

  cy.visitPage('/login')
    .wait('@loadConfigJson')
    .its('status')
    .should('eq', 200)
    .get('a', { timeout: 20000 })
    .should('be.visible');

  cy.get(':nth-child(2) > .ui-inputtext').type(adminUser.email);

  cy.get('.ui-inputgroup > .ui-inputtext')
    .type(adminUser.password)
    .get('.button-container > .ui-button > .ui-button-text')
    .click()
    .wait('@doLogin')
    .wait('@doLogin').its('status').should('eq', 200)
    .getCookies().should('have.length',4)
    .log('Login successful');
})

Cypress.Commands.add('doLogOut', () => {
  cy.server().route('GET', '/config-prod.json').as('loadConfigJson');
  cy.server().route('GET', '/identity/tenants').as('getTenants');
  cy.server().route('GET', '/tenant/projects?sortKey=name&sort=1&pageSize=500&active=true&includeAll=true').as('getAllProjects');

  cy.visitPage('/home')
    .wait('@loadConfigJson').its('status')
    .should('eq', 200)
    .wait('@getTenants')
    .its('status')
    .should('eq', 200)
    .wait('@getAllProjects')
    .its('status')
    .should('eq', 200)
    .get('.ap-icon-settings')
    .should('be.visible')
    .getCookies()
    .get('#userPopup').should('be.visible').click();
  cy.findByText('Sign Out').click();
})

Cypress.Commands.add('getAppDropDown', (appTitle) => {
  cy.get('a').contains(appTitle);
})

Cypress.Commands.add('findByDataCy', (element) => {
  return cy.get('[data-cy="' + element + '"]');
})

Cypress.Commands.add('clickElement', (element) => {
  cy.findByDataCy(element).click()
})

Cypress.Commands.add('enterText', (element, value) => {
  cy.findByDataCy(element).type(value);
})

Cypress.Commands.add('verifyElementEnabled', (element) => {
  cy.findByDataCy(element).should('not.be.disabled');
})

Cypress.Commands.add('verifyElementDisabled', (element) => {
  cy.findByDataCy(element).should('be.disabled');
})

Cypress.Commands.add('verifyElementNotFocused', (element) => {
  cy.findByDataCy(element).should('not.have.focus');
})

Cypress.Commands.add('getRandomString', () => {
  const uuid = () => Cypress._.random(0, 1e6);
  const id = uuid();
  const randomString = `cypress_${id}`;
  return randomString;
})

Cypress.Commands.add('visitPage', (url) => {
  cy.visit(url, { failOnStatusCode: false });
})

Cypress.Commands.add('validateRoles', (locator, role) => {
  return cy.get(locator).contains(role).should('not.be.disabled');
})

Cypress.Commands.add('getRandomKey', () => {
  let Key = "";
  const string = "ABCDEFGHIJ";
  for (let i = 0; i < 4; i++)
    Key += string.charAt(Math.floor(Math.random() * string.length));
  return Key;
})

