/// <reference types="cypress" />
/// <reference types="../support" />

declare namespace Cypress {
  interface Chainable<Subject> {
    /**
     * Create several Todo items via UI
     * @example
     * cy.createDefaultTodos()
     */
    // createDefaultToDos(): Chainable<any>

    /**
     * Creates one Todo using UI
     * @example
     * cy.createTodo('new item')
     */
    //createTodo(title: string): Chainable<any>

    doLogin(): Chainable<any>;

    doLogOut(): Chainable<any>;

    getAppDropDown(appTitle: string): Chainable<any>;

    clickElement(element: string): Chainable<any>;

    verifyElementEnabled(element: string): Chainable<any>;

    enterText(element: string, value: string): Chainable<any>;

    verifyElementDisabled(element: string): Chainable<any>;

    findByDataCy(element: string): Chainable<any>;

    adminLogin(): Chainable<any>;

    visitPage(url: string): Chainable<any>;

    validateRoles(locator: string, role: string): Chainable<any>;

    verifyElementNotFocused(element: string): Chainable<any>;

  }
}
