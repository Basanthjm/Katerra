
import { configure } from '@testing-library/cypress'

configure({ testIdAttribute: 'data-cy' })